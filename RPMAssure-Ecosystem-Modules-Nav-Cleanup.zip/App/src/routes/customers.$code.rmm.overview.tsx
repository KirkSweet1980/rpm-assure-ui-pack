import { createFileRoute } from "@tanstack/react-router";
import { RmmDevicesSection } from "@/components/customer/customer-sections";
import { Route as CustomerRoute } from "./customers.$code";

/** Legacy /rmm/overview — Platform Overview removed; show Servers */
export const Route = createFileRoute("/customers/$code/rmm/overview")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return <p className="text-sm text-muted">Loading customer workspace…</p>;
    }
    return <RmmDevicesSection data={data} />;
  },
});
