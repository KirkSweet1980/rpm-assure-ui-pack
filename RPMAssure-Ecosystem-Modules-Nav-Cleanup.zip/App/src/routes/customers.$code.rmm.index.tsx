import { createFileRoute } from "@tanstack/react-router";
import { RmmDevicesSection } from "@/components/customer/customer-sections";
import { Route as CustomerRoute } from "./customers.$code";

/** Default RMM landing — Platform Overview removed; open Servers */
export const Route = createFileRoute("/customers/$code/rmm/")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return (
        <p className="text-sm text-muted">
          Loading customer workspace… If this stays blank, use Refresh in the top bar.
        </p>
      );
    }
    return <RmmDevicesSection data={data} />;
  },
});
