import { useRouter, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { SpaLink } from "@/components/nav/spa-link";
import { warmHrefsIdle } from "@/lib/nav/preload";
import { cn } from "@/lib/utils";
import type { CustomerCover } from "@/lib/data/types";
import { NoCover } from "@/components/ui/no-cover";

/**
 * Customer workspace IA — pillars + modules as shadcn Tabs visual pattern (Phase 2)
 */
type PillarKey = keyof CustomerCover;

const domains: {
  id: string;
  label: string;
  short: string;
  match: (p: string, base: string) => boolean;
  href: (base: string) => string;
  pillar: PillarKey | null;
}[] = [
  {
    id: "exec",
    label: "Customer Ecosystem",
    short: "Ecosystem",
    match: (p, base) => p === base || p === `${base}/`,
    href: (base) => base,
    pillar: null,
  },
  {
    id: "syspro",
    label: "SYSPRO Deployment",
    short: "SYSPRO",
    match: (p, base) => p.startsWith(`${base}/syspro`),
    href: (base) => `${base}/syspro`,
    pillar: "syspro",
  },
  {
    id: "rmm",
    label: "RPM Remote Management",
    short: "RMM",
    match: (p, base) => p.startsWith(`${base}/rmm`),
    href: (base) => `${base}/rmm/devices`,
    pillar: "rmm",
  },
  {
    id: "cove",
    label: "RPM Cloud Backup",
    short: "Backup",
    match: (p, base) => p.startsWith(`${base}/cove`),
    href: (base) => `${base}/cove`,
    pillar: "cove",
  },
  {
    id: "epp",
    label: "RPM End Point Protection",
    short: "EPP",
    match: (p, base) => p.startsWith(`${base}/epp`),
    href: (base) => `${base}/epp`,
    pillar: "epp",
  },
  {
    id: "csp",
    label: "Microsoft 365 Tenant",
    short: "M365",
    match: (p, base) => p.startsWith(`${base}/csp`),
    href: (base) => `${base}/csp`,
    pillar: "csp",
  },
  {
    id: "ams",
    label: "AMS",
    short: "AMS",
    match: (p, base) => p.startsWith(`${base}/ams`),
    href: (base) => `${base}/ams`,
    pillar: null,
  },
];

const sysproLeaves = [
  { label: "Overview", path: "" },
  { label: "FinSight", path: "dtr" },
  { label: "License", path: "license" },
  { label: "Hotfixes", path: "hotfixes" },
  { label: "Operators", path: "operators" },
  { label: "Jobs", path: "jobs" },
  { label: "Health", path: "health" },
  { label: "Security", path: "security" },
  { label: "SQL", path: "sql" },
];

const rmmLeaves = [
  { label: "Servers", path: "devices" },
  { label: "Workstations", path: "workstations" },
  { label: "Server Patch Management", path: "patch" },
  { label: "Server Alerts", path: "alerts" },
];

const coveLeaves = [
  { label: "Devices on Cloud Backup", path: "devices" },
  { label: "Backup Recovery Testing", path: "recovery" },
  { label: "Retention policies", path: "retention" },
];

const eppLeaves = [
  { label: "Device stats", path: "" },
  { label: "Incidents", path: "incidents" },
  { label: "Modules", path: "modules" },
  { label: "Quarantine", path: "quarantine" },
];

const cspLeaves = [
  { label: "Tenant health", path: "" },
  { label: "Licensed users", path: "users" },
  { label: "License stats", path: "licenses" },
];

const amsLeaves = [
  { label: "Overview", path: "" },
  { label: "Incidents", path: "incidents" },
  { label: "Risks", path: "risks" },
  { label: "SLA", path: "sla" },
];

function pillarCovered(
  cover: CustomerCover | null | undefined,
  pillar: PillarKey | null,
): boolean {
  if (!pillar) return true; // AMS always available
  if (!cover) return false;
  // Strict: only show Covered when flag is true (loader sets from live data)
  return cover[pillar] === true;
}

export function CustomerWorkspaceNav({
  code,
  cover,
}: {
  code: string;
  cover?: CustomerCover | null;
}) {
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const base = `/customers/${encodeURIComponent(code)}`;
  const path = pathname.replace(/\/$/, "") || "/";

  const inSyspro = path.startsWith(`${base}/syspro`);
  const inCove = path.startsWith(`${base}/cove`);
  const inRmm = path.startsWith(`${base}/rmm`);
  const inEpp = path.startsWith(`${base}/epp`);
  const inCsp = path.startsWith(`${base}/csp`);
  const inAms = path.startsWith(`${base}/ams`);

  useEffect(() => {
    const pillarHrefs = domains
      .filter((d) => pillarCovered(cover, d.pillar))
      .map((d) => d.href(base));

    let moduleHrefs: string[] = [];
    if (inSyspro) {
      moduleHrefs = sysproLeaves.map((l) =>
        l.path ? `${base}/syspro/${l.path}` : `${base}/syspro`,
      );
    } else if (inRmm) {
      moduleHrefs = rmmLeaves.map((l) =>
        l.path ? `${base}/rmm/${l.path}` : `${base}/rmm`,
      );
    } else if (inCove) {
      moduleHrefs = coveLeaves.map((l) =>
        l.path ? `${base}/cove/${l.path}` : `${base}/cove`,
      );
    } else if (inEpp) {
      moduleHrefs = eppLeaves.map((l) =>
        l.path ? `${base}/epp/${l.path}` : `${base}/epp`,
      );
    } else if (inCsp) {
      moduleHrefs = cspLeaves.map((l) =>
        l.path ? `${base}/csp/${l.path}` : `${base}/csp`,
      );
    } else if (inAms) {
      moduleHrefs = amsLeaves.map((l) =>
        l.path ? `${base}/ams/${l.path}` : `${base}/ams`,
      );
    }

    return warmHrefsIdle(router, [...moduleHrefs, ...pillarHrefs], {
      delayMs: 150,
      max: 10,
    });
  }, [router, base, cover, inSyspro, inRmm, inCove, inEpp, inCsp, inAms]);

  return (
    <div className="rpma-workspace-nav space-y-2.5">
      {/* Pillars — shadcn TabsList look, route-based */}
      <div
        className="rpma-tabs-list rpma-pillar-track flex w-full flex-wrap gap-0.5 rounded-lg bg-surface-2/90 p-1"
        role="tablist"
        aria-label="Customer service pillars"
      >
        {domains.map((d) => {
          const active = d.match(path, base);
          const covered = pillarCovered(cover, d.pillar);
          const noCover = d.pillar != null && !covered;
          return (
            <SpaLink
              key={d.id}
              href={d.href(base)}
              role="tab"
              aria-selected={active}
              title={noCover ? `${d.label} — No Cover` : d.label}
              data-state={active ? "active" : "inactive"}
              className={cn(
                "rpma-tabs-trigger rpma-pillar-btn inline-flex min-h-9 min-w-0 flex-1 flex-col items-center justify-center rounded-md px-1.5 py-1.5 text-center sm:px-2",
                "text-[11px] font-semibold leading-tight tracking-tight sm:text-[12px]",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/35",
                active
                  ? "is-active"
                  : "text-muted hover:text-fg hover:bg-surface/80",
                noCover && !active && "opacity-55",
              )}
            >
              <span className="max-w-full truncate">
                <span className="hidden lg:inline">{d.label}</span>
                <span className="lg:hidden">{d.short}</span>
              </span>
              {noCover ? (
                <span
                  className={cn(
                    "rpma-no-cover mt-0.5 text-[9px] font-extrabold uppercase tracking-wide",
                    active ? "text-white" : "text-rag-amber",
                  )}
                >
                  No Cover
                </span>
              ) : null}
            </SpaLink>
          );
        })}
      </div>

      {inSyspro ? (
        <SectionRow
          aria="SYSPRO Deployment modules"
          noCover={cover?.syspro !== true}
          base={`${base}/syspro`}
          path={path}
          leaves={sysproLeaves}
        />
      ) : null}
      {inRmm ? (
        <SectionRow
          aria="RPM Remote Management modules"
          noCover={cover?.rmm !== true}
          base={`${base}/rmm`}
          path={path}
          leaves={rmmLeaves}
        />
      ) : null}
      {inCove ? (
        <SectionRow
          aria="RPM Cloud Backup modules"
          noCover={cover?.cove !== true}
          base={`${base}/cove`}
          path={path}
          leaves={coveLeaves}
        />
      ) : null}
      {inEpp ? (
        <SectionRow
          aria="RPM End Point Protection modules"
          noCover={cover?.epp !== true}
          base={`${base}/epp`}
          path={path}
          leaves={eppLeaves}
        />
      ) : null}
      {inCsp ? (
        <SectionRow
          aria="Microsoft 365 Tenant modules"
          noCover={cover?.csp !== true}
          base={`${base}/csp`}
          path={path}
          leaves={cspLeaves}
        />
      ) : null}
      {inAms ? (
        <SectionRow
          aria="AMS pack"
          noCover={false}
          base={`${base}/ams`}
          path={path}
          leaves={amsLeaves}
        />
      ) : null}
    </div>
  );
}

function SectionRow({
  aria,
  noCover,
  base,
  path,
  leaves,
}: {
  aria: string;
  noCover: boolean;
  base: string;
  path: string;
  leaves: { label: string; path: string }[];
}) {
  return (
    <div
      className="rpma-tabs-list rpma-module-track flex w-full flex-wrap items-center gap-0.5 rounded-lg bg-surface-2/70 p-1"
      role="navigation"
      aria-label={aria}
    >
      {noCover ? (
        <NoCover title={`${aria} — not in scope`} className="ml-1 mr-1" />
      ) : (
        <span className="ml-1 mr-1 hidden shrink-0 text-[10px] font-bold uppercase tracking-wider text-subtle sm:inline">
          Modules
        </span>
      )}
      {leaves.map((l) => {
        const href = l.path ? `${base}/${l.path}` : base;
        const active =
          path === href ||
          path === `${href}/` ||
          (l.path === "" && (path === base || path === `${base}/`));
        return (
          <SubLink key={l.label + l.path} href={href} label={l.label} active={active} />
        );
      })}
    </div>
  );
}

function SubLink({
  href,
  label,
  active,
}: {
  href: string;
  label: string;
  active: boolean;
}) {
  return (
    <SpaLink
      href={href}
      data-state={active ? "active" : "inactive"}
      className={cn(
        "rpma-tabs-trigger rpma-module-btn inline-flex items-center rounded-md px-2.5 py-1.5 text-[11px] font-semibold transition",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/35",
        active
          ? "is-active"
          : "text-muted hover:text-fg hover:bg-surface/80",
      )}
    >
      {label}
    </SpaLink>
  );
}
