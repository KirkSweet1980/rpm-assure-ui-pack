Ecosystem modules overview + nav cleanup. Run Apply-Ecosystem-Modules-Nav-Cleanup.ps1
