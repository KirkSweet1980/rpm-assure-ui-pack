Option D v2: stronger animations, watermark words under chart, no Estate health label.
Do NOT Expand-Archive into Downloads.
Paste the PowerShell install block from chat (streams login.tsx from this zip).
