import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Eye, EyeOff, Lock, Shield, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

/** Option D — split insight + scattered watermark words (CSS motion, silent) */
const LOGIN_SKIN = "option-d-v2";

/** Scattered watermarks under the chart — not stacked, not adjacent */
const WATERMARKS: {
  text: string;
  top: string;
  left: string;
  rotate: number;
  size: string;
  delay: string;
  opacity: number;
}[] = [
  { text: "Clarity", top: "54%", left: "6%", rotate: -12, size: "1.35rem", delay: "0s", opacity: 0.22 },
  { text: "Insight", top: "61%", left: "48%", rotate: 8, size: "1.05rem", delay: "0.6s", opacity: 0.18 },
  { text: "Evidence", top: "70%", left: "18%", rotate: 4, size: "1.2rem", delay: "1.1s", opacity: 0.2 },
  { text: "Confidence", top: "78%", left: "55%", rotate: -7, size: "0.95rem", delay: "0.3s", opacity: 0.16 },
  { text: "Visibility", top: "85%", left: "10%", rotate: 11, size: "1.15rem", delay: "1.5s", opacity: 0.19 },
  { text: "Source of truth", top: "90%", left: "38%", rotate: -5, size: "0.88rem", delay: "0.9s", opacity: 0.15 },
];

const BAR_HEIGHTS = [32, 48, 58, 72, 86, 100] as const;
const BAR_LABELS = ["73%", "84%", "88%", "91%", "94%", "96%"] as const;

const SQL_SNIPPET = [
  "SELECT c.CustomerCode, h.HealthScorePct",
  "FROM dbo.Dim_Customer c",
  "JOIN dbo.vw_Kpi_Customer_Health_Latest h",
  "  ON h.CustomerCode = c.CustomerCode",
  "WHERE c.Active = 1",
  "ORDER BY h.HealthScorePct DESC;",
];

const OPTION_D_CSS = `
.rpma-d-root {
  min-height: 100dvh;
  width: 100%;
  display: grid;
  grid-template-columns: 1.05fr 0.95fr;
  background: #050d18;
  color: #e8f4ff;
  overflow: hidden;
  position: relative;
}
.rpma-d-root::before {
  content: "";
  position: absolute;
  top: 0; bottom: 0; left: 52%;
  width: 2px;
  z-index: 5;
  background: linear-gradient(180deg, transparent, rgba(27,184,166,0.55) 50%, transparent);
  box-shadow: 0 0 18px rgba(27,184,166,0.35);
  transform: skewX(-6deg);
  pointer-events: none;
  animation: rpmaDLine 3s ease-in-out infinite;
}
@keyframes rpmaDLine {
  0%, 100% { opacity: 0.55; }
  50% { opacity: 1; }
}

.rpma-d-stage {
  position: relative;
  min-height: 100dvh;
  overflow: hidden;
  background:
    radial-gradient(ellipse 70% 60% at 35% 40%, rgba(27,184,166,0.14) 0%, transparent 60%),
    linear-gradient(160deg, #071525 0%, #050d18 55%, #030a12 100%);
  padding: 2rem 1.75rem 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
.rpma-d-sql-bg {
  position: absolute;
  inset: 0;
  z-index: 0;
  font-family: Consolas, "Courier New", monospace;
  font-size: 11px;
  line-height: 1.55;
  color: rgba(140,190,220,0.5);
  padding: 1.5rem;
  pointer-events: none;
  white-space: pre;
  opacity: 0.28;
  animation: rpmaDSqlDrift 18s linear infinite;
  will-change: transform;
}
@keyframes rpmaDSqlDrift {
  0% { transform: translate3d(0,0,0); }
  100% { transform: translate3d(0,-18%,0); }
}

.rpma-d-radar-wrap {
  position: relative;
  z-index: 2;
  width: min(260px, 68%);
  aspect-ratio: 1;
  margin: 0.25rem auto 0;
  flex: 0 0 auto;
}
.rpma-d-radar {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  border: 1px solid rgba(27,184,166,0.35);
  box-shadow:
    0 0 0 16px rgba(27,184,166,0.05),
    0 0 40px rgba(27,184,166,0.18),
    inset 0 0 40px rgba(27,184,166,0.08);
  animation: rpmaDRadarPulse 2.4s ease-in-out infinite;
}
@keyframes rpmaDRadarPulse {
  0%, 100% { box-shadow: 0 0 0 16px rgba(27,184,166,0.04), 0 0 30px rgba(27,184,166,0.12), inset 0 0 30px rgba(27,184,166,0.06); }
  50% { box-shadow: 0 0 0 22px rgba(27,184,166,0.08), 0 0 50px rgba(27,184,166,0.28), inset 0 0 50px rgba(27,184,166,0.12); }
}
.rpma-d-radar::before,
.rpma-d-radar::after {
  content: "";
  position: absolute;
  inset: 18%;
  border-radius: 50%;
  border: 1px solid rgba(27,184,166,0.22);
}
.rpma-d-radar::after { inset: 36%; }
.rpma-d-radar-cross::before,
.rpma-d-radar-cross::after {
  content: "";
  position: absolute;
  background: rgba(27,184,166,0.15);
}
.rpma-d-radar-cross::before {
  left: 50%; top: 8%; bottom: 8%; width: 1px; transform: translateX(-50%);
}
.rpma-d-radar-cross::after {
  top: 50%; left: 8%; right: 8%; height: 1px; transform: translateY(-50%);
}
.rpma-d-sweep {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(
    from 0deg,
    transparent 0deg,
    transparent 280deg,
    rgba(27,184,166,0.08) 310deg,
    rgba(27,184,166,0.55) 350deg,
    rgba(27,184,166,0.75) 360deg
  );
  animation: rpmaDSweep 2.8s linear infinite;
  will-change: transform;
}
@keyframes rpmaDSweep {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
.rpma-d-nodes {
  position: absolute;
  inset: 0;
  animation: rpmaDNodes 8s ease-in-out infinite alternate;
  will-change: transform;
}
@keyframes rpmaDNodes {
  from { transform: rotate(-6deg) scale(1); }
  to { transform: rotate(10deg) scale(1.04); }
}
.rpma-d-node {
  position: absolute;
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: #1bb8a6;
  box-shadow: 0 0 14px rgba(27,184,166,1);
  animation: rpmaDNodeBlink 1.8s ease-in-out infinite;
}
.rpma-d-node:nth-child(1) { top: 18%; left: 48%; animation-delay: 0s; }
.rpma-d-node:nth-child(2) { top: 32%; left: 72%; animation-delay: 0.25s; }
.rpma-d-node:nth-child(3) { top: 55%; left: 78%; animation-delay: 0.5s; }
.rpma-d-node:nth-child(4) { top: 72%; left: 58%; animation-delay: 0.75s; }
.rpma-d-node:nth-child(5) { top: 68%; left: 28%; animation-delay: 1s; }
.rpma-d-node:nth-child(6) { top: 40%; left: 22%; animation-delay: 1.25s; }
.rpma-d-node:nth-child(7) { top: 48%; left: 50%; width: 11px; height: 11px; animation-delay: 0.1s; }
@keyframes rpmaDNodeBlink {
  0%, 100% { opacity: 0.55; transform: scale(0.85); }
  50% { opacity: 1; transform: scale(1.25); }
}

.rpma-d-bars {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: flex-end;
  gap: 0.55rem;
  height: 140px;
  margin: 0.5rem 0.25rem 0;
  padding: 0 0.35rem;
}
.rpma-d-bar {
  flex: 1;
  border-radius: 6px 6px 2px 2px;
  background: linear-gradient(180deg, #5eead4 0%, #14b8a6 45%, #0f766e 100%);
  box-shadow: 0 0 18px rgba(27,184,166,0.35);
  transform-origin: bottom center;
  animation: rpmaDBarGrow 1.1s cubic-bezier(0.22,1,0.36,1) both, rpmaDBarPulse 2.2s ease-in-out infinite 1.1s;
  will-change: transform;
  position: relative;
  min-height: 12%;
}
.rpma-d-bar span {
  position: absolute;
  top: -1.2rem;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.68rem;
  font-weight: 700;
  color: rgba(180,240,230,0.9);
  white-space: nowrap;
}
.rpma-d-bar:nth-child(1) { height: 32%; animation-delay: 0s, 1.1s; }
.rpma-d-bar:nth-child(2) { height: 48%; animation-delay: 0.08s, 1.18s; }
.rpma-d-bar:nth-child(3) { height: 58%; animation-delay: 0.16s, 1.26s; }
.rpma-d-bar:nth-child(4) { height: 72%; animation-delay: 0.24s, 1.34s; }
.rpma-d-bar:nth-child(5) { height: 86%; animation-delay: 0.32s, 1.42s; }
.rpma-d-bar:nth-child(6) { height: 100%; animation-delay: 0.4s, 1.5s; }
@keyframes rpmaDBarGrow {
  from { transform: scaleY(0.05); opacity: 0.3; }
  to { transform: scaleY(1); opacity: 1; }
}
@keyframes rpmaDBarPulse {
  0%, 100% { filter: brightness(1); transform: scaleY(1); }
  50% { filter: brightness(1.2); transform: scaleY(1.06); }
}

/* Watermark layer under chart — scattered, not stacked */
.rpma-d-wm-layer {
  position: absolute;
  left: 0;
  right: 0;
  top: 48%;
  bottom: 0;
  z-index: 1;
  pointer-events: none;
  overflow: hidden;
}
.rpma-d-wm {
  position: absolute;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: #1bb8a6;
  white-space: nowrap;
  user-select: none;
  text-shadow: 0 0 20px rgba(27,184,166,0.25);
  animation: rpmaDWmFloat 5s ease-in-out infinite;
  will-change: transform, opacity;
}
@keyframes rpmaDWmFloat {
  0%, 100% { transform: translate3d(0,0,0) rotate(var(--r, 0deg)); opacity: var(--o, 0.18); }
  50% { transform: translate3d(0,-10px,0) rotate(var(--r, 0deg)); opacity: calc(var(--o, 0.18) + 0.1); }
}

.rpma-d-panel {
  position: relative;
  z-index: 2;
  min-height: 100dvh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2.5rem 2rem;
  background:
    radial-gradient(ellipse 60% 50% at 60% 40%, rgba(27,184,166,0.06) 0%, transparent 55%),
    linear-gradient(200deg, #0a1524 0%, #071018 100%);
}
.rpma-d-card { width: min(380px, 100%); animation: rpmaDCardIn 0.65s ease-out both; }
@keyframes rpmaDCardIn {
  from { opacity: 0; transform: translateY(14px); }
  to { opacity: 1; transform: translateY(0); }
}
.rpma-d-brand { text-align: center; margin-bottom: 1.5rem; }
.rpma-d-brand-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 3rem; height: 3rem;
  border-radius: 0.85rem;
  border: 1px solid rgba(27,184,166,0.4);
  background: rgba(27,184,166,0.1);
  color: #1bb8a6;
  margin-bottom: 0.85rem;
  animation: rpmaDShield 2.4s ease-in-out infinite;
}
@keyframes rpmaDShield {
  0%, 100% { box-shadow: 0 0 14px rgba(27,184,166,0.15); transform: scale(1); }
  50% { box-shadow: 0 0 32px rgba(27,184,166,0.45); transform: scale(1.06); }
}
.rpma-d-brand h1 {
  margin: 0;
  font-size: 1.75rem;
  font-weight: 800;
  letter-spacing: -0.02em;
}
.rpma-d-brand h1 span { color: #1bb8a6; }
.rpma-d-brand p {
  margin: 0.4rem 0 0;
  font-size: 0.82rem;
  color: rgba(170,200,220,0.7);
}
.rpma-d-form-box {
  padding: 1.5rem 1.4rem 1.35rem;
  border-radius: 1.1rem;
  background: linear-gradient(165deg, rgba(16,38,60,0.75) 0%, rgba(10,22,38,0.88) 100%);
  border: 1px solid rgba(27,184,166,0.22);
  box-shadow: 0 0 0 1px rgba(27,184,166,0.06), 0 24px 56px rgba(0,0,0,0.45);
  backdrop-filter: blur(16px);
}
.rpma-d-form-box h2 {
  margin: 0 0 1rem;
  font-size: 1.05rem;
  font-weight: 650;
  color: rgba(230,242,255,0.95);
}
.rpma-d-form { display: flex; flex-direction: column; gap: 0.9rem; }
.rpma-d-label {
  display: block;
  margin-bottom: 0.35rem;
  font-size: 0.75rem;
  font-weight: 600;
  color: rgba(200,220,235,0.8);
}
.rpma-d-field { position: relative; display: flex; align-items: center; }
.rpma-d-field > svg:first-of-type {
  position: absolute;
  left: 0.75rem;
  color: rgba(140,180,210,0.7);
  pointer-events: none;
}
.rpma-d-field input {
  width: 100%;
  height: 2.65rem;
  padding: 0 0.9rem 0 2.35rem;
  border-radius: 0.65rem;
  border: 1px solid rgba(100,160,200,0.2);
  background: rgba(6,14,26,0.75);
  color: #f0f7ff;
  font-size: 0.9rem;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.rpma-d-field input:focus {
  border-color: rgba(27,184,166,0.55);
  box-shadow: 0 0 0 3px rgba(27,184,166,0.14);
}
.rpma-d-field--pw input { padding-right: 2.5rem; }
.rpma-d-eye {
  position: absolute;
  right: 0.4rem;
  background: transparent;
  border: none;
  color: rgba(160,190,210,0.8);
  cursor: pointer;
  display: inline-flex;
  padding: 0.35rem;
}
.rpma-d-err { margin: 0; color: #f87171; font-size: 0.82rem; }
.rpma-d-submit {
  height: 2.75rem;
  margin-top: 0.15rem;
  border: none;
  border-radius: 0.65rem;
  background: linear-gradient(90deg, #0d9488 0%, #1bb8a6 55%, #14b8a6 100%);
  color: #042f2e;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.4rem;
  animation: rpmaDBtn 2s ease-in-out infinite;
}
@keyframes rpmaDBtn {
  0%, 100% { box-shadow: 0 8px 22px rgba(27,184,166,0.28); }
  50% { box-shadow: 0 10px 32px rgba(27,184,166,0.5); }
}
.rpma-d-submit:hover:not(:disabled) { transform: translateY(-1px); }
.rpma-d-submit:disabled { opacity: 0.7; cursor: wait; animation: none; }
.rpma-d-foot {
  margin: 1.25rem 0 0;
  text-align: center;
  font-size: 0.75rem;
  color: rgba(160,190,210,0.45);
}

@media (max-width: 900px) {
  .rpma-d-root { grid-template-columns: 1fr; }
  .rpma-d-root::before { display: none; }
  .rpma-d-stage { min-height: auto; max-height: 40vh; padding: 1rem; }
  .rpma-d-radar-wrap { width: 120px; }
  .rpma-d-bars { height: 72px; }
  .rpma-d-wm { font-size: 0.7rem !important; }
  .rpma-d-panel { min-height: auto; padding: 1.25rem; }
}
@media (prefers-reduced-motion: reduce) {
  .rpma-d-sweep, .rpma-d-nodes, .rpma-d-bar, .rpma-d-wm,
  .rpma-d-sql-bg, .rpma-d-submit, .rpma-d-brand-icon,
  .rpma-d-card, .rpma-d-radar, .rpma-d-node, .rpma-d-root::before {
    animation: none !important;
  }
}
`;

function InsightStage() {
  const sql = [...SQL_SNIPPET, "", ...SQL_SNIPPET, "", ...SQL_SNIPPET, "", ...SQL_SNIPPET].join("\n");
  return (
    <aside className="rpma-d-stage" aria-hidden="true">
      <div className="rpma-d-sql-bg">{sql}</div>

      <div className="rpma-d-radar-wrap">
        <div className="rpma-d-radar">
          <div className="rpma-d-radar-cross" />
          <div className="rpma-d-sweep" />
          <div className="rpma-d-nodes">
            {Array.from({ length: 7 }).map((_, i) => (
              <span key={i} className="rpma-d-node" />
            ))}
          </div>
        </div>
      </div>

      <div className="rpma-d-bars">
        {BAR_HEIGHTS.map((h, i) => (
          <div key={i} className="rpma-d-bar" style={{ height: `${h}%` }}>
            <span>{BAR_LABELS[i]}</span>
          </div>
        ))}
      </div>

      {/* Scattered watermark words under the chart — random placement */}
      <div className="rpma-d-wm-layer">
        {WATERMARKS.map((w) => (
          <span
            key={w.text}
            className="rpma-d-wm"
            style={{
              top: w.top,
              left: w.left,
              fontSize: w.size,
              ["--r" as string]: `${w.rotate}deg`,
              ["--o" as string]: w.opacity,
              animationDelay: w.delay,
              opacity: w.opacity,
              transform: `rotate(${w.rotate}deg)`,
            }}
          >
            {w.text}
          </span>
        ))}
      </div>
    </aside>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({ email: loginEmail, password });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rpma-d-root" data-login-skin={LOGIN_SKIN}>
      <style>{OPTION_D_CSS}</style>
      <InsightStage />

      <section className="rpma-d-panel">
        <div className="rpma-d-card">
          <div className="rpma-d-brand">
            <div className="rpma-d-brand-icon">
              <Shield size={22} strokeWidth={2.25} />
            </div>
            <h1>
              RPM <span>Assure</span>
            </h1>
            <p>Managed Service Assurance</p>
          </div>

          <div className="rpma-d-form-box">
            <IdleLogoutBanner />
            <h2>Sign in to your account</h2>

            {!authEnabled ? (
              <p className="rpma-d-err">Auth is disabled.</p>
            ) : (
              <form className="rpma-d-form" onSubmit={onSignIn}>
                <label>
                  <span className="rpma-d-label">Email or username</span>
                  <span className="rpma-d-field">
                    <User size={16} />
                    <input
                      type="text"
                      required
                      placeholder="Email or username"
                      autoComplete="username"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </span>
                </label>

                <label>
                  <span className="rpma-d-label">Password</span>
                  <span className="rpma-d-field rpma-d-field--pw">
                    <Lock size={16} />
                    <input
                      type={showPw ? "text" : "password"}
                      required
                      minLength={8}
                      placeholder="Password"
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      className="rpma-d-eye"
                      onClick={() => setShowPw((v) => !v)}
                      aria-label={showPw ? "Hide password" : "Show password"}
                      tabIndex={-1}
                    >
                      {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </span>
                </label>

                {error ? <p className="rpma-d-err">{error}</p> : null}

                <button type="submit" className="rpma-d-submit" disabled={busy}>
                  {busy ? "Signing in..." : "Sign in"}
                </button>
              </form>
            )}
          </div>

          <p className="rpma-d-foot">Powered by RPM Resources · Secure staff access</p>
        </div>
      </section>
    </div>
  );
}
