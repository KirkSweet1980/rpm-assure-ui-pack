# Apply-Epp-Staff-Map-453.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$SqlRoot = 'C:\RPM-Assure\Sql\bitdefender'
$Server = '102.222.21.220,14333'
$Db = 'RPMAssure_App'
if (-not (Test-Path $SqlRoot)) { New-Item -ItemType Directory -Path $SqlRoot -Force | Out-Null }
Copy-Item (Join-Path $Here 'Sql\bitdefender\453_Map_Staff_Unmapped_And_Fix_Seed.sql') (Join-Path $SqlRoot '453_Map_Staff_Unmapped_And_Fix_Seed.sql') -Force
Copy-Item (Join-Path $Here 'Sql\bitdefender\Collect-Bitdefender-To-RPMAssure.ps1') (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1') -Force
Write-Host '=== 453 map staff unmapped hosts -> RPMINT ==='
& sqlcmd -S $Server -d $Db -E -C -b -i (Join-Path $SqlRoot '453_Map_Staff_Unmapped_And_Fix_Seed.sql') 2>&1 | ForEach-Object { Write-Host $_ }
Write-Host '=== Done ==='
Write-Host 'Hard-refresh RPM Internal EPP. Other customers already mapped (AHIC/HYDRA/RSR/UVSS/METSI).'
Write-Host 'Incidents/Quarantine need GravityZone API key rights (see chat).'
