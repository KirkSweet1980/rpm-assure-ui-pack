import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RpmAssureMark } from "@/components/brand/rpm-assure-mark";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

/** Option A animated skin — matches mockup (soft SQL + floating chips + glass) */
const LOGIN_SKIN = "option-a-animated";

const SQL_LINES = [
  "-- RPM Assure  |  Estate health query workspace",
  "USE [RPMAssure_App];",
  "GO",
  "SET NOCOUNT ON;",
  "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;",
  "",
  "SELECT",
  "    c.CustomerCode,",
  "    c.DisplayName,",
  "    h.HealthRag,",
  "    h.HealthScorePct,",
  "    h.AssuranceScorePct",
  "FROM dbo.Dim_Customer AS c",
  "LEFT JOIN dbo.vw_Kpi_Customer_Health_Latest AS h",
  "  ON h.CustomerCode = c.CustomerCode",
  "WHERE c.Active = 1",
  "ORDER BY h.HealthScorePct ASC;",
  "GO",
  "",
  "SELECT CustomerCode, COUNT(*) AS OfflineServers",
  "FROM dbo.Pulseway_Devices",
  "WHERE IsOnline = 0",
  "  AND DeviceClass = N'Server'",
  "GROUP BY CustomerCode;",
  "GO",
  "",
  "SELECT CustomerCode, DeviceName, LastBackupStatus",
  "FROM dbo.Cove_DeviceStatistics",
  "WHERE SnapshotDate = CAST(SYSUTCDATETIME() AS date);",
  "GO",
  "",
  "PRINT N'Query complete — assurance delivered.';",
  "GO",
] as const;

const CHIPS: { text: string; cls: string }[] = [
  { text: "clarity", cls: "rpma-a-chip rpma-a-chip--L1" },
  { text: "source of truth", cls: "rpma-a-chip rpma-a-chip--L2" },
  { text: "insight", cls: "rpma-a-chip rpma-a-chip--L3" },
  { text: "visibility", cls: "rpma-a-chip rpma-a-chip--R1" },
  { text: "confidence", cls: "rpma-a-chip rpma-a-chip--R2" },
  { text: "evidence", cls: "rpma-a-chip rpma-a-chip--R3" },
];

const OPTION_A_CSS = `
.rpma-a-root {
  position: relative;
  min-height: 100dvh;
  width: 100%;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background: radial-gradient(ellipse 80% 70% at 50% 40%, #0a1a2e 0%, #050d18 55%, #030910 100%);
  color: #e8f4ff;
  isolation: isolate;
}
/* Soft SQL stream */
.rpma-a-sql {
  position: absolute;
  inset: 0;
  z-index: 0;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  overflow: hidden;
  pointer-events: none;
  font-family: Consolas, "Courier New", ui-monospace, monospace;
  filter: blur(0.2px);
  opacity: 0.55;
}
.rpma-a-sql-col { overflow: hidden; opacity: 0.38; }
.rpma-a-sql-col--2 { opacity: 0.28; }
.rpma-a-sql-col--3 { opacity: 0.34; }
.rpma-a-sql-track {
  padding: 1.25rem 1rem 2rem;
  animation: rpmaASql 52s linear infinite;
  will-change: transform;
}
.rpma-a-sql-col--2 .rpma-a-sql-track {
  animation-duration: 68s;
  animation-direction: reverse;
  padding-top: 3.5rem;
}
.rpma-a-sql-col--3 .rpma-a-sql-track {
  animation-duration: 58s;
  padding-top: 2rem;
}
@keyframes rpmaASql {
  0% { transform: translateY(0); }
  100% { transform: translateY(-33.333%); }
}
.rpma-a-sql-line {
  display: flex;
  gap: 0.55rem;
  font-size: clamp(10px, 1vw, 12px);
  line-height: 1.55;
  white-space: pre;
}
.rpma-a-sql-g { flex: 0 0 1.6rem; text-align: right; color: rgba(120,150,170,0.28); }
.rpma-a-sql-t { color: rgba(160,200,225,0.42); }
.rpma-a-sql-line.is-kw .rpma-a-sql-t { color: rgba(90,165,230,0.62); font-weight: 700; }
.rpma-a-sql-line.is-c .rpma-a-sql-t { color: rgba(110,170,95,0.5); font-style: italic; }
.rpma-a-sql-line.is-s .rpma-a-sql-t { color: rgba(210,150,120,0.48); }

/* Vignette — clear center like mockup */
.rpma-a-vignette {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  background:
    radial-gradient(ellipse 42% 50% at 50% 46%,
      rgba(5,13,24,0.94) 0%,
      rgba(5,13,24,0.72) 38%,
      rgba(5,13,24,0.25) 68%,
      transparent 100%),
    linear-gradient(90deg, rgba(5,13,24,0.45) 0%, transparent 18%, transparent 82%, rgba(5,13,24,0.45) 100%);
}

/* Floating chips */
.rpma-a-chips {
  position: absolute;
  inset: 0;
  z-index: 3;
  pointer-events: none;
  overflow: hidden;
}
.rpma-a-chip {
  position: absolute;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.48rem 1rem 0.48rem 0.72rem;
  border-radius: 999px;
  border: 1px solid rgba(27,184,166,0.55);
  background: rgba(8,28,48,0.88);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: #c8fff6;
  font-size: clamp(0.78rem, 1.1vw, 0.95rem);
  font-weight: 650;
  letter-spacing: 0.02em;
  text-transform: lowercase;
  white-space: nowrap;
  box-shadow:
    0 8px 28px rgba(0,0,0,0.4),
    0 0 0 1px rgba(27,184,166,0.1),
    0 0 24px rgba(27,184,166,0.12);
  animation: rpmaAChip 5.2s ease-in-out infinite;
}
.rpma-a-chip-dot {
  width: 0.5rem;
  height: 0.5rem;
  border-radius: 50%;
  background: #1bb8a6;
  box-shadow: 0 0 10px rgba(27,184,166,0.85);
  flex: 0 0 auto;
}
.rpma-a-chip--L1 { top: 20%; left: 3%; animation-delay: 0s; }
.rpma-a-chip--L2 { top: 44%; left: 2%; animation-delay: 0.75s; }
.rpma-a-chip--L3 { top: 68%; left: 3%; animation-delay: 1.5s; }
.rpma-a-chip--R1 { top: 20%; right: 3%; animation-delay: 0.35s; }
.rpma-a-chip--R2 { top: 44%; right: 2%; animation-delay: 1.1s; }
.rpma-a-chip--R3 { top: 68%; right: 3%; animation-delay: 1.85s; }
@keyframes rpmaAChip {
  0%, 100% { transform: translateY(0) scale(1); opacity: 0.92; }
  50% { transform: translateY(-10px) scale(1.03); opacity: 1; }
}

/* Center stack */
.rpma-a-center {
  position: relative;
  z-index: 10;
  width: min(400px, 92vw);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.15rem;
}
.rpma-a-mark {
  display: flex;
  justify-content: center;
  margin-bottom: 0.35rem;
  animation: rpmaAPulse 3.6s ease-in-out infinite;
  filter: drop-shadow(0 0 18px rgba(27,184,166,0.45));
}
@keyframes rpmaAPulse {
  0%, 100% { transform: scale(1); filter: drop-shadow(0 0 14px rgba(27,184,166,0.35)); }
  50% { transform: scale(1.04); filter: drop-shadow(0 0 26px rgba(27,184,166,0.55)); }
}
.rpma-a-title {
  margin: 0;
  font-size: clamp(2.1rem, 4.8vw, 2.85rem);
  font-weight: 800;
  letter-spacing: -0.03em;
  text-align: center;
  line-height: 1.1;
}
.rpma-a-rpm { color: #fff; }
.rpma-a-assure {
  color: #1bb8a6;
  text-shadow: 0 0 28px rgba(27,184,166,0.35);
}
.rpma-a-tag {
  margin: 0.55rem 0 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: #1bb8a6;
}
.rpma-a-tag::before,
.rpma-a-tag::after {
  content: "";
  width: 2.2rem;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(27,184,166,0.7), transparent);
}

/* Glass card — mockup look */
.rpma-a-glass {
  width: 100%;
  max-width: 24rem;
  padding: 1.55rem 1.45rem 1.4rem;
  border-radius: 1.15rem;
  text-align: left;
  background: linear-gradient(165deg, rgba(16,40,64,0.82) 0%, rgba(10,24,42,0.88) 100%);
  border: 1px solid rgba(27,184,166,0.28);
  box-shadow:
    0 0 0 1px rgba(27,184,166,0.08),
    0 0 40px rgba(27,184,166,0.12),
    0 28px 64px rgba(0,0,0,0.5);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  animation: rpmaACardIn 0.7s ease-out both;
}
@keyframes rpmaACardIn {
  from { opacity: 0; transform: translateY(12px) scale(0.98); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
.rpma-a-glass h2 {
  margin: 0;
  font-size: 1.45rem;
  font-weight: 700;
  color: #fff;
}
.rpma-a-glass-sub {
  margin: 0.35rem 0 0;
  font-size: 0.82rem;
  color: rgba(180,210,230,0.72);
}
.rpma-a-form {
  margin-top: 1.15rem;
  display: flex;
  flex-direction: column;
  gap: 0.9rem;
}
.rpma-a-label {
  display: block;
  margin-bottom: 0.35rem;
  font-size: 0.78rem;
  font-weight: 600;
  color: rgba(220,235,250,0.88);
}
.rpma-a-field {
  position: relative;
  display: flex;
  align-items: center;
}
.rpma-a-field > svg:first-child {
  position: absolute;
  left: 0.75rem;
  color: rgba(140,180,210,0.75);
  pointer-events: none;
}
.rpma-a-field input {
  width: 100%;
  height: 2.65rem;
  padding: 0 0.9rem 0 2.35rem;
  border-radius: 0.7rem;
  border: 1px solid rgba(100,160,200,0.22);
  background: rgba(6,16,28,0.72);
  color: #f0f7ff;
  font-size: 0.9rem;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.rpma-a-field input:focus {
  border-color: rgba(27,184,166,0.55);
  box-shadow: 0 0 0 3px rgba(27,184,166,0.15);
}
.rpma-a-field--pw input { padding-right: 2.5rem; }
.rpma-a-eye {
  position: absolute;
  right: 0.45rem;
  background: transparent;
  border: none;
  color: rgba(160,190,210,0.8);
  cursor: pointer;
  display: inline-flex;
  padding: 0.35rem;
}
.rpma-a-err { margin: 0; color: #f87171; font-size: 0.82rem; }
.rpma-a-submit {
  height: 2.75rem;
  border: none;
  border-radius: 0.7rem;
  background: linear-gradient(90deg, #0d9488 0%, #1bb8a6 50%, #14b8a6 100%);
  color: #042f2e;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.45rem;
  box-shadow: 0 8px 24px rgba(27,184,166,0.3);
  transition: transform 0.15s, box-shadow 0.2s, opacity 0.15s;
}
.rpma-a-submit:hover:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: 0 12px 28px rgba(27,184,166,0.4);
}
.rpma-a-submit:disabled { opacity: 0.7; cursor: wait; }

.rpma-a-footer {
  position: absolute;
  bottom: 1.1rem;
  left: 0;
  right: 0;
  z-index: 10;
  text-align: center;
  margin: 0;
  font-size: 0.8rem;
  color: rgba(180,210,230,0.5);
}

@media (max-width: 720px) {
  .rpma-a-chips { display: none; }
  .rpma-a-sql { opacity: 0.35; }
}
@media (prefers-reduced-motion: reduce) {
  .rpma-a-sql-track,
  .rpma-a-chip,
  .rpma-a-mark,
  .rpma-a-glass {
    animation: none !important;
  }
}
`;

function sqlClass(line: string): string {
  const s = line.trim();
  if (!s) return "";
  if (s.startsWith("--")) return "is-c";
  if (/^(USE|GO|SET|SELECT|FROM|WHERE|LEFT|ORDER|GROUP|PRINT|AND)\b/i.test(s)) return "is-kw";
  if (s.includes("N'") || s.includes("'")) return "is-s";
  return "";
}

function SqlBg() {
  const block = [...SQL_LINES, "", ...SQL_LINES, "", ...SQL_LINES];
  return (
    <div className="rpma-a-sql" aria-hidden="true" data-login-sql={LOGIN_SKIN}>
      {[0, 1, 2].map((col) => (
        <div key={col} className={`rpma-a-sql-col rpma-a-sql-col--${col + 1}`}>
          <div className="rpma-a-sql-track">
            {block.map((line, i) => (
              <div key={`${col}-${i}`} className={`rpma-a-sql-line ${sqlClass(line)}`}>
                <span className="rpma-a-sql-g">
                  {String((i % SQL_LINES.length) + 1).padStart(2, "0")}
                </span>
                <span className="rpma-a-sql-t">{line || " "}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({ email: loginEmail, password });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rpma-a-root" data-login-skin={LOGIN_SKIN}>
      <style>{OPTION_A_CSS}</style>
      <SqlBg />
      <div className="rpma-a-vignette" aria-hidden="true" />

      <div className="rpma-a-chips" aria-hidden="true">
        {CHIPS.map((c) => (
          <span key={c.text} className={c.cls}>
            <i className="rpma-a-chip-dot" />
            {c.text}
          </span>
        ))}
      </div>

      <div className="rpma-a-center">
        <div style={{ textAlign: "center" }}>
          <div className="rpma-a-mark">
            <RpmAssureMark size={100} showWordmark={false} />
          </div>
          <h1 className="rpma-a-title">
            <span className="rpma-a-rpm">RPM</span>{" "}
            <span className="rpma-a-assure">Assure</span>
          </h1>
          <p className="rpma-a-tag">Assurance Delivered</p>
        </div>

        <div className="rpma-a-glass">
          <IdleLogoutBanner />
          <h2>Sign in</h2>
          <p className="rpma-a-glass-sub">Welcome back. Sign in to continue.</p>

          {!authEnabled ? (
            <p className="rpma-a-err" style={{ marginTop: 12 }}>
              Auth is disabled.
            </p>
          ) : (
            <form className="rpma-a-form" onSubmit={onSignIn}>
              <label>
                <span className="rpma-a-label">Email or username</span>
                <span className="rpma-a-field">
                  <User size={16} />
                  <input
                    type="text"
                    required
                    placeholder="Email or username"
                    autoComplete="username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </span>
              </label>

              <label>
                <span className="rpma-a-label">Password</span>
                <span className="rpma-a-field rpma-a-field--pw">
                  <Lock size={16} />
                  <input
                    type={showPw ? "text" : "password"}
                    required
                    minLength={8}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="rpma-a-eye"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    tabIndex={-1}
                  >
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </span>
              </label>

              {error ? <p className="rpma-a-err">{error}</p> : null}

              <button type="submit" className="rpma-a-submit" disabled={busy}>
                <Lock size={16} strokeWidth={2.25} />
                {busy ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}
        </div>
      </div>

      <p className="rpma-a-footer">Powered by RPM Resources</p>
    </div>
  );
}
