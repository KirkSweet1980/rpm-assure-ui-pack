Option A animated skin. Apply then private window ?v=anim
