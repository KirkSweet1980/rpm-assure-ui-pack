import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RpmAssureMark } from "@/components/brand/rpm-assure-mark";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

/** Option E — Bioluminescent streams (silent CSS only) */
const LOGIN_SKIN = "option-e-bio";

const BUBBLES: {
  text: string;
  top: string;
  left?: string;
  right?: string;
  size: number;
  delay: string;
  duration: string;
}[] = [
  { text: "clarity", top: "12%", left: "8%", size: 92, delay: "0s", duration: "7s" },
  { text: "insight", top: "38%", left: "4%", size: 78, delay: "1.2s", duration: "8.5s" },
  { text: "evidence", top: "68%", left: "10%", size: 86, delay: "0.5s", duration: "6.5s" },
  { text: "confidence", top: "16%", right: "7%", size: 88, delay: "0.8s", duration: "7.8s" },
  { text: "visibility", top: "48%", right: "5%", size: 80, delay: "1.6s", duration: "9s" },
  { text: "source of truth", top: "74%", right: "9%", size: 100, delay: "0.3s", duration: "8s" },
];

const STREAM_LINES = [
  "SELECT c.CustomerCode, h.HealthRag, h.HealthScorePct FROM dbo.vw_Kpi_Customer_Health_Latest h",
  "JOIN dbo.Dim_Customer c ON c.CustomerCode = h.CustomerCode WHERE c.Active = 1",
  "SELECT DeviceName, LastBackupStatus, UsedBytes FROM dbo.Cove_DeviceStatistics WHERE SnapshotDate = @AsOf",
  "SELECT COUNT(*) OfflineServers FROM dbo.Pulseway_Devices WHERE IsOnline = 0 AND DeviceClass = N'Server'",
  "PRINT N'Query complete — assurance delivered.'; GO",
  "SELECT e.CustomerCode, COUNT(*) Endpoints FROM dbo.Bitdefender_Endpoints e GROUP BY e.CustomerCode",
];

const OPTION_E_CSS = `
.rpma-e-root {
  position: relative;
  min-height: 100dvh;
  width: 100%;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background:
    radial-gradient(ellipse 90% 70% at 50% -10%, rgba(20,120,140,0.35) 0%, transparent 50%),
    radial-gradient(ellipse 60% 40% at 20% 80%, rgba(27,184,166,0.12) 0%, transparent 55%),
    radial-gradient(ellipse 50% 35% at 85% 70%, rgba(15,90,120,0.18) 0%, transparent 50%),
    linear-gradient(180deg, #031018 0%, #050d18 40%, #020810 100%);
  color: #e8f4ff;
  isolation: isolate;
}

/* Light rays from top */
.rpma-e-rays {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  background:
    linear-gradient(118deg, transparent 40%, rgba(27,184,166,0.07) 48%, transparent 56%),
    linear-gradient(98deg, transparent 42%, rgba(80,200,220,0.05) 50%, transparent 58%),
    linear-gradient(135deg, transparent 38%, rgba(27,184,166,0.06) 46%, transparent 54%);
  animation: rpmaERays 8s ease-in-out infinite alternate;
  mix-blend-mode: screen;
}
@keyframes rpmaERays {
  from { opacity: 0.55; transform: translateX(-2%) scale(1); }
  to { opacity: 1; transform: translateX(2%) scale(1.03); }
}

/* Fiber / SQL streams */
.rpma-e-streams {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  overflow: hidden;
}
.rpma-e-stream {
  position: absolute;
  left: -20%;
  width: 140%;
  height: 2px;
  border-radius: 2px;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(27,184,166,0.05) 10%,
    rgba(80,220,230,0.55) 40%,
    rgba(27,184,166,0.75) 50%,
    rgba(80,220,230,0.45) 60%,
    rgba(27,184,166,0.05) 90%,
    transparent 100%
  );
  box-shadow: 0 0 12px rgba(27,184,166,0.45), 0 0 28px rgba(27,184,166,0.2);
  animation: rpmaEStream linear infinite;
  will-change: transform;
}
.rpma-e-stream::after {
  content: attr(data-sql);
  position: absolute;
  left: 8%;
  top: -1.1rem;
  font-family: Consolas, "Courier New", monospace;
  font-size: 10px;
  color: rgba(140,230,240,0.28);
  white-space: nowrap;
  letter-spacing: 0.02em;
}
.rpma-e-stream:nth-child(1) { top: 14%; animation-duration: 14s; opacity: 0.7; }
.rpma-e-stream:nth-child(2) { top: 28%; animation-duration: 18s; animation-direction: reverse; opacity: 0.55; height: 1.5px; }
.rpma-e-stream:nth-child(3) { top: 42%; animation-duration: 12s; opacity: 0.8; }
.rpma-e-stream:nth-child(4) { top: 58%; animation-duration: 16s; animation-direction: reverse; opacity: 0.5; }
.rpma-e-stream:nth-child(5) { top: 72%; animation-duration: 13s; opacity: 0.65; }
.rpma-e-stream:nth-child(6) { top: 86%; animation-duration: 20s; animation-direction: reverse; opacity: 0.45; height: 1.5px; }
@keyframes rpmaEStream {
  0% { transform: translate3d(-8%, 0, 0); }
  100% { transform: translate3d(8%, 0, 0); }
}

/* Floating particles */
.rpma-e-particles {
  position: absolute;
  inset: 0;
  z-index: 2;
  pointer-events: none;
  overflow: hidden;
}
.rpma-e-particle {
  position: absolute;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(120,240,230,0.7);
  box-shadow: 0 0 8px rgba(27,184,166,0.8);
  animation: rpmaEParticle linear infinite;
}
@keyframes rpmaEParticle {
  0% { transform: translate3d(0, 20px, 0); opacity: 0; }
  15% { opacity: 0.9; }
  85% { opacity: 0.7; }
  100% { transform: translate3d(12px, -100vh, 0); opacity: 0; }
}

/* Word bubbles */
.rpma-e-bubbles {
  position: absolute;
  inset: 0;
  z-index: 3;
  pointer-events: none;
}
.rpma-e-bubble {
  position: absolute;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  border: 1px solid rgba(120,230,240,0.35);
  background:
    radial-gradient(circle at 35% 30%, rgba(180,255,250,0.18) 0%, transparent 45%),
    radial-gradient(circle at 50% 50%, rgba(20,60,80,0.35) 0%, rgba(8,28,40,0.55) 70%);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  box-shadow:
    inset 0 0 20px rgba(100,220,230,0.15),
    0 0 24px rgba(27,184,166,0.2),
    0 8px 24px rgba(0,0,0,0.25);
  color: rgba(200,255,250,0.85);
  font-size: clamp(0.65rem, 1.1vw, 0.82rem);
  font-weight: 650;
  letter-spacing: 0.04em;
  text-transform: lowercase;
  text-align: center;
  padding: 0.5rem;
  line-height: 1.2;
  animation: rpmaEBubble ease-in-out infinite;
  will-change: transform;
}
@keyframes rpmaEBubble {
  0%, 100% { transform: translate3d(0, 0, 0) scale(1); }
  50% { transform: translate3d(0, -14px, 0) scale(1.04); }
}

/* Center portal */
.rpma-e-center {
  position: relative;
  z-index: 10;
  width: min(400px, 92vw);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  animation: rpmaEPortalIn 0.8s ease-out both;
}
@keyframes rpmaEPortalIn {
  from { opacity: 0; transform: translateY(16px) scale(0.97); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
.rpma-e-mark {
  filter: drop-shadow(0 0 22px rgba(27,184,166,0.55));
  animation: rpmaEMark 3.5s ease-in-out infinite;
}
@keyframes rpmaEMark {
  0%, 100% { transform: scale(1); filter: drop-shadow(0 0 16px rgba(27,184,166,0.4)); }
  50% { transform: scale(1.05); filter: drop-shadow(0 0 32px rgba(27,184,166,0.7)); }
}
.rpma-e-title {
  margin: 0;
  font-size: clamp(2rem, 4.5vw, 2.7rem);
  font-weight: 800;
  letter-spacing: -0.03em;
  text-align: center;
}
.rpma-e-title .rpm { color: #fff; }
.rpma-e-title .assure {
  color: #1bb8a6;
  text-shadow: 0 0 30px rgba(27,184,166,0.4);
}
.rpma-e-tag {
  margin: 0;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.28em;
  text-transform: uppercase;
  color: rgba(27,184,166,0.85);
}

.rpma-e-glass {
  width: 100%;
  max-width: 24rem;
  padding: 1.55rem 1.45rem 1.4rem;
  border-radius: 1.25rem;
  background:
    linear-gradient(165deg, rgba(20,50,70,0.55) 0%, rgba(8,24,40,0.72) 100%);
  border: 1px solid rgba(100,220,230,0.28);
  box-shadow:
    0 0 0 1px rgba(27,184,166,0.08),
    0 0 48px rgba(27,184,166,0.15),
    0 28px 64px rgba(0,0,0,0.45),
    inset 0 1px 0 rgba(200,255,250,0.1);
  backdrop-filter: blur(22px);
  -webkit-backdrop-filter: blur(22px);
}
.rpma-e-glass h2 {
  margin: 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #fff;
  text-align: center;
}
.rpma-e-glass-sub {
  margin: 0.35rem 0 0;
  font-size: 0.8rem;
  color: rgba(180,220,230,0.7);
  text-align: center;
}
.rpma-e-form {
  margin-top: 1.15rem;
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}
.rpma-e-label {
  display: block;
  margin-bottom: 0.3rem;
  font-size: 0.75rem;
  font-weight: 600;
  color: rgba(200,230,235,0.85);
}
.rpma-e-field {
  position: relative;
  display: flex;
  align-items: center;
}
.rpma-e-field > svg:first-of-type {
  position: absolute;
  left: 0.75rem;
  color: rgba(140,200,210,0.75);
  pointer-events: none;
}
.rpma-e-field input {
  width: 100%;
  height: 2.65rem;
  padding: 0 0.9rem 0 2.35rem;
  border-radius: 0.7rem;
  border: 1px solid rgba(100,180,200,0.22);
  background: rgba(4,16,28,0.65);
  color: #f0f7ff;
  font-size: 0.9rem;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.rpma-e-field input:focus {
  border-color: rgba(27,184,166,0.6);
  box-shadow: 0 0 0 3px rgba(27,184,166,0.16), 0 0 20px rgba(27,184,166,0.12);
}
.rpma-e-field--pw input { padding-right: 2.5rem; }
.rpma-e-eye {
  position: absolute;
  right: 0.4rem;
  background: transparent;
  border: none;
  color: rgba(160,200,210,0.8);
  cursor: pointer;
  display: inline-flex;
  padding: 0.35rem;
}
.rpma-e-err { margin: 0; color: #f87171; font-size: 0.82rem; }
.rpma-e-submit {
  height: 2.75rem;
  margin-top: 0.2rem;
  border: none;
  border-radius: 0.7rem;
  background: linear-gradient(90deg, #0d9488 0%, #1bb8a6 50%, #2dd4bf 100%);
  color: #042f2e;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.4rem;
  animation: rpmaEBtn 2.4s ease-in-out infinite;
}
@keyframes rpmaEBtn {
  0%, 100% { box-shadow: 0 8px 24px rgba(27,184,166,0.3); }
  50% { box-shadow: 0 10px 36px rgba(45,212,191,0.55); }
}
.rpma-e-submit:hover:not(:disabled) { transform: translateY(-1px); }
.rpma-e-submit:disabled { opacity: 0.7; cursor: wait; animation: none; }

.rpma-e-footer {
  position: absolute;
  bottom: 1.1rem;
  left: 0;
  right: 0;
  z-index: 10;
  text-align: center;
  margin: 0;
  font-size: 0.78rem;
  color: rgba(160,210,220,0.45);
}

@media (max-width: 720px) {
  .rpma-e-bubble { transform: scale(0.85); }
  .rpma-e-stream::after { display: none; }
}
@media (prefers-reduced-motion: reduce) {
  .rpma-e-rays, .rpma-e-stream, .rpma-e-particle, .rpma-e-bubble,
  .rpma-e-mark, .rpma-e-submit, .rpma-e-center {
    animation: none !important;
  }
}
`;

function BioBackdrop() {
  const particles = Array.from({ length: 18 }, (_, i) => ({
    id: i,
    left: `${(i * 17 + 7) % 100}%`,
    delay: `${(i * 0.45) % 8}s`,
    duration: `${10 + (i % 6)}s`,
    size: 2 + (i % 3),
  }));

  return (
    <>
      <div className="rpma-e-rays" aria-hidden="true" />
      <div className="rpma-e-streams" aria-hidden="true">
        {STREAM_LINES.map((line, i) => (
          <div
            key={i}
            className="rpma-e-stream"
            data-sql={line}
            style={{ animationDelay: `${i * -2.2}s` }}
          />
        ))}
      </div>
      <div className="rpma-e-particles" aria-hidden="true">
        {particles.map((p) => (
          <span
            key={p.id}
            className="rpma-e-particle"
            style={{
              left: p.left,
              bottom: "-4px",
              width: p.size,
              height: p.size,
              animationDelay: p.delay,
              animationDuration: p.duration,
            }}
          />
        ))}
      </div>
      <div className="rpma-e-bubbles" aria-hidden="true">
        {BUBBLES.map((b) => (
          <span
            key={b.text}
            className="rpma-e-bubble"
            style={{
              top: b.top,
              left: b.left,
              right: b.right,
              width: b.size,
              height: b.size,
              animationDuration: b.duration,
              animationDelay: b.delay,
            }}
          >
            {b.text}
          </span>
        ))}
      </div>
    </>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({ email: loginEmail, password });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rpma-e-root" data-login-skin={LOGIN_SKIN}>
      <style>{OPTION_E_CSS}</style>
      <BioBackdrop />

      <div className="rpma-e-center">
        <div className="rpma-e-mark">
          <RpmAssureMark size={96} showWordmark={false} />
        </div>
        <h1 className="rpma-e-title">
          <span className="rpm">RPM</span>{" "}
          <span className="assure">Assure</span>
        </h1>
        <p className="rpma-e-tag">Assurance Delivered</p>

        <div className="rpma-e-glass">
          <IdleLogoutBanner />
          <h2>Sign in</h2>
          <p className="rpma-e-glass-sub">Welcome back. Secure access for RPM staff.</p>

          {!authEnabled ? (
            <p className="rpma-e-err" style={{ marginTop: 12 }}>
              Auth is disabled.
            </p>
          ) : (
            <form className="rpma-e-form" onSubmit={onSignIn}>
              <label>
                <span className="rpma-e-label">Email or username</span>
                <span className="rpma-e-field">
                  <User size={16} />
                  <input
                    type="text"
                    required
                    placeholder="Email or username"
                    autoComplete="username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </span>
              </label>

              <label>
                <span className="rpma-e-label">Password</span>
                <span className="rpma-e-field rpma-e-field--pw">
                  <Lock size={16} />
                  <input
                    type={showPw ? "text" : "password"}
                    required
                    minLength={8}
                    placeholder="Password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="rpma-e-eye"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    tabIndex={-1}
                  >
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </span>
              </label>

              {error ? <p className="rpma-e-err">{error}</p> : null}

              <button type="submit" className="rpma-e-submit" disabled={busy}>
                <Lock size={16} strokeWidth={2.25} />
                {busy ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}
        </div>
      </div>

      <p className="rpma-e-footer">Powered by RPM Resources</p>
    </div>
  );
}
