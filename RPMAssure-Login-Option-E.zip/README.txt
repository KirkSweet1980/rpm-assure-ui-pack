Option E Bioluminescent streams.
Do not Expand-Archive into Downloads (AV locks .ps1).
Use the PowerShell stream install from chat.
