﻿# Apply-Epp-Dedupe-Endpoints.ps1
$ErrorActionPreference = 'Stop'
$App = 'C:\RPM-Assure\App'
$SqlRoot = 'C:\RPM-Assure\Sql\bitdefender'
$Server = '102.222.21.220,14333'
$Db = 'RPMAssure_App'

Write-Host '=== EPP endpoint de-dupe (FQDN/IP) ===' -ForegroundColor Cyan

function Find-Sqlcmd {
  $c = Get-Command sqlcmd -EA SilentlyContinue
  if ($c) { return $c.Source }
  foreach ($p in @(
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\SQLCMD.EXE',
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\130\Tools\Binn\SQLCMD.EXE'
  )) { if (Test-Path $p) { return $p } }
  return $null
}

# Expect this script to be run after files already copied next to it, OR from pack folder
$pack = $PSScriptRoot
$lpSrc = Join-Path $pack 'App\src\lib\data\live-portfolio.ts'
if (-not (Test-Path $lpSrc)) { $lpSrc = Join-Path $pack 'live-portfolio.ts' }
if (-not (Test-Path $lpSrc)) { throw "live-portfolio.ts not found under $pack" }

$destLp = Join-Path $App 'src\lib\data\live-portfolio.ts'
$d = Split-Path $destLp -Parent
if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
Copy-Item -LiteralPath $lpSrc -Destination $destLp -Force
$mirror = 'C:\RPM-Assure\src\lib\data\live-portfolio.ts'
$md = Split-Path $mirror -Parent
if (-not (Test-Path $md)) { New-Item -ItemType Directory -Path $md -Force | Out-Null }
Copy-Item $destLp $mirror -Force
$txt = [IO.File]::ReadAllText($destLp)
foreach ($m in @('dedupeEppDevices','stripEppMacSuffix','eppDeviceIdentityKey')) {
  if ($txt -notlike "*$m*") { throw "Missing $m in live-portfolio" }
  Write-Host "  OK app $m" -ForegroundColor Green
}

# SQL 456
$sqlSrc = Join-Path $pack 'Sql\bitdefender\456_Dedupe_Epp_Endpoint_Views.sql'
if (-not (Test-Path $sqlSrc)) { $sqlSrc = Join-Path $pack '456_Dedupe_Epp_Endpoint_Views.sql' }
if (Test-Path $sqlSrc) {
  if (-not (Test-Path $SqlRoot)) { New-Item -ItemType Directory -Path $SqlRoot -Force | Out-Null }
  Copy-Item $sqlSrc (Join-Path $SqlRoot '456_Dedupe_Epp_Endpoint_Views.sql') -Force
  $sqlcmd = Find-Sqlcmd
  if ($sqlcmd) {
    Write-Host 'Apply 456 view as Windows auth...'
    & $sqlcmd -S $Server -d $Db -E -C -b -i $sqlSrc
    if ($LASTEXITCODE -ne 0) {
      Write-Host 'Windows auth failed — try Rpm_collect if permitted' -ForegroundColor Yellow
      & $sqlcmd -S $Server -d $Db -U 'Rpm_collect' -P 'RpmCollect#AHIC2026' -C -b -i $sqlSrc
    }
  } else { Write-Host 'sqlcmd not found — skip 456' -ForegroundColor Yellow }
}

# Collect script
$collSrc = Join-Path $pack 'Sql\bitdefender\Collect-Bitdefender-To-RPMAssure.ps1'
if (-not (Test-Path $collSrc)) { $collSrc = Join-Path $pack 'Collect-Bitdefender-To-RPMAssure.ps1' }
if (Test-Path $collSrc) {
  if (-not (Test-Path $SqlRoot)) { New-Item -ItemType Directory -Path $SqlRoot -Force | Out-Null }
  Copy-Item $collSrc (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1') -Force
  Write-Host 'OK Collect script (host de-dupe on next collect)'
}

# Restart app
if (Test-Path (Join-Path $App 'node_modules\.vite')) {
  Remove-Item (Join-Path $App 'node_modules\.vite') -Recurse -Force
}
Get-Process node -EA SilentlyContinue | Stop-Process -Force -EA SilentlyContinue
Start-Sleep 3
Get-NetTCPConnection -LocalPort 8081 -EA SilentlyContinue | ForEach-Object {
  Stop-Process -Id $_.OwningProcess -Force -EA SilentlyContinue
}
Start-Sleep 2
$log = 'C:\RPM-Assure\deploy\logs'
New-Item -ItemType Directory -Force -Path $log | Out-Null
$cmd = "cd /d `"$App`" && npx.cmd vite dev --host 0.0.0.0 --port 8081 >> `"$log\app-stdout.log`" 2>> `"$log\app-stderr.log`""
Start-Process cmd.exe -ArgumentList '/c',$cmd -WorkingDirectory $App -WindowStyle Minimized
1..40 | ForEach-Object {
  Start-Sleep 1
  $l = Get-NetTCPConnection -LocalPort 8081 -State Listen -EA SilentlyContinue
  if ($l) { "LISTENING PID $($l[0].OwningProcess)"; break }
}

Write-Host 'Hard-refresh EPP Endpoints for AHIC — expect 6 not 12.' -ForegroundColor Cyan
Write-Host 'Optional re-collect: powershell -NoProfile -ExecutionPolicy Bypass -File C:\RPM-Assure\Sql\bitdefender\Collect-Bitdefender-To-RPMAssure.ps1'
Write-Host '=== Done ==='
