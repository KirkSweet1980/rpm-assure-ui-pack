EPP de-dupe: clean name + MAC twin -> one host. App + 456 view + collect.
Extract under C:\RPM-Assure\deploy not Downloads.
