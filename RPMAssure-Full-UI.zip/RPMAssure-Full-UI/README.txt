RPM Assure - Full UI deploy
===========================

1. Copy this folder (or the ZIP contents) to the APP SERVER.
2. Open Administrator PowerShell.
3. Run:

   powershell -NoProfile -ExecutionPolicy Bypass -File "C:\path\to\Install-RpmAssure-Full-UI.ps1"

What it does
- Stops RPMAssure-App
- Backs up C:\RPM-Assure\App\src
- Replaces src (and public brand files)
- Starts the service
- Hits /login as proof

Does not change SQL, collect, .env, or node_modules.

After deploy: hard-refresh the browser (Ctrl+F5).
