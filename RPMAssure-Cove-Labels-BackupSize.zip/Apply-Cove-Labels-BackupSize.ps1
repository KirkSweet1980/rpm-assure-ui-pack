# Apply-Cove-Labels-BackupSize.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = 'C:\RPM-Assure\App'
$pairs = @(
  'src\components\nav\customer-workspace-nav.tsx',
  'src\lib\nav\site-tree.ts',
  'src\routes\customers.$code.tsx',
  'src\routes\customers.$code.cove.index.tsx',
  'src\routes\customers.$code.cove.overview.tsx',
  'src\components\customer\customer-sections.tsx',
  'src\lib\data\live-portfolio.ts',
  'src\lib\data\types.ts'
)
foreach ($rel in $pairs) {
  $s = Join-Path $Here ('App\' + $rel)
  $d = Join-Path $AppRoot $rel
  if (-not (Test-Path -LiteralPath $s)) { Write-Host "SKIP $s"; continue }
  $dir = Split-Path -Parent $d
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  Copy-Item -LiteralPath $s -Destination $d -Force
  Write-Host "OK $d"
}
Write-Host 'Restart app...'
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 6
} catch { Write-Host $_ }
Write-Host 'Hard-refresh RPM Cloud Backup. Modules: Device on Cloud Backup | Backup Recovery Testing.'
Write-Host '=== Done ==='
