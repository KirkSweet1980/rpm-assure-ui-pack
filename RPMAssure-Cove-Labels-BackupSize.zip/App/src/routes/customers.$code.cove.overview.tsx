import { createFileRoute } from "@tanstack/react-router";
import { CoveDevicesSection } from "@/components/customer/customer-sections";
import { Route as CustomerRoute } from "./customers.$code";

/** Legacy /cove/overview — Device stats removed; show Device on Cloud Backup */
export const Route = createFileRoute("/customers/$code/cove/overview")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return <p className="text-sm text-muted">Loading customer workspace…</p>;
    }
    return <CoveDevicesSection data={data} />;
  },
});
