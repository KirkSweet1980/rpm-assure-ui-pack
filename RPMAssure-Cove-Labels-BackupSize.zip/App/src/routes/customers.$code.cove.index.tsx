import { createFileRoute } from "@tanstack/react-router";
import { CoveDevicesSection } from "@/components/customer/customer-sections";
import { Route as CustomerRoute } from "./customers.$code";

export const Route = createFileRoute("/customers/$code/cove/")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return (
        <p className="text-sm text-muted">
          Loading customer workspace… If this stays blank, use Refresh in the top bar.
        </p>
      );
    }
    return <CoveDevicesSection data={data} />;
  },
});
