export type HealthRag = "Red" | "Amber" | "Green";

/** Which managed services are in scope for this customer */
export type CustomerCover = {
  syspro: boolean;
  rmm: boolean;
  cove: boolean;
  /** Endpoint protection (Bitdefender / RPM EPP) — future collect */
  epp?: boolean;
  /** Microsoft CSP / 365 licensing — future collect */
  csp?: boolean;
};


export type PortfolioRow = {
  customerCode: string;
  displayName: string;
  active?: boolean;
  sqlInstanceName?: string | null;
  asOfDate: string | null;
  healthRag: HealthRag;
  healthSummary: string;
  operatorCount: number;
  activeUserCount: number;
  lastImportAt: string | null;
  sysproJobErrorCount: number;
  sysproDtrVarianceLines: number;
  reportingPeriod?: string | null;
  coveDeviceCount?: number;
  coveFailedDeviceCount?: number;
  coveStaleDeviceCount?: number;
  coveOkDeviceCount?: number;
  coveLastImportAt?: string | null;
  pulsewayOfflineCount?: number;
  pulsewayDeviceCount?: number;
  pulsewayOnlineCount?: number;
  pulsewayCriticalAlerts?: number;
  pulsewayElevatedAlerts?: number;
  pulsewayLastImportAt?: string | null;
  pulsewayOrgName?: string | null;
  pulsewayHealthRag?: HealthRag | null;
  pulsewayHealthSummary?: string | null;
  /** Server agents online (latest Pulseway snap) */
  pulsewayServerOnline?: number;
  pulsewayServerOffline?: number;
  /** Workstation agents online / offline */
  pulsewayWorkstationOnline?: number;
  pulsewayWorkstationOffline?: number;
  bdInfectedCount?: number;
  eppDeviceCount?: number;
  eppManagedCount?: number;
  eppLastImportAt?: string | null;
  /** Explicit service cover — false = show "No cover", do not score health */
  cover?: CustomerCover;
  pillarSyspro?: boolean | null;
  pillarPulseway?: boolean | null;
  pillarCove?: boolean | null;
  /** Maps from Dim_Customer_AmsConfig.PillarBitdefender */
  pillarEpp?: boolean | null;
  pillarCsp?: boolean | null;
};

export type OperatorRow = {
  operatorCode: string;
  operatorName: string | null;
  networkUser?: string | null;
  email?: string | null;
  active?: boolean | null;
  lastLoginDate: string | null;
  groupCode?: string | null;
  operatorStatus?: string | null;
  snapshotDate?: string | null;
};

export type JobErrorRow = {
  programName: string | null;
  operator: string | null;
  message: string | null;
  errorStatusCode: string | null;
  progErrorCode: number | null;
  progRunDate: string | null;
  companyDb?: string | null;
};

export type DtrLevel1Row = {
  balanceTypeCode: string;
  balanceTypeName: string;
  varianceLineCount: number;
  sumVariance?: number | null;
  absVariance?: number | null;
  closeBalance?: number | null;
  lineCount?: number | null;
  totalLineCount?: number | null;
  totalCloseBalance?: number | null;
  totalVariance?: number | null;
  snapshotDate?: string | null;
  asOfDate?: string | null;
};

/** FinSight L1/L2/L3 line (control drill-down) */
export type DtrDetailLine = {
  balanceTypeCode: string;
  informationLevel: 1 | 2 | 3 | number;
  levelKey: string | null;
  parentLevelKey: string | null;
  glCode: string | null;
  dimension1: string | null;
  description: string | null;
  subCloseBalance: number | null;
  glCloseBalance: number | null;
  variance: number | null;
  snapshotDate: string | null;
  companyDb?: string | null;
};

export type FinSightReconStatus =
  | "Open"
  | "Investigating"
  | "WaitingFinance"
  | "Cleared"
  | "Accepted"
  | "Closed";

export type FinSightReconCase = {
  reconCaseId: string;
  customerCode: string;
  balanceTypeCode: string;
  snapshotDate: string | null;
  status: FinSightReconStatus;
  oobLines: number;
  absVariance: number | null;
  closeBalance: number | null;
  ownerName: string | null;
  title: string;
  notes: string | null;
  sourceLevel: number | null;
  levelKey: string | null;
  createdAtUtc: string | null;
  updatedAtUtc: string | null;
};

export type FinSightReconStep = {
  reconStepId: string;
  reconCaseId: string;
  stepAtUtc: string | null;
  actorName: string | null;
  fromStatus: string | null;
  toStatus: string;
  note: string | null;
};

export type PortfolioSummary = {
  totalCustomers: number;
  red: number;
  amber: number;
  green: number;
  totalActiveUsers: number;
  totalOperators: number;
  generatedAt: string;
  dataMode?: "demo" | "live" | "mixed";
};

export type CoveUnmappedPartner = {
  partnerName: string;
  partnerId: number | null;
  deviceCount: number;
  lastSnapshotDate: string | null;
  lastImportAt: string | null;
};

export type PortfolioPayload = {
  summary: PortfolioSummary;
  customers: PortfolioRow[];
  rows: PortfolioRow[];
  dataMode?: "demo" | "live" | "mixed";
  sqlError?: string | null;
  exco?: ExcoInsightPayload;
  coveUnmapped?: CoveUnmappedPartner[];
};

export type LicenseRow = {
  productName: string | null;
  productVersion: string | null;
  licenseType: string | null;
  users: number | null;
  companyCount?: number | null;
  licenseExpiry: string | null;
  customerName: string | null;
  importDate: string | null;
};

export type HealthLogRow = {
  logDate?: string | null;
  severity?: string | null;
  message?: string | null;
  source?: string | null;
  healthFunction?: string | null;
  description?: string | null;
  runDateTime?: string | null;
  statusFlag?: string | null;
  operator?: string | null;
};

export type TaskGroupRow = {
  operatorCode: string | null;
  taskGroup: string | null;
  description?: string | null;
  autoRun?: number | null;
  stopIfError?: number | null;
};

export type TaskItemRow = {
  operatorCode: string | null;
  taskGroup: string | null;
  description: string | null;
  programName: string | null;
  taskType: string | null;
  sequenceNumber: number | null;
};

export type FactIncidentRow = {
  incidentId?: string | null;
  title: string;
  severity: string;
  status: string;
  priority?: string | null;
  openedAt?: string | null;
  firstResponseAt?: string | null;
  resolvedAt?: string | null;
  isMajor?: boolean;
  externalRef?: string | null;
  ownerName?: string | null;
  sourceSystem?: string | null;
  businessImpact?: string | null;
  respondMins?: number | null;
  resolveMins?: number | null;
  responseMinsElapsed?: number | null;
  resolveMinsElapsed?: number | null;
  responseSlaMet?: boolean | null;
  resolveSlaMet?: boolean | null;
};

export type FactProblemRow = {
  title: string;
  status: string;
  severity: string | null;
  ownerName: string | null;
  openedAt?: string | null;
};

export type FactRiskRow = {
  title: string;
  rag: HealthRag | string;
  status: string;
  ownerName: string | null;
  targetDate?: string | null;
  mitigation?: string | null;
  category?: string | null;
};

export type FactIssueRow = {
  title: string;
  status: string;
  severity: string | null;
  ownerName: string | null;
  openedAt?: string | null;
  targetDate?: string | null;
};

export type FactPriorityRow = {
  title: string;
  detail: string | null;
  status: string;
  sortOrder: number;
  periodLabel: string | null;
  programCode: string | null;
};

export type SlaPolicyRow = {
  priority: string;
  respondMins: number | null;
  resolveMins: number | null;
  availabilityPct: number | null;
};

export type AvailabilitySlaSnapshot = {
  periodFrom: string | null;
  periodTo: string | null;
  availabilityPct: number | null;
  availabilitySlaPct: number | null;
  slaResponsePct: number | null;
  slaResolvePct: number | null;
  slaCompliancePct: number | null;
  source: "snapshot" | "stub" | "derived" | "live-incident" | "sla-period";
  /** Counts when source is live-incident */
  incidentCount30d?: number | null;
  responseBreachCount?: number | null;
  resolveBreachCount?: number | null;
  note?: string | null;
};

export type FactChangeRow = {
  title: string;
  status: string;
  outcome: string | null;
  completedAt: string | null;
};

export type FactCsatRow = {
  periodFrom: string | null;
  periodTo: string | null;
  score: number;
  responseCount: number | null;
  source: string | null;
};

export type OperGroupRow = {
  operatorCode: string | null;
  groupCode: string | null;
  groupName: string | null;
};

export type OperAmendRow = {
  operatorCode: string | null;
  amendDate: string | null;
  amendType: string | null;
  detail: string | null;
  changedBy: string | null;
};

export type AuditEventRow = {
  eventAt: string | null;
  operatorCode: string | null;
  programName: string | null;
  actionCode: string | null;
  detail: string | null;
};

export type DiagSummaryRow = {
  diagCode: string | null;
  diagName: string | null;
  severity: string | null;
  statusText: string | null;
  messageText: string | null;
  checkedAt: string | null;
};

export type SqlHealthRow = {
  companyDb: string | null;
  healthKey: string | null;
  description: string | null;
  statusText: string | null;
  refreshDate: string | null;
};

export type OperationalAssurance = {
  collectAgeHours: number | null;
  collectFresh: boolean;
  jobErrorCount: number;
  activeUserRatioPct: number | null;
  dtrOutOfBalance: number;
  scorePct: number;
  summary: string;
};

export type ExecSummaryRow = {
  periodFrom: string | null;
  periodTo: string | null;
  periodLabel: string | null;
  healthRag: string;
  healthSummary: string | null;
  businessImpactSummary: string | null;
  openRiskCount: number | null;
  openIssueCount: number | null;
  majorIncidentCount: number | null;
  status: string;
};

export type ExecNarrativeRow = {
  narrativeType: string;
  body: string;
  sortOrder: number;
};

export type SqlBackupRow = {
  databaseName: string;
  lastFullBackup: string | null;
  lastDiffBackup: string | null;
  lastLogBackup: string | null;
  lastBackupStatus: string | null;
  fullAgeHours: number | null;
};

export type SqlBackupFailureRow = {
  failureAt: string | null;
  jobName: string | null;
  databaseName: string | null;
  stepName: string | null;
  message: string | null;
};

export type SysproVersionInfo = {
  productName: string | null;
  productVersion: string | null;
  buildNumber: string | null;
  licenseType: string | null;
  users: number | null;
  companyCount?: number | null;
  licenseExpiry: string | null;
  customerName: string | null;
  serverName?: string | null;
  importDate: string | null;
};

export type SysproHotfixRow = {
  hotfixCode: string;
  hotfixName: string | null;
  description: string | null;
  installed: boolean;
  installedAt: string | null;
  sourceTable: string | null;
};

export type HotfixGapRow = {
  hotfixCode: string;
  title: string | null;
  severity: string | null;
  releaseLabel: string | null;
  isMissing: boolean;
  isWaived?: boolean;
  waiverReason?: string | null;
  installedAt: string | null;
  kbUrl: string | null;
};

export type HotfixGapSummary = {
  baselineCount: number;
  missingCount: number;
  installedMatchCount: number;
  missingMandatory: number;
  waivedMissingCount?: number;
  missingOptional?: number;
};

/** RMM leg — RPM RMM Management Agents (technical: Pulseway). Parallel to SYSPRO. */
export type RmmOrgSummary = {
  asOfDate: string | null;
  organizationName: string | null;
  deviceCount: number;
  onlineCount: number;
  offlineCount: number;
  maintenanceCount: number;
  criticalAlerts: number;
  elevatedAlerts: number;
  diskHighCount: number;
  serverCount: number;
  workstationCount: number;
  notificationCount: number;
  /** Online / offline split by class (from Pulseway_Devices) */
  serverOnline?: number;
  serverOffline?: number;
  workstationOnline?: number;
  workstationOffline?: number;
  healthRag: HealthRag;
  healthSummary: string;
  lastImportAt: string | null;
  /** Customer fleet disk totals (GB) from Pulseway_Disks */
  diskTotalGb?: number | null;
  diskFreeGb?: number | null;
  diskUsedGb?: number | null;
  /** Devices with at least one critical/elevated alert */
  devicesWithAlerts?: number | null;
  /** Max / avg days since reboot across devices with uptime */
  maxDaysSinceReboot?: number | null;
  avgDaysSinceReboot?: number | null;
  /** OS patch posture (agent) */
  patchInstalled?: number | null;
  patchMissing?: number | null;
  patchPending?: number | null;
  patchDevicesReporting?: number | null;
};

export type RmmDeviceRow = {
  deviceId: string;
  name: string | null;
  isOnline: boolean | null;
  osName: string | null;
  deviceType: string | null;
  criticalNotifications: number;
  elevatedNotifications: number;
  lastSeenOnline: string | null;
  organizationName: string | null;
  ipAddress?: string | null;
  cpuPct?: number | null;
  memoryPct?: number | null;
  onlinePct?: number | null;
  /** Days since last reboot (from Pulseway uptime text) */
  daysSinceReboot?: number | null;
  lastBootAt?: string | null;
  patchInstalled?: number | null;
  patchMissing?: number | null;
  patchPending?: number | null;
  disks?: {
    driveLetter: string;
    totalGb: number | null;
    freeGb: number | null;
    usedGb?: number | null;
    usedPct: number | null;
    /** SSD / NVMe / SAS / HDD when reported by agent */
    mediaType?: string | null;
  }[];
  /** Sum of disk used/free for this device */
  diskUsedGb?: number | null;
  diskFreeGb?: number | null;
  diskTotalGb?: number | null;
};

export type RmmAlertRow = {
  notificationId: string;
  deviceId: string | null;
  deviceName: string | null;
  severity: string | null;
  title: string | null;
  message: string | null;
  raisedAt: string | null;
  isActive: boolean | null;
};

export type RmmOrgMapRow = {
  organizationName: string;
  organizationId: number | null;
  active: boolean;
  notes: string | null;
};


export type CoveDeviceRow = {
  accountId?: string | number | null;
  deviceName?: string | null;
  machineName?: string | null;
  partnerName?: string | null;
  partnerId?: number | null;
  lastBackupStatus?: string | null;
  lastSuccessTime?: string | null;
  usedBytes?: number | null;
  /** Selected backup size when UsedBytes empty */
  selectedBytes?: number | null;
  snapshotDate?: string | null;
  importedAt?: string | null;
  /** I80: 0 none, 1 Recovery Testing, 2 Standby Image */
  recoveryPlanType?: number | null;
  recoveryPlanLabel?: string | null;
  /** F19 raw / short verification text */
  recoveryVerification?: string | null;
  /** Success | Failed | Unknown | NotInPlan | InProgress | NotStarted */
  recoveryTestStatus?: string | null;
  physicality?: string | null;
  /** Last VDR restore / recovery test completion (RVO/RVL) */
  lastRecoveryTestAt?: string | null;
};

export type CovePartnerMapRow = {
  partnerName: string;
  partnerId: number | null;
  active: boolean;
  notes: string | null;
  customerCode?: string | null;
};

export type CoveRecoverySummary = {
  deviceCount: number;
  recoveryTestingCount: number;
  standbyImageCount: number;
  noPlanCount: number;
  testSuccessCount: number;
  testFailedCount: number;
  testUnknownCount: number;
  lastImportAt?: string | null;
  asOfDate?: string | null;
  lastRecoveryTestAt?: string | null;
};

export type CoveSummary = {
  deviceCount: number;
  failedCount: number;
  staleCount: number;
  okCount: number;
  unknownCount?: number;
  lastImportAt?: string | null;
  lastSuccessAny?: string | null;
  asOfDate?: string | null;
  healthRag?: HealthRag | null;
  healthSummary?: string | null;
  recovery?: CoveRecoverySummary | null;
};

/** One collect day of Cove backup / recovery KPIs (last 7 days) */
export type CoveRecentDay = {
  snapshotDate: string;
  deviceCount: number;
  okCount: number;
  staleCount: number;
  failedCount: number;
  recoveryTestingCount: number;
  standbyImageCount: number;
  testSuccessCount: number;
  testFailedCount: number;
  lastSuccessAny?: string | null;
  lastRecoveryTestAt?: string | null;
};

export type CovePayload = {
  enabled: boolean;
  summary: CoveSummary | null;
  devices: CoveDeviceRow[];
  mapping: CovePartnerMapRow[];
  unmapped: CoveUnmappedPartner[];
  message: string | null;
  recovery?: CoveRecoverySummary | null;
  /** Last ~7 collect days of backup + recovery rollups (newest first) */
  recentDays?: CoveRecentDay[];
  /** Recovery-relevant device rows across last ~7 days */
  recoveryHistory?: CoveDeviceRow[];
  /** Stale / fail / recovery test banners */
  alerts?: Array<{ severity: "red" | "amber"; title: string; detail: string }>;
};

export type RmmPayload = {
  enabled: boolean;
  pillarOn: boolean;
  pulsewayOrgName: string | null;
  summary: RmmOrgSummary | null;
  devices: RmmDeviceRow[];
  alerts: RmmAlertRow[];
  mapping: RmmOrgMapRow[];
  message: string | null;
};

export type ExcoCustomerBoard = {
  customerCode: string;
  displayName: string;
  healthRag: HealthRag;
  healthSummary: string;
  healthScorePct: number;
  assuranceScorePct: number;
  collectAgeHours: number | null;
  collectFresh: boolean;
  lastImportAt: string | null;
  activeUserCount: number;
  operatorCount: number;
  jobErrorCount: number;
  dtrVarianceLines: number;
  slaCompliancePct: number | null;
  availabilityPct: number | null;
  licenseExpiry: string | null;
  licenseProduct: string | null;
  licenseDaysRemaining: number | null;
  openRiskCount: number;
  openIssueCount: number;
  lastFullBackup: string | null;
  backupStatus: string | null;
  backupHealthy: boolean | null;
  /** SYSPRO product version e.g. 8.10.0000 */
  sysproVersion: string | null;
  /** Build / DB version string */
  sysproBuild: string | null;
  /** Count of installed hotfixes on latest snapshot */
  installedHotfixCount: number;
  /** Latest InstalledAt among collected HFs */
  lastHotfixAt: string | null;
  /** Latest KB code for ExCo glance (not a "sample" product) */
  sampleHotfixCode: string | null;
  /** Real baseline missing total (gap view) */
  missingHotfixCount: number | null;
  /** Missing mandatory baseline KBs */
  missingMandatoryHotfixes: number | null;
  /** True when SYSPRO is Covered — ExCo hotfixes/licenses only for these */
  sysproCovered?: boolean;
  attentionReasons: string[];
  pulsewayDeviceCount?: number;
  pulsewayOnlineCount?: number;
  pulsewayOfflineCount?: number;
  pulsewayCriticalAlerts?: number;
  pulsewayElevatedAlerts?: number;
  pulsewayLastImportAt?: string | null;
  pulsewayOrgName?: string | null;
  pulsewayHealthRag?: HealthRag | null;
  pulsewayHealthSummary?: string | null;
  pulsewayServerOnline?: number;
  pulsewayServerOffline?: number;
  pulsewayWorkstationOnline?: number;
  pulsewayWorkstationOffline?: number;
};

export type ExcoInsightPayload = {
  generatedAt: string;
  estateAssurancePct: number;
  customersNeedingAttention: number;
  collectFreshCount: number;
  collectStaleCount: number;
  collectMissingCount: number;
  licensesExpiringSoon: number;
  openRisksTotal: number;
  openIssuesTotal: number;
  backupUnhealthyCount: number;
  /** Estate total installed hotfixes (sum of boards) */
  installedHotfixesTotal: number;
  /** Customers with at least one HF row */
  customersWithHotfixes: number;
  /** Customers missing HF collect (0 rows) */
  customersMissingHotfixes: number;
  rmmDevicesTotal?: number;
  rmmOfflineTotal?: number;
  rmmCriticalTotal?: number;
  rmmCustomersWithDevices?: number;
  rmmCustomersUnhealthy?: number;
  rmmServerOnlineTotal?: number;
  rmmServerOfflineTotal?: number;
  rmmWorkstationOnlineTotal?: number;
  rmmWorkstationOfflineTotal?: number;
  boards: ExcoCustomerBoard[];
};


export type EppDeviceRow = {
  endpointId: string;
  deviceName: string | null;
  fqdn: string | null;
  ipAddress: string | null;
  isManaged: boolean | null;
  machineType: number | null;
  operatingSystem: string | null;
  policyName: string | null;
  snapshotDate: string | null;
};

export type EppSummary = {
  deviceCount: number;
  managedCount: number;
  unmanagedCount: number;
  workstationCount: number;
  serverCount: number;
  lastImportAt: string | null;
  asOfDate: string | null;
};

export type EppIncidentRow = {
  incidentId: string;
  endpointId: string | null;
  deviceName: string | null;
  severity: string | null;
  status: string | null;
  incidentType: string | null;
  summary: string | null;
  detectedAt: string | null;
};

export type EppQuarantineRow = {
  itemId: string;
  endpointId: string | null;
  deviceName: string | null;
  threatName: string | null;
  filePath: string | null;
  status: string | null;
  quarantinedAt: string | null;
};

export type EppPayload = {
  enabled: boolean;
  summary: EppSummary | null;
  devices: EppDeviceRow[];
  message: string | null;
  license?: {
    usedSlots: number | null;
    totalSlots: number | null;
    endSubscription: string | null;
  } | null;
  incidents?: EppIncidentRow[];
  quarantine?: EppQuarantineRow[];
  feedStatus?: {
    incidentsOk: boolean | null;
    incidentsMessage: string | null;
    quarantineOk: boolean | null;
    quarantineMessage: string | null;
  } | null;
};

export type CustomerDetailPayload = {
  customer: PortfolioRow;
  /** Service cover for SYSPRO / RMM / Cove */
  cover?: CustomerCover;
  operators: OperatorRow[];
  recentLogins: OperatorRow[];
  jobErrors: JobErrorRow[];
  dtrLevel1: DtrLevel1Row[];
  /** L1–L3 detail lines for drill-down */
  dtrDetailLines?: DtrDetailLine[];
  /** Open / recent FinSight recon workflow cases */
  finsightReconCases?: FinSightReconCase[];
  license: LicenseRow | null;
  healthLogs: HealthLogRow[];
  taskGroups: TaskGroupRow[];
  taskItems: TaskItemRow[];
  incidents: FactIncidentRow[];
  problems: FactProblemRow[];
  risks: FactRiskRow[];
  issues: FactIssueRow[];
  priorities: FactPriorityRow[];
  slaPolicies: SlaPolicyRow[];
  availabilitySla: AvailabilitySlaSnapshot | null;
  /** Rolling 30d from Fact_Incident clocks */
  amsSlaSummary?: {
    incidentCount30d: number;
    openCount: number;
    majorOpenCount: number;
    responsePct: number | null;
    resolvePct: number | null;
    responseBreach: number;
    resolveBreach: number;
  } | null;
  changes: FactChangeRow[];
  csat: FactCsatRow | null;
  operGroups: OperGroupRow[];
  operAmends: OperAmendRow[];
  securitySummary: {
    groupMemberships: number;
    distinctOperatorsInGroups: number;
    distinctGroups: number;
    amendCount90d: number;
  };
  execSummary: ExecSummaryRow | null;
  execNarratives: ExecNarrativeRow[];
  auditEvents: AuditEventRow[];
  diagSummaries: DiagSummaryRow[];
  sqlHealthRows: SqlHealthRow[];
  extraSummary: {
    auditCount: number;
    diagCount: number;
    sqlHealthCount: number;
    sqlHealthFailCount: number;
    lastAuditImport: string | null;
  };
  operationalAssurance: OperationalAssurance;
  sqlBackups: SqlBackupRow[];
  sqlBackupFailures: SqlBackupFailureRow[];
  sysproVersion: SysproVersionInfo | null;
  sysproHotfixes: SysproHotfixRow[];
  hotfixGap: HotfixGapRow[];
  hotfixGapSummary: HotfixGapSummary | null;
  /** RMM leg (Pulseway) — same customer, different source */
  rmm: RmmPayload;
  /** Cyber Backup (Cove) */
  cove: CovePayload;
  /** RPM End Point Protection (Bitdefender GravityZone) */
  epp?: EppPayload | null;
  dataMode: "demo" | "live";
};
