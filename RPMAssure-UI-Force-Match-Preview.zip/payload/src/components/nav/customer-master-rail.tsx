import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { SpaLink } from "@/components/nav/spa-link";
import {
  filterMasterCustomers,
  useCustomerList,
  type MasterCustomer,
} from "@/lib/nav/customer-list-context";
import type { CustomerCover, HealthRag } from "@/lib/data/types";
import { cn } from "@/lib/utils";

const COVER_KEYS: { key: keyof CustomerCover; label: string }[] = [
  { key: "syspro", label: "S" },
  { key: "rmm", label: "R" },
  { key: "cove", label: "B" },
  { key: "epp", label: "E" },
  { key: "csp", label: "M" },
];

function healthDot(rag: HealthRag) {
  if (rag === "Green") return "bg-rag-green";
  if (rag === "Red") return "bg-rag-red";
  return "bg-rag-amber";
}

function CoverGlyphs({ cover }: { cover?: CustomerCover }) {
  return (
    <span className="rpma-d3-cover-glyphs" aria-hidden>
      {COVER_KEYS.map(({ key, label }) => {
        const on = cover?.[key] === true;
        return (
          <span
            key={key}
            className={cn("rpma-d3-cover-glyph", on && "is-on")}
            title={on ? `${key}: Cover` : `${key}: No Cover`}
          >
            {label}
          </span>
        );
      })}
    </span>
  );
}

function Row({
  c,
  active,
}: {
  c: MasterCustomer;
  active: boolean;
}) {
  return (
    <SpaLink
      href={`/customers/${encodeURIComponent(c.code)}`}
      className={cn("rpma-d3-master-row", active && "is-active")}
      aria-current={active ? "page" : undefined}
    >
      <span className={cn("rpma-d3-health-dot", healthDot(c.healthRag))} />
      <span className="rpma-d3-master-row-main min-w-0">
        <span className="rpma-d3-master-name truncate">{c.name}</span>
        <span className="rpma-d3-master-meta">
          <span className="font-mono">{c.code}</span>
          {c.opsAgeLabel ? (
            <span className="text-muted"> · {c.opsAgeLabel}</span>
          ) : null}
        </span>
      </span>
      <CoverGlyphs cover={c.cover} />
    </SpaLink>
  );
}

/**
 * D3 master rail — dense customer list for master–detail workspace.
 */
export function CustomerMasterRail({
  currentCode,
}: {
  currentCode: string;
}) {
  const { customers, loading } = useCustomerList();
  const [q, setQ] = useState("");

  const filtered = useMemo(
    () => filterMasterCustomers(customers, q),
    [customers, q],
  );

  const cur = currentCode.toUpperCase();

  return (
    <aside className="rpma-d3-master" aria-label="Customers">
      <div className="rpma-d3-master-head">
        <div className="flex items-center justify-between gap-2">
          <h2 className="rpma-d3-master-title">
            Customers
            <span className="rpma-d3-master-count">{customers.length}</span>
          </h2>
        </div>
        <label className="rpma-d3-master-search">
          <Search className="h-3.5 w-3.5 shrink-0 opacity-60" aria-hidden />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search customers…"
            autoComplete="off"
          />
        </label>
      </div>
      <div className="rpma-d3-master-list" role="list">
        {loading && customers.length === 0 ? (
          <p className="px-3 py-4 text-[12px] text-muted">Loading…</p>
        ) : filtered.length === 0 ? (
          <p className="px-3 py-4 text-[12px] text-muted">No matches.</p>
        ) : (
          filtered.map((c) => (
            <Row
              key={c.code}
              c={c}
              active={c.code.toUpperCase() === cur}
            />
          ))
        )}
      </div>
    </aside>
  );
}
