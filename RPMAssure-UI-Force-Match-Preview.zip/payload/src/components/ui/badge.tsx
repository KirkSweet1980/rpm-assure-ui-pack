import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold tracking-normal",
  {
    variants: {
      variant: {
        default: "border-border bg-surface-2 text-fg",
        muted: "border-border/60 bg-surface-2 text-muted",
        outline: "border-border text-muted",
        green: "border-rag-green/30 bg-rag-green-bg text-rag-green",
        amber: "border-rag-amber/30 bg-rag-amber-bg text-rag-amber",
        red: "border-rag-red/30 bg-rag-red-bg text-rag-red",
        nav: "border-transparent bg-white/15 text-nav-fg",
        accent: "border-accent/30 bg-accent-soft text-accent",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export function Badge({
  className,
  variant,
  ...props
}: React.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
