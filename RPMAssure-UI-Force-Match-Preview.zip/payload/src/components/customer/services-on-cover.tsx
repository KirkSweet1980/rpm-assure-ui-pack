import { NoCover } from "@/components/ui/no-cover";
import type { CustomerCover } from "@/lib/data/cover";
import { useUiLabels } from "@/lib/settings/use-ui-labels";

/**
 * Single cover strip for all customer pages — must not sit under sticky pillars.
 * Labels from Settings → Labels.
 */
export function ServicesOnCoverStrip({
  cover,
}: {
  cover?: CustomerCover | null;
}) {
  const { labels } = useUiLabels();
  const c = cover ?? {
    syspro: false,
    rmm: false,
    cove: false,
    epp: false,
    csp: false,
  };

  return (
    <div
      className="rpma-cover-strip flex flex-wrap items-center gap-x-2 gap-y-1.5 rounded-xl border border-border bg-surface px-3 py-2.5 text-[12px]"
      aria-label={labels.servicesOnCover}
    >
      <span className="shrink-0 font-semibold text-fg">{labels.servicesOnCover}</span>
      <CoverChip
        on={Boolean(c.syspro)}
        label={labels.syspro}
        noCover={labels.noCover}
        tip={`${labels.syspro} not in scope for this customer`}
      />
      <span className="hidden text-subtle sm:inline" aria-hidden>
        ·
      </span>
      <CoverChip
        on={Boolean(c.rmm)}
        label={labels.rmm}
        noCover={labels.noCover}
        tip={`${labels.rmm} not in scope for this customer`}
      />
      <span className="hidden text-subtle sm:inline" aria-hidden>
        ·
      </span>
      <CoverChip
        on={Boolean(c.cove)}
        label={labels.cove}
        noCover={labels.noCover}
        tip={`${labels.cove} not in scope for this customer`}
      />
      <span className="hidden text-subtle sm:inline" aria-hidden>
        ·
      </span>
      <CoverChip
        on={Boolean(c.epp)}
        label={labels.epp}
        noCover={labels.noCover}
        tip={`${labels.epp} not in scope for this customer`}
      />
      <span className="hidden text-subtle sm:inline" aria-hidden>
        ·
      </span>
      <CoverChip
        on={Boolean(c.csp)}
        label={labels.csp}
        noCover={labels.noCover}
        tip={`${labels.csp} not in scope for this customer`}
      />
    </div>
  );
}

function CoverChip({
  on,
  label,
  tip,
  noCover,
}: {
  on: boolean;
  label: string;
  tip: string;
  noCover: string;
}) {
  if (on) {
    return (
      <span className="rounded-md bg-rag-green-bg px-2 py-0.5 font-medium text-rag-green">
        {label}
      </span>
    );
  }
  return (
    <span title={tip} className="inline-flex items-center gap-1">
      <span className="text-muted">{label}</span>
      <NoCover text={noCover} />
    </span>
  );
}
