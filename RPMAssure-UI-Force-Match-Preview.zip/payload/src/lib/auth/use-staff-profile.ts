import { useEffect, useState } from "react";
import { fetchStaffProfile, type StaffProfile } from "@/lib/data/staff-profile";
import { useCurrentUserState } from "./use-current-user";

const profileCache = new Map<string, { at: number; profile: StaffProfile }>();
const PROFILE_TTL = 120_000;

export function useStaffProfile(): {
  profile: StaffProfile | null;
  isPending: boolean;
  userPending: boolean;
} {
  const { user, isPending: userPending } = useCurrentUserState();
  const email = user?.primaryEmail ?? null;
  const cached =
    email && profileCache.has(email.toLowerCase())
      ? profileCache.get(email.toLowerCase())!
      : null;
  const fresh =
    cached && Date.now() - cached.at < PROFILE_TTL ? cached.profile : null;

  const [profile, setProfile] = useState<StaffProfile | null>(fresh);
  const [loading, setLoading] = useState(!fresh && !!email);

  useEffect(() => {
    if (userPending) return;
    if (!email) {
      setProfile(null);
      setLoading(false);
      return;
    }
    const key = email.toLowerCase();
    const hit = profileCache.get(key);
    if (hit && Date.now() - hit.at < PROFILE_TTL) {
      setProfile(hit.profile);
      setLoading(false);
      return;
    }
    // Stale cache: keep showing last profile while we revalidate (no white flash)
    if (hit?.profile) {
      setProfile(hit.profile);
      setLoading(false);
    }

    let cancelled = false;
    if (!hit?.profile) setLoading(true);
    void fetchStaffProfile({
      data: {
        email,
        displayName: user?.displayName,
      },
    })
      .then((p) => {
        if (cancelled) return;
        if (p) profileCache.set(key, { at: Date.now(), profile: p });
        setProfile(p);
      })
      .catch(() => {
        if (!cancelled) setProfile(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [email, user?.displayName, userPending]);

  return {
    profile,
    isPending: userPending || loading,
    userPending,
  };
}
