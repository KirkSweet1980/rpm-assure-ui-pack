/**
 * Multi-pillar cover model for RPM Assure.
 * Legs: SYSPRO · RMM (Pulseway) · Cyber Backup (Cove) · EPP · M365.
 *
 * Cover is DATA-DRIVEN for every customer and every pillar:
 *   relevant warehouse / mapping data present → Covered
 *   no relevant data → No Cover
 *
 * Explicit AmsConfig flags (true) force Covered before data arrives.
 * SYSPRO only: explicit false = hard No Cover (e.g. HYDRA deferred).
 * RMM / Cove / EPP: live mapped data always wins over a default flag=0.
 * Uncovered legs show "No Cover" and do not drive estate health / SLA.
 */

export type PillarId = "syspro" | "rmm" | "cove" | "epp" | "csp";

export type CustomerCover = {
  /** SYSPRO / RPM Assure ERP collect */
  syspro: boolean;
  /** RPM Remote Management (Pulseway) */
  rmm: boolean;
  /** RPM Cyber Backup (Cove) */
  cove: boolean;
  /** Endpoint protection (Bitdefender) */
  epp?: boolean;
  /** Microsoft CSP / licensing */
  csp?: boolean;
};

export const NO_COVER = "No Cover";

export function coverLabel(on: boolean): string {
  return on ? "Covered" : NO_COVER;
}

function hasText(v: string | null | undefined): boolean {
  return Boolean(v != null && String(v).trim());
}

/**
 * SYSPRO-only resolve (supports deferred hard-off via PillarSyspro=false).
 * - explicit flag false → hard No Cover
 * - evidence → Covered
 * - explicit flag true → Covered
 * - else → No Cover
 */
function resolveSyspro(
  evidence: boolean,
  flag: boolean | null | undefined,
): boolean {
  if (flag === false) return false;
  if (evidence) return true;
  if (flag === true) return true;
  return false;
}

/**
 * Data-first resolve for RMM / Cove / EPP / CSP.
 * Mapped warehouse data always means Covered (ignores default Pillar*=0).
 * Flag true can pre-enable before first collect.
 */
function resolveDataFirst(
  evidence: boolean,
  flag: boolean | null | undefined,
): boolean {
  if (evidence) return true;
  if (flag === true) return true;
  return false;
}

/**
 * Infer which services are in scope from **relevant data** (same rules for all customers).
 *
 * SYSPRO evidence: SQL instance mapping, operators, active users, or last SYSPRO import.
 * RMM evidence: Pulseway org name, mapped devices, or device count.
 * Cove evidence: partner/mapping or device count.
 * EPP / CSP: device/user counts when provided.
 */
export function inferCustomerCover(input: {
  pillarSyspro?: boolean | null;
  pillarPulseway?: boolean | null;
  pillarCove?: boolean | null;
  pillarEpp?: boolean | null;
  pillarCsp?: boolean | null;
  /** retained for callers; data evidence is primary */
  hasAmsConfig?: boolean | null;
  sqlInstanceName?: string | null;
  operatorCount?: number | null;
  activeUserCount?: number | null;
  sysproLastImportAt?: string | null;
  /** Additional SYSPRO warehouse signals (any one is enough) */
  sysproJobErrorCount?: number | null;
  sysproDtrVarianceLines?: number | null;
  sysproHasLicense?: boolean | null;
  sysproHasVersion?: boolean | null;
  sysproHotfixCount?: number | null;
  pulsewayOrgName?: string | null;
  pulsewayDeviceCount?: number | null;
  pulsewayMapped?: boolean | null;
  coveDeviceCount?: number | null;
  coveMapped?: boolean | null;
  covePartnerName?: string | null;
  eppDeviceCount?: number | null;
  cspUserCount?: number | null;
  cspLicenseCount?: number | null;
}): CustomerCover {
  const sysproEvidence =
    hasText(input.sqlInstanceName) ||
    (Number(input.operatorCount) || 0) > 0 ||
    (Number(input.activeUserCount) || 0) > 0 ||
    hasText(input.sysproLastImportAt) ||
    (Number(input.sysproJobErrorCount) || 0) > 0 ||
    (Number(input.sysproDtrVarianceLines) || 0) > 0 ||
    Boolean(input.sysproHasLicense) ||
    Boolean(input.sysproHasVersion) ||
    (Number(input.sysproHotfixCount) || 0) > 0;

  const rmmEvidence =
    hasText(input.pulsewayOrgName) ||
    Boolean(input.pulsewayMapped) ||
    (Number(input.pulsewayDeviceCount) || 0) > 0;

  const coveEvidence =
    Boolean(input.coveMapped) ||
    hasText(input.covePartnerName) ||
    (Number(input.coveDeviceCount) || 0) > 0;

  const eppEvidence = (Number(input.eppDeviceCount) || 0) > 0;
  const cspEvidence =
    (Number(input.cspUserCount) || 0) > 0 ||
    (Number(input.cspLicenseCount) || 0) > 0;

  return {
    syspro: resolveSyspro(sysproEvidence, input.pillarSyspro),
    rmm: resolveDataFirst(rmmEvidence, input.pillarPulseway),
    cove: resolveDataFirst(coveEvidence, input.pillarCove),
    epp: resolveDataFirst(eppEvidence, input.pillarEpp),
    csp: resolveDataFirst(cspEvidence, input.pillarCsp),
  };
}

/** True when the cover object says this pillar is on. */
export function isPillarCovered(
  cover: CustomerCover | null | undefined,
  pillar: PillarId,
): boolean {
  if (!cover) return false;
  return cover[pillar] === true;
}

export function anyCover(c: CustomerCover): boolean {
  return c.syspro || c.rmm || c.cove || Boolean(c.epp) || Boolean(c.csp);
}

/** After warehouse load: any real SYSPRO footprint forces Covered (all customers). */
export function forceSysproCoverIfEvidence(
  cover: CustomerCover,
  evidence: boolean,
): CustomerCover {
  if (evidence && !cover.syspro) return { ...cover, syspro: true };
  return cover;
}

export function coverSummary(c: CustomerCover): string {
  const on: string[] = [];
  if (c.syspro) on.push("SYSPRO");
  if (c.rmm) on.push("RMM");
  if (c.cove) on.push("Backup");
  if (c.epp) on.push("EPP");
  if (c.csp) on.push("M365");
  if (on.length === 0) return "No service cover configured";
  return `Cover: ${on.join(" · ")}`;
}

export function coveredLegCount(c: CustomerCover): number {
  return (
    (c.syspro ? 1 : 0) +
    (c.rmm ? 1 : 0) +
    (c.cove ? 1 : 0) +
    (c.epp ? 1 : 0) +
    (c.csp ? 1 : 0)
  );
}

export function averageCoveredScores(
  cover: CustomerCover,
  scores: { syspro?: number | null; rmm?: number | null; cove?: number | null },
): number | null {
  const parts: number[] = [];
  if (cover.syspro && scores.syspro != null && Number.isFinite(scores.syspro)) {
    parts.push(Number(scores.syspro));
  }
  if (cover.rmm && scores.rmm != null && Number.isFinite(scores.rmm)) {
    parts.push(Number(scores.rmm));
  }
  if (cover.cove && scores.cove != null && Number.isFinite(scores.cove)) {
    parts.push(Number(scores.cove));
  }
  if (parts.length === 0) return null;
  return Math.round((parts.reduce((a, b) => a + b, 0) / parts.length) * 10) / 10;
}
