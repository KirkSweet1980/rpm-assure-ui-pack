RPM Assure - Force UI to match Grok preview
===========================================

PROBLEM
  Your server runs production  .output\server\index.mjs  via
  scheduled task RPMAssure-App-OnStart.
  Deploying only src\ does NOT change that bundle - you keep
  seeing the OLD UI while Grok preview shows the NEW one (vite).

FIX
  This pack deploys latest src+public, STOPS production, starts
  VITE on 8081, and PROVES login marker:
    cmd-centre-A-v3-split-20260812

RUN (elevated PowerShell on APP SERVER)
  $zip  = "$env:USERPROFILE\Downloads\RPMAssure-UI-Force-Match-Preview.zip"
  $dest = "$env:USERPROFILE\Downloads\RPMAssure-UI-Force-Match-Preview"
  Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
  Unblock-File "$dest\Apply-UI-Force-Match-Preview.ps1"
  powershell -NoProfile -ExecutionPolicy Bypass -File "$dest\Apply-UI-Force-Match-Preview.ps1"

SUCCESS looks like
  PROOF OK: .../src/routes/login.tsx contains cmd-centre-A-v3-split-20260812
  SUCCESS - live UI matches Grok preview source

THEN
  Open a PRIVATE browser window to https://assure.rpmresources.co.za/login
  Hard refresh (Ctrl+Shift+R)
  You should see the split login (CLI windows left, glass card right)

If still wrong after PROOF OK:
  - Private window only (old cache)
  - Caddy still proxying an old process: check netstat :8081 command line
