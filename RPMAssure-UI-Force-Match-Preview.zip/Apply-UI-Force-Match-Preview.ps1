# Apply-UI-Force-Match-Preview.ps1
# Makes the LIVE site match the Grok preview pane.
#
# WHY your last zip looked wrong:
#   Scheduled task RPMAssure-App-OnStart runs PRODUCTION .output\server\index.mjs
#   Copying src\ does NOT change that bundle until rebuild. You kept seeing old UI.
#
# THIS script:
#   1) Deploys latest src + public from the zip payload
#   2) Stops production node / scheduled task
#   3) Starts VITE on 8081 (same path as Grok preview - source UI)
#   4) PROVES the login marker is served: cmd-centre-A-v3-split-20260812
#
# Pure ASCII. Run elevated on the APP SERVER.
$ErrorActionPreference = 'Stop'

$App  = 'C:\RPM-Assure\App'
$Port = 8081
$Base = "http://127.0.0.1:$Port"
$Marker = 'cmd-centre-A-v3-split-20260812'
$utf8 = New-Object System.Text.UTF8Encoding $false

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Here) { $Here = (Get-Location).Path }
$Payload = Join-Path $Here 'payload'
if (-not (Test-Path (Join-Path $Payload 'src\routes\login.tsx'))) {
  $alt = Get-ChildItem $Here -Recurse -Directory -Filter 'payload' -EA SilentlyContinue |
    Where-Object { Test-Path (Join-Path $_.FullName 'src\routes\login.tsx') } |
    Select-Object -First 1
  if ($alt) { $Payload = $alt.FullName }
}
if (-not (Test-Path (Join-Path $Payload 'src\routes\login.tsx'))) {
  throw "Missing payload\src\routes\login.tsx under $Here - extract the FULL zip"
}

if (-not (Test-Path $App)) {
  foreach ($c in @(
      'C:\Program Files\RPM Resources\RPM Assure\app',
      'C:\Program Files\RPM Resources\RPM Assure\App'
    )) {
    if (Test-Path $c) { $App = $c; break }
  }
}
if (-not (Test-Path $App)) { throw "Missing $App" }

Write-Host '=== Force UI to match Grok preview ===' -ForegroundColor Cyan
Write-Host "Payload = $Payload"
Write-Host "App     = $App"
Write-Host "Marker  = $Marker"

# Verify payload has the marker
$loginSrc = Join-Path $Payload 'src\routes\login.tsx'
$loginText = [IO.File]::ReadAllText($loginSrc)
if ($loginText -notlike "*$Marker*") {
  throw "Payload login.tsx missing marker $Marker - wrong zip"
}
Write-Host 'OK payload login.tsx contains marker' -ForegroundColor Green

# --- 1) Backup + deploy source ---
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$Backup = Join-Path $App ('_backup_ui_' + $stamp)
New-Item -ItemType Directory -Force -Path $Backup | Out-Null
if (Test-Path (Join-Path $App 'src')) {
  Copy-Item (Join-Path $App 'src') (Join-Path $Backup 'src') -Recurse -Force
  Write-Host "Backup src -> $Backup\src"
}

$destSrc = Join-Path $App 'src'
if (Test-Path $destSrc) { Remove-Item $destSrc -Recurse -Force }
Copy-Item (Join-Path $Payload 'src') $destSrc -Recurse -Force
Write-Host "OK deployed $destSrc"

$destPublic = Join-Path $App 'public'
if (Test-Path (Join-Path $Payload 'public')) {
  New-Item -ItemType Directory -Force -Path $destPublic | Out-Null
  Copy-Item (Join-Path $Payload 'public\*') $destPublic -Recurse -Force
  Write-Host "OK deployed public"
}

# Mirror legacy path some tasks used
$mirror = 'C:\RPM-Assure\src'
if (Test-Path 'C:\RPM-Assure') {
  if (Test-Path $mirror) { Remove-Item $mirror -Recurse -Force -EA SilentlyContinue }
  Copy-Item $destSrc $mirror -Recurse -Force -EA SilentlyContinue
}

# Marker on disk
$markerFile = Join-Path $App 'UI_DEPLOY_MARKER.txt'
Copy-Item (Join-Path $Payload 'UI_DEPLOY_MARKER.txt') $markerFile -Force -EA SilentlyContinue
[IO.File]::WriteAllText(
  (Join-Path $App 'src\routes\_deploy_marker.txt'),
  ("SERVE_VIA_VITE`n" + $Marker + "`n" + (Get-Date).ToString('o') + "`n"),
  $utf8
)

# Clear Vite cache
$viteCache = Join-Path $App 'node_modules\.vite'
if (Test-Path $viteCache) {
  Remove-Item $viteCache -Recurse -Force -EA SilentlyContinue
  Write-Host 'Cleared Vite cache'
}

# Deploy scripts if missing
if (Test-Path (Join-Path $Payload 'scripts')) {
  New-Item -ItemType Directory -Force -Path (Join-Path $App 'scripts') | Out-Null
  Copy-Item (Join-Path $Payload 'scripts\*') (Join-Path $App 'scripts') -Force -EA SilentlyContinue
}

# --- 2) HARD stop everything on 8081 (production + vite + task) ---
Write-Host '--- Stopping production / all node on 8081 ---' -ForegroundColor Yellow
try { schtasks /End /TN 'RPMAssure-App-OnStart' 2>$null | Out-Null } catch {}
try { schtasks /End /TN 'RPMAssure-App' 2>$null | Out-Null } catch {}
foreach ($svcName in @('RPMAssure-App', 'RPMAssure', 'RPM-Assure')) {
  $svc = Get-Service -Name $svcName -EA SilentlyContinue
  if ($svc -and $svc.Status -eq 'Running') {
    try { Stop-Service -Name $svcName -Force -EA SilentlyContinue } catch {}
  }
}

# Kill node processes related to the app
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -EA SilentlyContinue | ForEach-Object {
  $cl = $_.CommandLine
  if ($cl -match 'RPM-Assure|8081|\.output|vite') {
    Write-Host ("Kill PID " + $_.ProcessId + " " + $cl.Substring(0, [Math]::Min(80, $cl.Length)))
    Stop-Process -Id $_.ProcessId -Force -EA SilentlyContinue
  }
}
# Also free the port
$conns = Get-NetTCPConnection -LocalPort $Port -State Listen -EA SilentlyContinue
foreach ($c in @($conns)) {
  if ($c.OwningProcess -gt 0) {
    Write-Host ("Kill port owner PID " + $c.OwningProcess)
    Stop-Process -Id $c.OwningProcess -Force -EA SilentlyContinue
  }
}
Start-Sleep -Seconds 2

# --- 3) Point OnStart wrapper at VITE (so reboot still matches preview) ---
$Logs = 'C:\RPM-Assure\deploy\logs'
New-Item -ItemType Directory -Force -Path $Logs | Out-Null
$wrapper = Join-Path $Logs 'start-app-vite.cmd'
$wrapperBody = @"
@echo off
cd /d "$App"
set PORT=$Port
set HOST=0.0.0.0
set NITRO_PORT=$Port
rem Force source UI (matches Grok preview). Production .output is NOT used.
npx.cmd vite dev --host 0.0.0.0 --port $Port >> "$Logs\app-stdout.log" 2>> "$Logs\app-stderr.log"
"@
[IO.File]::WriteAllText($wrapper, $wrapperBody, $utf8)
Write-Host "OK $wrapper"

# Re-register scheduled task to vite wrapper (so it does not revive stale .output)
try {
  schtasks /Create /F /TN 'RPMAssure-App-OnStart' /TR $wrapper /SC ONSTART /RU SYSTEM /RL HIGHEST /DELAY 0000:15 | Out-Null
  Write-Host 'OK scheduled task RPMAssure-App-OnStart -> VITE' -ForegroundColor Green
} catch {
  Write-Host ('WARN schtasks update: ' + $_.Exception.Message) -ForegroundColor Yellow
}

# Also write a note
[IO.File]::WriteAllText(
  (Join-Path $Logs 'UI_MODE.txt'),
  "MODE=VITE`nMARKER=$Marker`nUPDATED=$(Get-Date -Format o)`nREASON=Match Grok preview; production .output was stale`n",
  $utf8
)

# --- 4) Start Vite now ---
Write-Host '--- Starting Vite (source UI) ---' -ForegroundColor Cyan
$cmdLine = "cd /d `"$App`" && npx.cmd vite dev --host 0.0.0.0 --port $Port >> `"$Logs\app-stdout.log`" 2>> `"$Logs\app-stderr.log`""
Start-Process cmd.exe -ArgumentList '/c', $cmdLine -WorkingDirectory $App -WindowStyle Minimized

$up = $false
$pidListen = $null
for ($i = 1; $i -le 60; $i++) {
  Start-Sleep -Seconds 1
  $l = Get-NetTCPConnection -LocalPort $Port -State Listen -EA SilentlyContinue
  if ($l) {
    $pidListen = $l[0].OwningProcess
    Write-Host "LISTENING PID $pidListen after ${i}s"
    $up = $true
    break
  }
  if (($i % 10) -eq 0) { Write-Host "waiting vite $i/60..." }
}
if (-not $up) {
  Write-Host 'Vite did not bind - last stderr:' -ForegroundColor Red
  if (Test-Path (Join-Path $Logs 'app-stderr.log')) {
    Get-Content (Join-Path $Logs 'app-stderr.log') -Tail 40
  }
  throw "Port $Port not listening"
}

Start-Sleep -Seconds 5

# --- 5) PROVE served module has marker (vite serves TS source) ---
Write-Host '--- Prove live module matches preview ---' -ForegroundColor Cyan
$ok = $false
$probeUrls = @(
  "$Base/src/routes/login.tsx",
  "$Base/src/routes/login.tsx?tsr-split=component"
)
foreach ($u in $probeUrls) {
  try {
    $r = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 30
    $body = $r.Content
    if ($body -like "*$Marker*") {
      Write-Host "PROOF OK: $u contains $Marker" -ForegroundColor Green
      $ok = $true
      break
    } else {
      Write-Host "No marker in $u (len=$($body.Length))" -ForegroundColor Yellow
      # show a snippet for debug
      if ($body.Length -gt 200) {
        Write-Host ($body.Substring(0, [Math]::Min(300, $body.Length)))
      }
    }
  } catch {
    Write-Host ("probe fail $u : " + $_.Exception.Message)
  }
}

# Also prove disk
$diskLogin = Join-Path $App 'src\routes\login.tsx'
$diskOk = (Select-String -Path $diskLogin -Pattern $Marker -SimpleMatch -Quiet)
Write-Host ("Disk login.tsx marker: " + $diskOk)

if (-not $ok) {
  Write-Host ''
  Write-Host 'SERVED UI STILL WRONG - common causes:' -ForegroundColor Red
  Write-Host '  1) Another process still serving old .output on 8081'
  Write-Host '  2) Browser cache - use private window'
  Write-Host '  3) Caddy upstream points elsewhere'
  Write-Host '  netstat -ano | findstr :8081'
  Write-Host '  Get-CimInstance Win32_Process -Filter "Name=''node.exe''" | Select ProcessId,CommandLine'
  exit 1
}

Write-Host ''
Write-Host '========================================' -ForegroundColor Green
Write-Host ' SUCCESS - live UI matches Grok preview source'
Write-Host "  Marker:  $Marker"
Write-Host "  Mode:    VITE (source) on port $Port"
Write-Host "  Backup:  $Backup"
Write-Host '  Browser: PRIVATE WINDOW or Ctrl+Shift+R hard refresh'
Write-Host '  Login:   look for split CLI stack + glass card'
Write-Host '  Check:   view-source or DevTools -> data-login-build='
Write-Host "           $Marker"
Write-Host '========================================' -ForegroundColor Green
Write-Host ''
Write-Host 'Note: production .output was intentionally NOT used.'
Write-Host 'When you want production mode again:'
Write-Host '  cd C:\RPM-Assure\App'
Write-Host '  npm.cmd run build:node'
Write-Host '  then restore start-app-prod.cmd task via Go-Production-NoMsi.ps1'
Write-Host '=== Done ==='
