Login words left/right only. Run Apply-Login-Words-Sides-Only.ps1
