﻿# Apply-Login-Words-No-Dupes.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = 'C:\RPM-Assure\App'
$s = Join-Path $Here 'App\src\routes\login.tsx'
$d = Join-Path $AppRoot 'src\routes\login.tsx'
Copy-Item -LiteralPath $s -Destination $d -Force
Write-Host "OK $d"
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 5
} catch { Write-Host $_ }
Write-Host 'Hard-refresh /login (Ctrl+F5). Each word appears once.'
Write-Host '=== Done ==='
