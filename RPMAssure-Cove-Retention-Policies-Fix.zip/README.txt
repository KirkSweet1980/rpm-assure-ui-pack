Fixed apply script (ASCII). Run Apply-Cove-Retention-Policies-Fix.ps1 as Admin.
