Run Prepare-Payload.ps1 to fill this archive.
