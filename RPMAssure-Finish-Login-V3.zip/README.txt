Run Finish-Login-V3.ps1 after V3 apply wrote the file.
