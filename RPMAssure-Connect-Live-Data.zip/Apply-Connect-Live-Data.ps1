# Apply-Connect-Live-Data.ps1
# Wires RPM Assure to live SQL (RPMAssure_App) and restarts the app.
# Run ON the APP SERVER in elevated PowerShell.
# Pure ASCII - safe for Windows PowerShell 5.1
$ErrorActionPreference = 'Stop'

# --- defaults (edit if your central differs) ---
$SqlServerHost = '102.222.21.220'
$SqlPort       = 14333
$SqlDatabase   = 'RPMAssure_App'
$SqlUser       = 'Rpm_collect'
$SqlPassword   = 'RpmCollect#AHIC2026'
$DataMode      = 'live'   # live | auto | demo
$AppPort       = 8081
$Base          = "http://127.0.0.1:$AppPort"

$AppCandidates = @(
  'C:\RPM-Assure\App',
  'C:\Program Files\RPM Resources\RPM Assure\app',
  'C:\Program Files\RPM Resources\RPM Assure\App'
)
$App = $null
foreach ($c in $AppCandidates) {
  if ((Test-Path (Join-Path $c 'package.json')) -or (Test-Path (Join-Path $c '.output\server\index.mjs'))) {
    $App = $c
    break
  }
}
if (-not $App) { $App = 'C:\RPM-Assure\App' }
if (-not (Test-Path $App)) { throw "App not found. Expected C:\RPM-Assure\App" }

$utf8 = New-Object System.Text.UTF8Encoding $false
Write-Host '=== Connect live data to RPM Assure ==='
Write-Host "App = $App"
Write-Host "SQL = ${SqlServerHost},${SqlPort} / $SqlDatabase / user=$SqlUser / mode=$DataMode"

# Optional overrides from env
if ($env:RPMA_SQL_SERVER)   { $SqlServerHost = $env:RPMA_SQL_SERVER }
if ($env:RPMA_SQL_PORT)     { $SqlPort = [int]$env:RPMA_SQL_PORT }
if ($env:RPMA_SQL_USER)     { $SqlUser = $env:RPMA_SQL_USER }
if ($env:RPMA_SQL_PASSWORD) { $SqlPassword = $env:RPMA_SQL_PASSWORD }
if ($env:RPMA_DATA_MODE)    { $DataMode = $env:RPMA_DATA_MODE }

function Merge-EnvFile {
  param([string]$Path)
  $map = [ordered]@{}
  if (Test-Path -LiteralPath $Path) {
    foreach ($line in Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue) {
      $t = $line.Trim()
      if (-not $t -or $t.StartsWith('#')) { continue }
      $eq = $t.IndexOf('=')
      if ($eq -le 0) { continue }
      $k = $t.Substring(0, $eq).Trim()
      $v = $t.Substring($eq + 1)
      $map[$k] = $v
    }
  }

  # Force live SQL keys
  $map['RPM_ASSURE_DATA_MODE'] = $DataMode
  $map['RPM_ASSURE_SQL_SERVER'] = ("{0},{1}" -f $SqlServerHost, $SqlPort)
  $map['RPM_ASSURE_SQL_PORT'] = "$SqlPort"
  $map['RPM_ASSURE_SQL_DATABASE'] = $SqlDatabase
  $map['RPM_ASSURE_SQL_USER'] = $SqlUser
  $map['RPM_ASSURE_SQL_PASSWORD'] = $SqlPassword
  $map['RPM_ASSURE_SQL_TRUST_CERT'] = 'true'
  $map['RPM_ASSURE_SQL_ENCRYPT'] = 'true'
  $map['NITRO_PORT'] = "$AppPort"
  $map['PORT'] = "$AppPort"
  $map['HOST'] = '0.0.0.0'

  if (-not $map.Contains('VITE_AUTH_ENABLED')) { $map['VITE_AUTH_ENABLED'] = 'true' }
  if (-not $map.Contains('BETTER_AUTH_URL') -or [string]::IsNullOrWhiteSpace([string]$map['BETTER_AUTH_URL'])) {
    $map['BETTER_AUTH_URL'] = "http://127.0.0.1:$AppPort"
  }
  if (-not $map.Contains('BETTER_AUTH_SECRET') -or [string]::IsNullOrWhiteSpace([string]$map['BETTER_AUTH_SECRET'])) {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $map['BETTER_AUTH_SECRET'] = ([BitConverter]::ToString($bytes) -replace '-','').ToLowerInvariant()
    Write-Host 'Generated BETTER_AUTH_SECRET'
  }

  $lines = @()
  foreach ($k in $map.Keys) {
    $lines += ('{0}={1}' -f $k, $map[$k])
  }
  $dir = Split-Path -Parent $Path
  if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  [System.IO.File]::WriteAllText($Path, (($lines -join "`r`n") + "`r`n"), $utf8)
  Write-Host "OK env $Path"
}

# 1) .env.local + .env (app reads both)
Merge-EnvFile (Join-Path $App '.env.local')
Merge-EnvFile (Join-Path $App '.env')

# ProgramData layout (MSI recovery)
$pd = 'C:\ProgramData\RPM Resources\RPM Assure\config'
if (Test-Path $pd) {
  Merge-EnvFile (Join-Path $pd 'app.env')
}

# 2) Settings file (preferred by app when complete) - live primary connection
$dataDir = Join-Path $App 'data'
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
$settingsPath = Join-Path $dataDir 'rpma-settings.json'

$settings = $null
if (Test-Path $settingsPath) {
  try {
    $settings = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
  } catch {
    Write-Host 'WARN: existing rpma-settings.json invalid - recreating primary SQL only'
    $settings = $null
  }
}

$primary = [ordered]@{
  id                     = 'primary-central'
  name                   = 'RPMAssure_App (central)'
  isPrimary              = $true
  server                 = $SqlServerHost
  port                   = $SqlPort
  database               = $SqlDatabase
  user                   = $SqlUser
  password               = $SqlPassword
  trustServerCertificate = $true
  encrypt                = $true
  dataMode               = $DataMode
}

if ($null -eq $settings) {
  $settingsObj = [ordered]@{
    version         = 1
    updatedAt       = (Get-Date).ToUniversalTime().ToString('o')
    sqlConnections  = @($primary)
    smtp            = @{ enabled = $false }
    ssl             = @{ mode = 'disabled' }
    rag             = @{}
    alerts          = @{ enabled = $false }
    dashboard       = @{}
    labels          = @{}
    cronSecret      = ''
    lastWeeklyReportAt = $null
  }
  $json = $settingsObj | ConvertTo-Json -Depth 8
} else {
  # Update or insert primary connection; demote others
  $list = @()
  $found = $false
  if ($settings.sqlConnections) {
    foreach ($c in @($settings.sqlConnections)) {
      $ht = [ordered]@{}
      foreach ($p in $c.PSObject.Properties) { $ht[$p.Name] = $p.Value }
      if ($ht['id'] -eq 'primary-central' -or $ht['isPrimary'] -eq $true) {
        $ht = $primary
        $found = $true
      } else {
        $ht['isPrimary'] = $false
      }
      $list += [pscustomobject]$ht
    }
  }
  if (-not $found) { $list = @([pscustomobject]$primary) + $list }
  $settings | Add-Member -NotePropertyName sqlConnections -NotePropertyValue $list -Force
  $settings | Add-Member -NotePropertyName updatedAt -NotePropertyValue ((Get-Date).ToUniversalTime().ToString('o')) -Force
  $json = $settings | ConvertTo-Json -Depth 10
}

[System.IO.File]::WriteAllText($settingsPath, $json + "`r`n", $utf8)
Write-Host "OK $settingsPath (primary SQL live)"

# Also ProgramData data folder if present
$pdData = 'C:\ProgramData\RPM Resources\RPM Assure\data'
if (Test-Path (Split-Path $pdData -Parent)) {
  New-Item -ItemType Directory -Force -Path $pdData | Out-Null
  [System.IO.File]::WriteAllText((Join-Path $pdData 'rpma-settings.json'), $json + "`r`n", $utf8)
  Write-Host "OK ProgramData rpma-settings.json"
}

# 3) Prove SQL with sqlcmd (on-box named instance OR remote TCP)
Write-Host '--- SQL proof ---'
$sqlcmd = $null
foreach ($c in @(
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\SQLCMD.EXE',
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\180\Tools\Binn\SQLCMD.EXE'
  )) {
  if (Test-Path $c) { $sqlcmd = $c; break }
}
if (-not $sqlcmd) {
  $g = Get-Command sqlcmd -ErrorAction SilentlyContinue
  if ($g) { $sqlcmd = $g.Source }
}

$SqlServerComma = ("{0},{1}" -f $SqlServerHost, $SqlPort)
$proofQ = "SET NOCOUNT ON; SELECT @@SERVERNAME AS ServerName, DB_NAME() AS Db, SUSER_SNAME() AS LoginName, (SELECT COUNT(*) FROM dbo.Dim_Customer WITH (NOLOCK)) AS Customers;"

if ($sqlcmd) {
  Write-Host "sqlcmd=$sqlcmd"
  Write-Host "Trying TCP $SqlServerComma as $SqlUser ..."
  $out = & $sqlcmd -S $SqlServerComma -d $SqlDatabase -U $SqlUser -P $SqlPassword -C -W -Q $proofQ 2>&1 | Out-String
  Write-Host $out
  if ($LASTEXITCODE -ne 0) {
    Write-Host 'TCP auth failed - try local named instance with Windows auth ...' -ForegroundColor Yellow
    $out2 = & $sqlcmd -S '.\RPMREPORTS' -d $SqlDatabase -E -C -W -Q $proofQ 2>&1 | Out-String
    Write-Host $out2
    if ($LASTEXITCODE -eq 0) {
      Write-Host 'Local Windows auth OK. App still uses SQL login from .env.local (Rpm_collect).' -ForegroundColor Cyan
    }
  } else {
    Write-Host 'SQL TCP proof OK' -ForegroundColor Green
  }
} else {
  Write-Host 'sqlcmd not found - skip SQL proof (app will test on start)' -ForegroundColor Yellow
}

# 4) Restart app so pool reloads env + settings
Write-Host '--- Restart app ---'
try { schtasks /End /TN 'RPMAssure-App-OnStart' 2>$null | Out-Null } catch {}
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$listen = Get-NetTCPConnection -LocalPort $AppPort -State Listen -ErrorAction SilentlyContinue
if ($listen) {
  foreach ($c in @($listen)) {
    try { Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  Start-Sleep -Seconds 2
}

$started = $false
$task = schtasks /Run /TN 'RPMAssure-App-OnStart' 2>&1
if ($LASTEXITCODE -eq 0) {
  Write-Host 'Started scheduled task RPMAssure-App-OnStart'
  $started = $true
} else {
  $serverJs = Join-Path $App '.output\server\index.mjs'
  $nodeExe = $null
  foreach ($n in @(
      'C:\Program Files\RPM Resources\RPM Assure\runtime\node\node.exe',
      'C:\Nodejs\node.exe',
      'C:\Program Files\nodejs\node.exe'
    )) {
    if (Test-Path $n) { $nodeExe = $n; break }
  }
  if (-not $nodeExe) {
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) { $nodeExe = $cmd.Source }
  }
  $logDir = 'C:\RPM-Assure\deploy\logs'
  if (-not (Test-Path $logDir)) { $logDir = Join-Path $env:TEMP 'rpma-logs' }
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null

  if ((Test-Path $serverJs) -and $nodeExe) {
    Write-Host "Starting production node: $serverJs"
    $env:PORT = "$AppPort"
    $env:HOST = '0.0.0.0'
    $env:RPM_ASSURE_DATA_MODE = $DataMode
    $env:RPM_ASSURE_SQL_SERVER = $SqlServerComma
    $env:RPM_ASSURE_SQL_PORT = "$SqlPort"
    $env:RPM_ASSURE_SQL_DATABASE = $SqlDatabase
    $env:RPM_ASSURE_SQL_USER = $SqlUser
    $env:RPM_ASSURE_SQL_PASSWORD = $SqlPassword
    $env:RPM_ASSURE_SQL_TRUST_CERT = 'true'
    Start-Process -FilePath $nodeExe -ArgumentList $serverJs -WorkingDirectory $App -WindowStyle Minimized `
      -RedirectStandardOutput (Join-Path $logDir 'app-stdout.log') `
      -RedirectStandardError  (Join-Path $logDir 'app-stderr.log')
    $started = $true
  } elseif ($nodeExe -and (Test-Path (Join-Path $App 'package.json'))) {
    Write-Host 'Starting vite dev ...'
    $cmdLine = "cd /d `"$App`" && npx.cmd vite dev --host 0.0.0.0 --port $AppPort >> `"$logDir\app-stdout.log`" 2>> `"$logDir\app-stderr.log`""
    Start-Process cmd.exe -ArgumentList '/c', $cmdLine -WorkingDirectory $App -WindowStyle Minimized
    $started = $true
  }
}

if (-not $started) {
  Write-Host 'WARN: could not auto-start app. Start manually then hard-refresh browser.' -ForegroundColor Yellow
}

$up = $false
for ($i = 1; $i -le 45; $i++) {
  Start-Sleep -Seconds 1
  $l = Get-NetTCPConnection -LocalPort $AppPort -State Listen -ErrorAction SilentlyContinue
  if ($l) {
    Write-Host "LISTENING PID $($l[0].OwningProcess)"
    $up = $true
    break
  }
}

if ($up) {
  Start-Sleep -Seconds 3
  try {
    $r = Invoke-WebRequest -Uri "$Base/" -UseBasicParsing -TimeoutSec 15
    Write-Host ("App HTTP " + $r.StatusCode) -ForegroundColor Green
  } catch {
    Write-Host ("App probe: " + $_.Exception.Message) -ForegroundColor Yellow
  }
  # settings runtime probe if available
  try {
    $r2 = Invoke-WebRequest -Uri "$Base/api/settings/runtime" -UseBasicParsing -TimeoutSec 15
    Write-Host 'Runtime:'
    Write-Host $r2.Content
  } catch {
    # route may not exist or needs auth - ignore
  }
}

Write-Host ''
Write-Host '========================================' -ForegroundColor Green
Write-Host ' LIVE DATA CONNECTED'
Write-Host "  Mode:     $DataMode"
Write-Host "  Server:   $SqlServerComma"
Write-Host "  Database: $SqlDatabase"
Write-Host "  User:     $SqlUser"
Write-Host '  Files:    .env.local + data\rpma-settings.json'
Write-Host '  Browser:  hard-refresh (Ctrl+F5) or private window'
Write-Host '  Login:    RPMAdmin / RPM@dm1n2026#  (if still needed)'
Write-Host '========================================' -ForegroundColor Green
Write-Host 'If portfolio still looks empty: check Dim_Customer rows and collect jobs.'
Write-Host '=== Done ==='
