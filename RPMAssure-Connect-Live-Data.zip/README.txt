RPM Assure - Connect live SQL data
==================================

On the APP SERVER (elevated PowerShell):

1) Save/extract this folder, then:

   Unblock-File "$env:USERPROFILE\Downloads\Apply-Connect-Live-Data.ps1"
   powershell -NoProfile -ExecutionPolicy Bypass -File "$env:USERPROFILE\Downloads\Apply-Connect-Live-Data.ps1"

   Or from the extracted zip folder:

   powershell -NoProfile -ExecutionPolicy Bypass -File .\Apply-Connect-Live-Data.ps1

2) Expect:
   - SQL proof with Customer count
   - LISTENING on 8081
   - LIVE DATA CONNECTED banner

3) Browser:
   - Hard refresh (Ctrl+F5) or private window
   - Sign in: RPMAdmin / RPM@dm1n2026#
   - Home / Exco / customers should show live SQL data (not demo)

Defaults used:
  Server   102.222.21.220,14333
  Database RPMAssure_App
  User     Rpm_collect
  Password RpmCollect#AHIC2026
  Mode     live

Override without editing the script:
  $env:RPMA_SQL_SERVER='102.222.21.220'
  $env:RPMA_SQL_PORT='14333'
  $env:RPMA_SQL_USER='rpmassure'
  $env:RPMA_SQL_PASSWORD='@ssuR3me!'
  $env:RPMA_DATA_MODE='live'
  then run Apply-Connect-Live-Data.ps1

If SQL proof fails with login error, try rpmassure password or fix Rpm_collect password in SQL.
