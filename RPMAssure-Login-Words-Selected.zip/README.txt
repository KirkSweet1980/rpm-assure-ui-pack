Selected login words only. Run Apply-Login-Words-Selected.ps1
