Option A V3 clean rewrite.
1. Expand zip
2. Run Apply-Login-Option-A-V3.ps1
3. Look for CONTAINS MARKER in output
4. Private window http://127.0.0.1:8081/login
Must see OPTION-A-20260811-V3 at top of page
