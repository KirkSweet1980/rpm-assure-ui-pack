import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type CSSProperties, type FormEvent } from "react";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RpmAssureMark } from "@/components/brand/rpm-assure-mark";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

/** Unmistakable build marker — if you cannot find this string in the browser, old JS is cached */
const LOGIN_BUILD_MARKER = "OPTION-A-20260811-V3";

const SQL_LINES = [
  "-- RPM Assure | Estate health workspace",
  "USE [RPMAssure_App];",
  "GO",
  "SET NOCOUNT ON;",
  "SELECT c.CustomerCode, c.DisplayName, h.HealthRag, h.HealthScorePct",
  "FROM dbo.Dim_Customer AS c",
  "LEFT JOIN dbo.vw_Kpi_Customer_Health_Latest AS h",
  "  ON h.CustomerCode = c.CustomerCode",
  "WHERE c.Active = 1",
  "ORDER BY h.HealthScorePct ASC;",
  "GO",
  "SELECT CustomerCode, COUNT(*) AS OfflineServers",
  "FROM dbo.Pulseway_Devices",
  "WHERE IsOnline = 0 AND DeviceClass = N'Server'",
  "GROUP BY CustomerCode;",
  "GO",
  "SELECT CustomerCode, DeviceName, LastBackupStatus, UsedBytes",
  "FROM dbo.Cove_DeviceStatistics",
  "WHERE SnapshotDate = CAST(SYSUTCDATETIME() AS date);",
  "GO",
  "PRINT N'Query complete — assurance delivered.';",
  "GO",
] as const;

const CHIPS: { text: string; top: string; side: "left" | "right"; offset: string }[] = [
  { text: "clarity", top: "18%", side: "left", offset: "2%" },
  { text: "source of truth", top: "42%", side: "left", offset: "1.5%" },
  { text: "insight", top: "66%", side: "left", offset: "2%" },
  { text: "visibility", top: "18%", side: "right", offset: "2%" },
  { text: "confidence", top: "42%", side: "right", offset: "1.5%" },
  { text: "evidence", top: "66%", side: "right", offset: "2%" },
];

const chipStyle = (c: (typeof CHIPS)[number]): CSSProperties => ({
  position: "absolute",
  top: c.top,
  ...(c.side === "left" ? { left: c.offset } : { right: c.offset }),
  display: "inline-flex",
  alignItems: "center",
  gap: 8,
  padding: "8px 14px 8px 12px",
  borderRadius: 999,
  border: "1px solid rgba(27,184,166,0.75)",
  background: "rgba(6,30,50,0.95)",
  color: "#b8fff4",
  fontSize: 15,
  fontWeight: 700,
  letterSpacing: "0.03em",
  textTransform: "lowercase",
  whiteSpace: "nowrap",
  boxShadow: "0 6px 24px rgba(0,0,0,0.5), 0 0 18px rgba(27,184,166,0.25)",
  zIndex: 3,
  pointerEvents: "none",
});

function SqlBg() {
  const block = [...SQL_LINES, "", ...SQL_LINES, "", ...SQL_LINES];
  return (
    <div
      aria-hidden="true"
      data-login-sql={LOGIN_BUILD_MARKER}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 0,
        display: "grid",
        gridTemplateColumns: "1fr 1fr 1fr",
        overflow: "hidden",
        pointerEvents: "none",
        fontFamily: 'Consolas, "Courier New", monospace',
      }}
    >
      <style>{`
        @keyframes rpmaSqlScroll {
          0% { transform: translateY(0); }
          100% { transform: translateY(-33.333%); }
        }
      `}</style>
      {[0, 1, 2].map((col) => (
        <div
          key={col}
          style={{
            overflow: "hidden",
            opacity: col === 1 ? 0.45 : 0.6,
            borderRight: col < 2 ? "1px solid rgba(27,184,166,0.1)" : "none",
          }}
        >
          <div
            style={{
              padding: col === 1 ? "48px 12px 24px" : "16px 12px 24px",
              animation: `rpmaSqlScroll ${50 + col * 10}s linear infinite${col === 1 ? " reverse" : ""}`,
              willChange: "transform",
            }}
          >
            {block.map((line, i) => {
              const t = line.trim();
              let color = "rgba(170,205,230,0.75)";
              if (/^(USE|GO|SET|SELECT|FROM|WHERE|LEFT|ORDER|GROUP|PRINT)\b/i.test(t))
                color = "rgba(100,170,230,0.98)";
              else if (t.startsWith("--")) color = "rgba(120,180,100,0.85)";
              else if (t.includes("N'") || t.includes("'")) color = "rgba(220,160,130,0.9)";
              return (
                <div
                  key={`${col}-${i}`}
                  style={{
                    display: "flex",
                    gap: 8,
                    fontSize: 11,
                    lineHeight: 1.55,
                    whiteSpace: "pre",
                  }}
                >
                  <span style={{ width: 28, textAlign: "right", color: "rgba(120,150,170,0.5)" }}>
                    {String((i % SQL_LINES.length) + 1).padStart(2, "0")}
                  </span>
                  <span style={{ color, fontWeight: color.startsWith("rgba(100") ? 700 : 400 }}>
                    {line || " "}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({ email: loginEmail, password });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      data-login-skin={LOGIN_BUILD_MARKER}
      style={{
        position: "relative",
        minHeight: "100dvh",
        width: "100%",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#050d18",
        color: "#e8f4ff",
      }}
    >
      {/* Visible build stamp — top center under chips area */}
      <div
        style={{
          position: "absolute",
          top: 10,
          left: 0,
          right: 0,
          zIndex: 20,
          textAlign: "center",
          fontSize: 11,
          fontWeight: 700,
          letterSpacing: "0.14em",
          color: "#1bb8a6",
          textTransform: "uppercase",
          pointerEvents: "none",
        }}
      >
        {LOGIN_BUILD_MARKER}
      </div>

      <SqlBg />

      {/* Center dim so form stays readable */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 1,
          pointerEvents: "none",
          background:
            "radial-gradient(ellipse 46% 52% at 50% 48%, rgba(5,12,22,0.9) 0%, rgba(5,12,22,0.55) 45%, transparent 75%)",
        }}
      />

      {/* Edge chips */}
      <div aria-hidden="true" data-login-chips={LOGIN_BUILD_MARKER} style={{ position: "absolute", inset: 0, zIndex: 3 }}>
        {CHIPS.map((c) => (
          <span key={c.text} style={chipStyle(c)}>
            <i
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "#1bb8a6",
                boxShadow: "0 0 10px #1bb8a6",
                display: "inline-block",
              }}
            />
            {c.text}
          </span>
        ))}
      </div>

      <div
        style={{
          position: "relative",
          zIndex: 10,
          width: "min(420px, 92vw)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 18,
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>
            <RpmAssureMark size={108} showWordmark={false} className="rpma-mark-pulse" />
          </div>
          <h1 style={{ margin: 0, fontSize: "clamp(2rem, 4.5vw, 2.75rem)", fontWeight: 800, letterSpacing: "-0.03em" }}>
            <span style={{ color: "#fff" }}>RPM</span>{" "}
            <span style={{ color: "#1bb8a6" }}>Assure</span>
          </h1>
          <p
            style={{
              margin: "10px 0 0",
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: "0.22em",
              textTransform: "uppercase",
              color: "#1bb8a6",
            }}
          >
            Assurance Delivered
          </p>
        </div>

        <div
          className="rpma-login-glass"
          style={{
            width: "100%",
            maxWidth: 384,
            padding: "26px 24px 24px",
            borderRadius: 18,
            textAlign: "left",
            background: "linear-gradient(165deg, rgba(18,42,68,0.78) 0%, rgba(12,28,48,0.85) 100%)",
            border: "1px solid rgba(100,180,220,0.22)",
            boxShadow: "0 24px 64px rgba(0,0,0,0.45)",
            backdropFilter: "blur(18px)",
          }}
        >
          <IdleLogoutBanner />
          <h2 style={{ margin: 0, fontSize: 23, fontWeight: 700, color: "#fff" }}>Sign in</h2>
          <p style={{ margin: "6px 0 0", fontSize: 12, fontWeight: 600, color: "#1bb8a6", letterSpacing: "0.06em" }}>
            Estate source of truth · {LOGIN_BUILD_MARKER}
          </p>

          {!authEnabled ? (
            <p style={{ color: "#f87171", marginTop: 12 }}>Auth is disabled.</p>
          ) : (
            <form onSubmit={onSignIn} style={{ marginTop: 18, display: "flex", flexDirection: "column", gap: 14 }}>
              <label style={{ display: "block" }}>
                <span style={{ display: "block", marginBottom: 6, fontSize: 12.5, fontWeight: 600, color: "rgba(220,235,250,0.9)" }}>
                  Email or username
                </span>
                <span style={{ position: "relative", display: "flex", alignItems: "center" }}>
                  <User size={16} style={{ position: "absolute", left: 12, color: "rgba(140,180,210,0.75)" }} />
                  <input
                    type="text"
                    required
                    placeholder="Email or username"
                    autoComplete="username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    style={{
                      width: "100%",
                      height: 42,
                      padding: "0 14px 0 38px",
                      borderRadius: 10,
                      border: "1px solid rgba(100,160,200,0.25)",
                      background: "rgba(6,16,28,0.7)",
                      color: "#f0f7ff",
                      fontSize: 14,
                      outline: "none",
                    }}
                  />
                </span>
              </label>

              <label style={{ display: "block" }}>
                <span style={{ display: "block", marginBottom: 6, fontSize: 12.5, fontWeight: 600, color: "rgba(220,235,250,0.9)" }}>
                  Password
                </span>
                <span style={{ position: "relative", display: "flex", alignItems: "center" }}>
                  <Lock size={16} style={{ position: "absolute", left: 12, color: "rgba(140,180,210,0.75)" }} />
                  <input
                    type={showPw ? "text" : "password"}
                    required
                    minLength={8}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    style={{
                      width: "100%",
                      height: 42,
                      padding: "0 42px 0 38px",
                      borderRadius: 10,
                      border: "1px solid rgba(100,160,200,0.25)",
                      background: "rgba(6,16,28,0.7)",
                      color: "#f0f7ff",
                      fontSize: 14,
                      outline: "none",
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    tabIndex={-1}
                    style={{
                      position: "absolute",
                      right: 8,
                      background: "transparent",
                      border: "none",
                      color: "rgba(160,190,210,0.8)",
                      cursor: "pointer",
                      display: "inline-flex",
                      padding: 6,
                    }}
                  >
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </span>
              </label>

              {error ? (
                <p style={{ margin: 0, color: "#f87171", fontSize: 13 }}>{error}</p>
              ) : null}

              <button
                type="submit"
                disabled={busy}
                style={{
                  height: 44,
                  border: "none",
                  borderRadius: 10,
                  background: "linear-gradient(90deg, #0d9488 0%, #1bb8a6 50%, #14b8a6 100%)",
                  color: "#042f2e",
                  fontWeight: 700,
                  fontSize: 15,
                  cursor: busy ? "wait" : "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                  opacity: busy ? 0.7 : 1,
                }}
              >
                <Lock size={16} strokeWidth={2.25} />
                {busy ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}
        </div>
      </div>

      <p
        style={{
          position: "absolute",
          bottom: 16,
          left: 0,
          right: 0,
          zIndex: 10,
          textAlign: "center",
          margin: 0,
          fontSize: 13,
          color: "rgba(180,210,230,0.55)",
        }}
      >
        Powered by RPM Resources
      </p>
    </div>
  );
}
