Keep brand words away from RPM Assure and login card. Run Apply-Login-Words-Clear-Center.ps1
