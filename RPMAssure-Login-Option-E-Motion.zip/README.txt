Option E with JS requestAnimationFrame motion (ignores reduced-motion CSS kill).
