import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RpmAssureMark } from "@/components/brand/rpm-assure-mark";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

/** Option E — bioluminescent streams with FORCED JS animation */
const LOGIN_SKIN = "option-e-bio-js";

const BUBBLE_DEFS = [
  { text: "clarity", x: 8, y: 14, size: 96, phase: 0, speed: 0.9 },
  { text: "insight", x: 5, y: 42, size: 82, phase: 1.2, speed: 1.1 },
  { text: "evidence", x: 11, y: 70, size: 90, phase: 2.1, speed: 0.75 },
  { text: "confidence", x: 78, y: 18, size: 92, phase: 0.6, speed: 1.0 },
  { text: "visibility", x: 82, y: 48, size: 84, phase: 1.8, speed: 1.15 },
  { text: "source of truth", x: 74, y: 74, size: 108, phase: 0.3, speed: 0.85 },
] as const;

const STREAM_SQL = [
  "SELECT c.CustomerCode, h.HealthScorePct FROM dbo.vw_Kpi_Customer_Health_Latest h",
  "JOIN dbo.Dim_Customer c ON c.CustomerCode = h.CustomerCode WHERE c.Active = 1",
  "SELECT DeviceName, LastBackupStatus FROM dbo.Cove_DeviceStatistics WHERE SnapshotDate = @AsOf",
  "SELECT COUNT(*) Offline FROM dbo.Pulseway_Devices WHERE IsOnline = 0",
  "PRINT N'Assurance delivered.'; GO",
  "SELECT CustomerCode, COUNT(*) FROM dbo.Bitdefender_Endpoints GROUP BY CustomerCode",
];

const OPTION_E_CSS = `
.rpma-e-root {
  position: relative;
  min-height: 100dvh;
  width: 100%;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  background:
    radial-gradient(ellipse 90% 70% at 50% -10%, rgba(20,120,140,0.4) 0%, transparent 50%),
    radial-gradient(ellipse 60% 40% at 20% 80%, rgba(27,184,166,0.14) 0%, transparent 55%),
    linear-gradient(180deg, #031018 0%, #050d18 40%, #020810 100%);
  color: #e8f4ff;
}
.rpma-e-rays {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  background:
    linear-gradient(118deg, transparent 40%, rgba(27,184,166,0.1) 48%, transparent 56%),
    linear-gradient(98deg, transparent 42%, rgba(80,200,220,0.08) 50%, transparent 58%),
    linear-gradient(135deg, transparent 38%, rgba(27,184,166,0.08) 46%, transparent 54%);
  mix-blend-mode: screen;
  will-change: opacity, transform;
}
.rpma-e-streams {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  overflow: hidden;
}
.rpma-e-stream {
  position: absolute;
  left: -15%;
  width: 130%;
  height: 3px;
  border-radius: 3px;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(27,184,166,0.1) 15%,
    rgba(80,240,250,0.85) 45%,
    rgba(27,184,166,1) 50%,
    rgba(80,240,250,0.7) 55%,
    rgba(27,184,166,0.1) 85%,
    transparent 100%
  );
  box-shadow: 0 0 16px rgba(27,184,166,0.7), 0 0 40px rgba(27,184,166,0.35);
  will-change: transform;
}
.rpma-e-stream::after {
  content: attr(data-sql);
  position: absolute;
  left: 10%;
  top: -1.15rem;
  font-family: Consolas, "Courier New", monospace;
  font-size: 11px;
  color: rgba(160,240,250,0.45);
  white-space: nowrap;
}
.rpma-e-particles {
  position: absolute;
  inset: 0;
  z-index: 2;
  pointer-events: none;
  overflow: hidden;
}
.rpma-e-particle {
  position: absolute;
  border-radius: 50%;
  background: rgba(140,255,245,0.9);
  box-shadow: 0 0 10px rgba(27,184,166,1);
  will-change: transform, opacity;
}
.rpma-e-bubbles {
  position: absolute;
  inset: 0;
  z-index: 3;
  pointer-events: none;
}
.rpma-e-bubble {
  position: absolute;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  border: 1.5px solid rgba(120,240,250,0.55);
  background:
    radial-gradient(circle at 35% 28%, rgba(200,255,250,0.28) 0%, transparent 42%),
    radial-gradient(circle at 50% 55%, rgba(20,70,90,0.45) 0%, rgba(6,24,36,0.65) 75%);
  box-shadow:
    inset 0 0 24px rgba(100,230,240,0.2),
    0 0 28px rgba(27,184,166,0.35),
    0 10px 28px rgba(0,0,0,0.3);
  color: rgba(220,255,250,0.95);
  font-size: clamp(0.7rem, 1.2vw, 0.88rem);
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: lowercase;
  text-align: center;
  padding: 0.55rem;
  line-height: 1.2;
  will-change: transform;
}
.rpma-e-center {
  position: relative;
  z-index: 10;
  width: min(400px, 92vw);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.9rem;
}
.rpma-e-mark {
  will-change: transform, filter;
  filter: drop-shadow(0 0 24px rgba(27,184,166,0.65));
}
.rpma-e-title {
  margin: 0;
  font-size: clamp(2rem, 4.5vw, 2.7rem);
  font-weight: 800;
  letter-spacing: -0.03em;
  text-align: center;
}
.rpma-e-title .rpm { color: #fff; }
.rpma-e-title .assure {
  color: #1bb8a6;
  text-shadow: 0 0 28px rgba(27,184,166,0.5);
}
.rpma-e-tag {
  margin: 0;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.28em;
  text-transform: uppercase;
  color: rgba(27,184,166,0.9);
}
.rpma-e-glass {
  width: 100%;
  max-width: 24rem;
  padding: 1.55rem 1.45rem 1.4rem;
  border-radius: 1.25rem;
  background: linear-gradient(165deg, rgba(20,50,70,0.58) 0%, rgba(8,24,40,0.78) 100%);
  border: 1px solid rgba(100,230,240,0.35);
  box-shadow:
    0 0 0 1px rgba(27,184,166,0.1),
    0 0 52px rgba(27,184,166,0.2),
    0 28px 64px rgba(0,0,0,0.5),
    inset 0 1px 0 rgba(200,255,250,0.12);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}
.rpma-e-glass h2 {
  margin: 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #fff;
  text-align: center;
}
.rpma-e-glass-sub {
  margin: 0.35rem 0 0;
  font-size: 0.8rem;
  color: rgba(180,220,230,0.72);
  text-align: center;
}
.rpma-e-form {
  margin-top: 1.15rem;
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}
.rpma-e-label {
  display: block;
  margin-bottom: 0.3rem;
  font-size: 0.75rem;
  font-weight: 600;
  color: rgba(200,230,235,0.88);
}
.rpma-e-field {
  position: relative;
  display: flex;
  align-items: center;
}
.rpma-e-field > svg:first-of-type {
  position: absolute;
  left: 0.75rem;
  color: rgba(140,200,210,0.8);
  pointer-events: none;
}
.rpma-e-field input {
  width: 100%;
  height: 2.65rem;
  padding: 0 0.9rem 0 2.35rem;
  border-radius: 0.7rem;
  border: 1px solid rgba(100,180,200,0.25);
  background: rgba(4,16,28,0.7);
  color: #f0f7ff;
  font-size: 0.9rem;
  outline: none;
}
.rpma-e-field input:focus {
  border-color: rgba(27,184,166,0.65);
  box-shadow: 0 0 0 3px rgba(27,184,166,0.18);
}
.rpma-e-field--pw input { padding-right: 2.5rem; }
.rpma-e-eye {
  position: absolute;
  right: 0.4rem;
  background: transparent;
  border: none;
  color: rgba(160,200,210,0.85);
  cursor: pointer;
  display: inline-flex;
  padding: 0.35rem;
}
.rpma-e-err { margin: 0; color: #f87171; font-size: 0.82rem; }
.rpma-e-submit {
  height: 2.75rem;
  margin-top: 0.2rem;
  border: none;
  border-radius: 0.7rem;
  background: linear-gradient(90deg, #0d9488 0%, #1bb8a6 50%, #2dd4bf 100%);
  color: #042f2e;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.4rem;
  will-change: box-shadow;
}
.rpma-e-submit:hover:not(:disabled) { transform: translateY(-1px); }
.rpma-e-submit:disabled { opacity: 0.7; cursor: wait; }
.rpma-e-footer {
  position: absolute;
  bottom: 1.1rem;
  left: 0;
  right: 0;
  z-index: 10;
  text-align: center;
  margin: 0;
  font-size: 0.78rem;
  color: rgba(160,210,220,0.5);
}
.rpma-e-live {
  position: absolute;
  top: 0.75rem;
  right: 0.85rem;
  z-index: 20;
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: rgba(27,184,166,0.75);
  pointer-events: none;
}
@media (max-width: 720px) {
  .rpma-e-stream::after { display: none; }
  .rpma-e-bubble { font-size: 0.68rem; }
}
`;

type Particle = { x: number; y: number; s: number; sp: number; o: number };

function useBioMotion(
  rootRef: { current: HTMLDivElement | null },
  markRef: { current: HTMLDivElement | null },
  btnRef: { current: HTMLButtonElement | null },
) {
  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    const rays = root.querySelector(".rpma-e-rays") as HTMLElement | null;
    const streams = Array.from(root.querySelectorAll(".rpma-e-stream")) as HTMLElement[];
    const bubbles = Array.from(root.querySelectorAll(".rpma-e-bubble")) as HTMLElement[];
    const particles = Array.from(root.querySelectorAll(".rpma-e-particle")) as HTMLElement[];

    // Stream top positions
    streams.forEach((el, i) => {
      el.style.top = `${12 + i * 14}%`;
    });

    const streamPhase = streams.map((_, i) => i * 0.9);
    const streamSpeed = streams.map((_, i) => (i % 2 === 0 ? 1 : -1) * (28 + i * 4));
    const bubblePhase = BUBBLE_DEFS.map((b) => b.phase);
    const pState: Particle[] = particles.map((_, i) => ({
      x: (i * 37) % 100,
      y: 100 + ((i * 19) % 40),
      s: 2 + (i % 4),
      sp: 18 + (i % 10) * 3,
      o: 0.4 + (i % 5) * 0.1,
    }));

    let raf = 0;
    let last = performance.now();
    let t = 0;

    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      t += dt;

      if (rays) {
        const o = 0.55 + 0.45 * Math.sin(t * 0.8);
        const x = Math.sin(t * 0.35) * 2.5;
        rays.style.opacity = String(o);
        rays.style.transform = `translateX(${x}%) scale(${1 + 0.02 * Math.sin(t * 0.5)})`;
      }

      streams.forEach((el, i) => {
        streamPhase[i] += streamSpeed[i] * dt;
        // wrap -40..40 percent
        let p = streamPhase[i];
        while (p > 40) p -= 80;
        while (p < -40) p += 80;
        streamPhase[i] = p;
        el.style.transform = `translate3d(${p}%, 0, 0)`;
      });

      bubbles.forEach((el, i) => {
        const def = BUBBLE_DEFS[i];
        if (!def) return;
        bubblePhase[i] += def.speed * dt;
        const dy = Math.sin(bubblePhase[i]) * 18;
        const dx = Math.cos(bubblePhase[i] * 0.7) * 10;
        const sc = 1 + 0.06 * Math.sin(bubblePhase[i] * 1.3);
        el.style.left = `${def.x}%`;
        el.style.top = `${def.y}%`;
        el.style.width = `${def.size}px`;
        el.style.height = `${def.size}px`;
        el.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${sc})`;
      });

      pState.forEach((p, i) => {
        p.y -= p.sp * dt * 0.35;
        p.x += Math.sin(t + i) * 0.08;
        if (p.y < -5) {
          p.y = 105;
          p.x = (p.x + 23) % 100;
        }
        const el = particles[i];
        if (!el) return;
        el.style.left = `${p.x}%`;
        el.style.top = `${p.y}%`;
        el.style.width = `${p.s}px`;
        el.style.height = `${p.s}px`;
        el.style.opacity = String(0.3 + 0.6 * (1 - p.y / 110));
      });

      if (markRef.current) {
        const s = 1 + 0.05 * Math.sin(t * 1.6);
        const g = 18 + 14 * (0.5 + 0.5 * Math.sin(t * 1.6));
        markRef.current.style.transform = `scale(${s})`;
        markRef.current.style.filter = `drop-shadow(0 0 ${g}px rgba(27,184,166,0.75))`;
      }

      if (btnRef.current) {
        const b = 24 + 16 * (0.5 + 0.5 * Math.sin(t * 2.2));
        btnRef.current.style.boxShadow = `0 8px ${b}px rgba(27,184,166,0.55)`;
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [rootRef, markRef, btnRef]);
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [fpsHint, setFpsHint] = useState("motion: on");

  const rootRef = useRef<HTMLDivElement>(null);
  const markRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);
  useBioMotion(rootRef, markRef, btnRef);

  useEffect(() => {
    let frames = 0;
    let last = performance.now();
    let id = 0;
    const loop = (now: number) => {
      frames++;
      if (now - last >= 1000) {
        setFpsHint(`motion: ${frames} fps`);
        frames = 0;
        last = now;
      }
      id = requestAnimationFrame(loop);
    };
    id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, []);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({ email: loginEmail, password });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div ref={rootRef} className="rpma-e-root" data-login-skin={LOGIN_SKIN}>
      <style>{OPTION_E_CSS}</style>
      <span className="rpma-e-live" aria-hidden="true">
        {fpsHint}
      </span>

      <div className="rpma-e-rays" aria-hidden="true" />
      <div className="rpma-e-streams" aria-hidden="true">
        {STREAM_SQL.map((line, i) => (
          <div key={i} className="rpma-e-stream" data-sql={line} />
        ))}
      </div>
      <div className="rpma-e-particles" aria-hidden="true">
        {Array.from({ length: 22 }).map((_, i) => (
          <span key={i} className="rpma-e-particle" />
        ))}
      </div>
      <div className="rpma-e-bubbles" aria-hidden="true">
        {BUBBLE_DEFS.map((b) => (
          <span key={b.text} className="rpma-e-bubble">
            {b.text}
          </span>
        ))}
      </div>

      <div className="rpma-e-center">
        <div ref={markRef} className="rpma-e-mark">
          <RpmAssureMark size={96} showWordmark={false} />
        </div>
        <h1 className="rpma-e-title">
          <span className="rpm">RPM</span>{" "}
          <span className="assure">Assure</span>
        </h1>
        <p className="rpma-e-tag">Assurance Delivered</p>

        <div className="rpma-e-glass">
          <IdleLogoutBanner />
          <h2>Sign in</h2>
          <p className="rpma-e-glass-sub">Welcome back. Secure access for RPM staff.</p>

          {!authEnabled ? (
            <p className="rpma-e-err" style={{ marginTop: 12 }}>
              Auth is disabled.
            </p>
          ) : (
            <form className="rpma-e-form" onSubmit={onSignIn}>
              <label>
                <span className="rpma-e-label">Email or username</span>
                <span className="rpma-e-field">
                  <User size={16} />
                  <input
                    type="text"
                    required
                    placeholder="Email or username"
                    autoComplete="username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </span>
              </label>

              <label>
                <span className="rpma-e-label">Password</span>
                <span className="rpma-e-field rpma-e-field--pw">
                  <Lock size={16} />
                  <input
                    type={showPw ? "text" : "password"}
                    required
                    minLength={8}
                    placeholder="Password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="rpma-e-eye"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    tabIndex={-1}
                  >
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </span>
              </label>

              {error ? <p className="rpma-e-err">{error}</p> : null}

              <button ref={btnRef} type="submit" className="rpma-e-submit" disabled={busy}>
                <Lock size={16} strokeWidth={2.25} />
                {busy ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}
        </div>
      </div>

      <p className="rpma-e-footer">Powered by RPM Resources</p>
    </div>
  );
}
