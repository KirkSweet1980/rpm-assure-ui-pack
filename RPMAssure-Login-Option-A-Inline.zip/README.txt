Option A with INLINE CSS. Run Apply-Login-Option-A-Inline.ps1 then private window.
