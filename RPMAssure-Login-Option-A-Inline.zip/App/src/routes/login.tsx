import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RpmAssureMark } from "@/components/brand/rpm-assure-mark";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";
import "@/styles/login-option-a.css";
export const Route = createFileRoute("/login")({
  component: LoginPage,
});

type FloatWin = {
  id: string;
  kind: "ps" | "sql" | "linux" | "macos";
  title: string;
  lines: string[];
  className: string;
};

/** One of each: PowerShell · SQL · Linux · macOS */
const FLOAT_WINDOWS: FloatWin[] = [
  {
    id: "win-ps",
    kind: "ps",
    title: "Windows PowerShell",
    className: "rpma-login-fwin rpma-login-fwin--ps rpma-login-fwin--tl",
    lines: [
      "PS C:\\> Get-Process | Select -First 6",
      "",
      "Handles  NPM(K)  PM(K)  Id  ProcessName",
      "-------  ------  -----  --  -----------",
      "  10316     122    156 Idle",
      "  39878    1134   1134 System",
      "  13376    1222    188 csrss",
      "  28164    1222    202 services",
      "  12936    1222    118 lsass",
      "  32248    1208    218 svchost",
      "",
      "PS C:\\> Get-Service WinRM",
      "Status  Name   DisplayName",
      "------  ----   -----------",
      "Running WinRM  Windows Remote Management",
    ],
  },
  {
    id: "win-sql",
    kind: "sql",
    title: "Microsoft SQL Server Management Studio",
    className: "rpma-login-fwin rpma-login-fwin--sql rpma-login-fwin--tr",
    lines: [
      "-- Query connected to RPMREPORTS",
      "USE [RPMAssure_App];",
      "GO",
      "",
      "SELECT",
      "    c.CustomerCode,",
      "    c.DisplayName,",
      "    COUNT(d.AccountId) AS Devices",
      "FROM dbo.Dim_Customer AS c",
      "LEFT JOIN dbo.Cove_DeviceStatistics AS d",
      "  ON d.CustomerCode = c.CustomerCode",
      "WHERE c.Active = 1",
      "GROUP BY c.CustomerCode, c.DisplayName",
      "ORDER BY Devices DESC;",
      "GO",
      "",
      "-- (21 rows affected)",
    ],
  },
  {
    id: "win-linux",
    kind: "linux",
    title: "user@rpm-linux: ~",
    className: "rpma-login-fwin rpma-login-fwin--linux rpma-login-fwin--bl",
    lines: [
      "user@rpm-linux:~$ uname -a",
      "Linux rpm-linux 6.8.0-51-generic #52-Ubuntu SMP x86_64 GNU/Linux",
      "",
      "user@rpm-linux:~$ df -h / /var",
      "Filesystem      Size  Used Avail Use% Mounted on",
      "/dev/sda2        98G   42G   52G  45% /",
      "/dev/sda4       200G   88G  102G  47% /var",
      "",
      "user@rpm-linux:~$ systemctl status ssh --no-pager",
      "● ssh.service - OpenBSD Secure Shell server",
      "     Active: active (running)",
      "",
      "user@rpm-linux:~$ _",
    ],
  },
  {
    id: "win-macos",
    kind: "macos",
    title: "Terminal — zsh — 80×24",
    className: "rpma-login-fwin rpma-login-fwin--macos rpma-login-fwin--br",
    lines: [
      "last login: Mon Aug 10 17:24:01 on ttys000",
      "rpm@MacBook-Pro ~ % sw_vers",
      "ProductName:		macOS",
      "ProductVersion:	15.5",
      "BuildVersion:	24F74",
      "",
      "rpm@MacBook-Pro ~ % top -l 1 | head -n 8",
      "Processes: 412 total, 3 running, 409 sleeping",
      "CPU usage: 8.2% user, 4.1% sys, 87.7% idle",
      "PhysMem: 18G used (2148M wired), 14G unused",
      "",
      "rpm@MacBook-Pro ~ % ping -c 2 10.0.0.1",
      "64 bytes from 10.0.0.1: icmp_seq=0 ttl=64 time=1.2 ms",
      "64 bytes from 10.0.0.1: icmp_seq=1 ttl=64 time=0.9 ms",
      "rpm@MacBook-Pro ~ % █",
    ],
  },
];

function lineClass(kind: FloatWin["kind"], line: string): string {
  if (kind === "ps") {
    if (line.startsWith("PS ") || line.startsWith(">>")) return "is-prompt";
    if (/Running|True/i.test(line)) return "is-ok";
  }
  if (kind === "sql") {
    if (line.startsWith("--")) return "is-comment";
    if (/^(SELECT|FROM|WHERE|LEFT|GROUP|ORDER|USE|GO)\b/i.test(line.trim()))
      return "is-kw";
    if (line.includes("rows affected")) return "is-ok";
  }
  if (kind === "linux") {
    if (line.includes("$ ")) return "is-prompt";
    if (line.startsWith("●") || /active \(running\)/i.test(line)) return "is-ok";
  }
  if (kind === "macos") {
    if (line.includes("% ") || line.startsWith("last login")) return "is-prompt";
    if (/ProductName|unused|ttl=/i.test(line)) return "is-ok";
  }
  return "";
}


/** Full-page SQL background — T-SQL style (no secrets) */
const SQL_BG_SCRIPT = [
  "-- =============================================",
  "-- RPM Assure  |  Estate health query workspace",
  "-- =============================================",
  "USE [RPMAssure_App];",
  "GO",
  "",
  "SET NOCOUNT ON;",
  "SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;",
  "",
  "DECLARE @AsOf date = CAST(SYSUTCDATETIME() AS date);",
  "DECLARE @StaleHours int = 24;",
  "",
  "/* Customer portfolio with cover + latest signals */",
  "SELECT",
  "    c.CustomerCode,",
  "    c.DisplayName,",
  "    c.Active,",
  "    cover.PillarSyspro,",
  "    cover.PillarPulseway,",
  "    cover.PillarCove,",
  "    cover.PillarBitdefender,",
  "    h.HealthRag,",
  "    h.HealthScorePct,",
  "    h.AssuranceScorePct,",
  "    h.LastImportAt,",
  "    DATEDIFF(hour, h.LastImportAt, SYSUTCDATETIME()) AS CollectAgeHours",
  "FROM dbo.Dim_Customer AS c",
  "LEFT JOIN dbo.Dim_Customer_AmsConfig AS cover",
  "  ON cover.CustomerCode = c.CustomerCode",
  "LEFT JOIN dbo.vw_Kpi_Customer_Health_Latest AS h",
  "  ON h.CustomerCode = c.CustomerCode",
  "WHERE c.Active = 1",
  "ORDER BY",
  "    CASE h.HealthRag WHEN N'Red' THEN 0 WHEN N'Amber' THEN 1 ELSE 2 END,",
  "    c.DisplayName;",
  "GO",
  "",
  "/* Remote management — servers offline */",
  "SELECT",
  "    d.CustomerCode,",
  "    COUNT(*) AS OfflineServers",
  "FROM dbo.Pulseway_Devices AS d",
  "WHERE d.SnapshotDate = @AsOf",
  "  AND d.IsOnline = 0",
  "  AND d.DeviceClass = N'Server'",
  "GROUP BY d.CustomerCode",
  "HAVING COUNT(*) > 0",
  "ORDER BY OfflineServers DESC;",
  "GO",
  "",
  "/* Cloud backup — failed or stale */",
  "SELECT",
  "    b.CustomerCode,",
  "    b.DeviceName,",
  "    b.LastBackupStatus,",
  "    b.LastSuccessTime,",
  "    b.RetentionPolicy,",
  "    b.UsedBytes",
  "FROM dbo.Cove_DeviceStatistics AS b",
  "WHERE b.SnapshotDate = @AsOf",
  "  AND (",
  "        b.LastBackupStatus IN (N'Failed', N'Overdue', N'Stale')",
  "     OR b.LastSuccessTime < DATEADD(hour, -36, SYSUTCDATETIME())",
  "  )",
  "ORDER BY b.CustomerCode, b.DeviceName;",
  "GO",
  "",
  "/* Endpoint protection estate */",
  "SELECT",
  "    e.CustomerCode,",
  "    COUNT(*) AS Endpoints,",
  "    SUM(CASE WHEN e.IsManaged = 1 THEN 1 ELSE 0 END) AS Managed",
  "FROM dbo.Bitdefender_Endpoints AS e",
  "WHERE e.SnapshotDate = @AsOf",
  "GROUP BY e.CustomerCode",
  "ORDER BY Endpoints DESC;",
  "GO",
  "",
  "/* Open risks needing EXCO attention */",
  "SELECT",
  "    r.CustomerCode,",
  "    r.Title,",
  "    r.Rag,",
  "    r.Status,",
  "    r.OwnerName,",
  "    r.TargetDate",
  "FROM dbo.Fact_Risk AS r",
  "WHERE r.Status NOT IN (N'Closed', N'Resolved')",
  "ORDER BY",
  "    CASE r.Rag WHEN N'Red' THEN 0 WHEN N'Amber' THEN 1 ELSE 2 END,",
  "    r.TargetDate;",
  "GO",
  "",
  "-- (rows affected)  clarity · source of truth · trust",
  "PRINT N'Query complete — assurance delivered.';",
  "GO",
] as const;

function sqlLineClass(line: string): string {
  const s = line.trim();
  if (!s) return "is-blank";
  if (s.startsWith("--") || (s.startsWith("/*") || s.endsWith("*/"))) return "is-comment";
  if (/^(USE|GO|SET|DECLARE|SELECT|FROM|LEFT|WHERE|GROUP|ORDER|HAVING|AND|OR|ON|CASE|WHEN|THEN|ELSE|END|PRINT|JOIN)\b/i.test(s))
    return "is-kw";
  if (s.includes("N'") || s.includes("'")) return "is-str";
  return "is-code";
}


/** Option A: six value chips once each — outer edges only */
const LOGIN_PAGE_WORDS = [
  { text: "clarity", className: "rpma-lw rpma-lw--L1" },
  { text: "source of truth", className: "rpma-lw rpma-lw--L2" },
  { text: "insight", className: "rpma-lw rpma-lw--L3" },
  { text: "visibility", className: "rpma-lw rpma-lw--R1" },
  { text: "confidence", className: "rpma-lw rpma-lw--R2" },
  { text: "evidence", className: "rpma-lw rpma-lw--R3" },
] as const;

function LoginPageWords() {
  return (
    <div className="rpma-login-page-words" aria-hidden="true">
      {LOGIN_PAGE_WORDS.map((w) => (
        <span key={w.text} className={w.className}>
          <i className="rpma-lw-dot" />
          {w.text}
        </span>
      ))}
    </div>
  );
}

function LoginSqlBackground() {
  // Repeat script so tall viewports stay filled; 3 columns for depth
  const block = [...SQL_BG_SCRIPT, "", ...SQL_BG_SCRIPT, "", ...SQL_BG_SCRIPT];
  return (
    <div className="rpma-login-sql-bg" aria-hidden="true">
      <div className="rpma-login-sql-bg-fade" />
      {[0, 1, 2].map((col) => (
        <div
          key={col}
          className={`rpma-login-sql-col rpma-login-sql-col--${col + 1}`}
        >
          <div className="rpma-login-sql-track">
            {block.map((line, i) => (
              <div key={`${col}-${i}`} className={`rpma-login-sql-line ${sqlLineClass(line)}`}>
                <span className="rpma-login-sql-gutter">{String((i % SQL_BG_SCRIPT.length) + 1).padStart(3, " ")}</span>
                <span className="rpma-login-sql-text">{line || " "}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}


function FloatWindow({ win }: { win: FloatWin }) {
  return (
    <div className={win.className} aria-hidden="true">
      <div className="rpma-login-fwin-bar">
        <span className="rpma-login-fwin-dots">
          <i />
          <i />
          <i />
        </span>
        <span className="rpma-login-fwin-title">{win.title}</span>
      </div>
      <div className="rpma-login-fwin-body">
        {win.lines.map((line, i) => (
          <div key={i} className={lineClass(win.kind, line)}>
            {line || "\u00a0"}
          </div>
        ))}
      </div>
    </div>
  );
}

const OPTION_A_INLINE_CSS = "\n/** OPTION_A_INLINE_SKIN **/\n.rpma-login-hero--option-a{\n  position:relative!important;min-height:100dvh!important;width:100%!important;\n  overflow:hidden!important;display:flex!important;align-items:center!important;\n  justify-content:center!important;background:#050d18!important;color:#e8f4ff!important;\n  isolation:isolate!important;\n}\n.rpma-login-hero--option-a .rpma-login-brand-words,\n.rpma-login-hero--option-a .rpma-login-ps-stage,\n.rpma-login-hero--option-a .rpma-login-hero-grid,\n.rpma-login-hero--option-a .rpma-login-word-wm-layer{display:none!important}\n\n/* SQL full bleed - deliberately strong so change is obvious */\n.rpma-login-hero--option-a .rpma-login-sql-bg{\n  position:absolute!important;inset:0!important;z-index:0!important;\n  display:grid!important;grid-template-columns:1fr 1fr 1fr!important;\n  overflow:hidden!important;pointer-events:none!important;\n  font-family:Consolas,\"Courier New\",ui-monospace,monospace!important;\n  opacity:1!important;\n}\n.rpma-login-hero--option-a .rpma-login-sql-col{opacity:.55!important;overflow:hidden!important;position:relative!important}\n.rpma-login-hero--option-a .rpma-login-sql-col--2{opacity:.4!important}\n.rpma-login-hero--option-a .rpma-login-sql-col--3{opacity:.48!important}\n.rpma-login-hero--option-a .rpma-login-sql-track{\n  padding:1rem .75rem 2rem!important;\n  animation:rpmaOptASql 48s linear infinite!important;will-change:transform!important;\n}\n.rpma-login-hero--option-a .rpma-login-sql-col--2 .rpma-login-sql-track{animation-duration:62s!important;animation-direction:reverse!important;padding-top:3rem!important}\n.rpma-login-hero--option-a .rpma-login-sql-col--3 .rpma-login-sql-track{animation-duration:54s!important;padding-top:1.5rem!important}\n@keyframes rpmaOptASql{0%{transform:translateY(0)}100%{transform:translateY(-33.333%)}}\n.rpma-login-hero--option-a .rpma-login-sql-line{display:flex!important;gap:.55rem!important;font-size:11px!important;line-height:1.5!important;white-space:pre!important}\n.rpma-login-hero--option-a .rpma-login-sql-gutter{flex:0 0 1.75rem!important;text-align:right!important;color:rgba(120,150,170,.4)!important}\n.rpma-login-hero--option-a .rpma-login-sql-text{color:rgba(170,205,230,.65)!important}\n.rpma-login-hero--option-a .rpma-login-sql-line.is-kw .rpma-login-sql-text{color:rgba(100,170,230,.95)!important;font-weight:700!important}\n.rpma-login-hero--option-a .rpma-login-sql-line.is-comment .rpma-login-sql-text{color:rgba(120,180,100,.75)!important;font-style:italic!important}\n.rpma-login-hero--option-a .rpma-login-sql-line.is-str .rpma-login-sql-text{color:rgba(220,160,130,.8)!important}\n.rpma-login-hero--option-a .rpma-login-sql-bg-fade{\n  position:absolute!important;inset:0!important;z-index:2!important;pointer-events:none!important;\n  background:linear-gradient(90deg,rgba(5,12,22,.5) 0%,transparent 20%,transparent 80%,rgba(5,12,22,.5) 100%)!important;\n}\n.rpma-login-hero--option-a .rpma-login-sql-vignette{\n  position:absolute!important;inset:0!important;z-index:1!important;pointer-events:none!important;\n  background:radial-gradient(ellipse 46% 52% at 50% 44%,rgba(5,12,22,.9) 0%,rgba(5,12,22,.65) 42%,rgba(5,12,22,.2) 72%,transparent 100%)!important;\n}\n\n/* Edge chips - large and obvious */\n.rpma-login-hero--option-a .rpma-login-page-words{\n  position:absolute!important;inset:0!important;z-index:3!important;pointer-events:none!important;overflow:hidden!important;\n}\n.rpma-login-hero--option-a .rpma-lw{\n  position:absolute!important;display:inline-flex!important;align-items:center!important;gap:.5rem!important;\n  padding:.5rem 1rem .5rem .75rem!important;border-radius:999px!important;\n  border:1px solid rgba(27,184,166,.65)!important;background:rgba(6,30,50,.92)!important;\n  color:#b8fff4!important;font-size:.95rem!important;font-weight:700!important;\n  letter-spacing:.03em!important;text-transform:lowercase!important;white-space:nowrap!important;\n  box-shadow:0 6px 24px rgba(0,0,0,.45),0 0 0 1px rgba(27,184,166,.15),0 0 20px rgba(27,184,166,.15)!important;\n  animation:rpmaOptAChip 5.5s ease-in-out infinite!important;\n}\n.rpma-login-hero--option-a .rpma-lw-dot{\n  width:.55rem!important;height:.55rem!important;border-radius:50%!important;\n  background:#1bb8a6!important;box-shadow:0 0 10px #1bb8a6!important;flex:0 0 auto!important;\n}\n.rpma-login-hero--option-a .rpma-lw--L1{top:18%!important;left:2%!important;animation-delay:0s!important}\n.rpma-login-hero--option-a .rpma-lw--L2{top:42%!important;left:1.25%!important;animation-delay:.7s!important}\n.rpma-login-hero--option-a .rpma-lw--L3{top:66%!important;left:2%!important;animation-delay:1.4s!important}\n.rpma-login-hero--option-a .rpma-lw--R1{top:18%!important;right:2%!important;animation-delay:.35s!important}\n.rpma-login-hero--option-a .rpma-lw--R2{top:42%!important;right:1.25%!important;animation-delay:1s!important}\n.rpma-login-hero--option-a .rpma-lw--R3{top:66%!important;right:2%!important;animation-delay:1.7s!important}\n@keyframes rpmaOptAChip{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}\n\n.rpma-login-hero--option-a .rpma-login-hero-center{\n  position:relative!important;z-index:10!important;width:min(420px,92vw)!important;\n  display:flex!important;flex-direction:column!important;align-items:center!important;gap:1.1rem!important;\n}\n.rpma-login-hero--option-a .rpma-login-hero-rpm{color:#fff!important;-webkit-text-fill-color:#fff!important}\n.rpma-login-hero--option-a .rpma-login-hero-assure{color:#1bb8a6!important;-webkit-text-fill-color:#1bb8a6!important}\n.rpma-login-hero--option-a .rpma-login-glass{width:100%!important;max-width:24rem!important;z-index:2!important}\n.rpma-login-hero--option-a .rpma-login-hero-footer{\n  position:absolute!important;bottom:1rem!important;left:0!important;right:0!important;z-index:10!important;\n  text-align:center!important;color:rgba(180,210,230,.55)!important;font-size:.78rem!important;margin:0!important;\n}\n@media (max-width:700px){\n  .rpma-login-hero--option-a .rpma-login-page-words{display:none!important}\n}\n@media (prefers-reduced-motion:reduce){\n  .rpma-login-hero--option-a .rpma-lw,\n  .rpma-login-hero--option-a .rpma-login-sql-track{animation:none!important}\n}\n";

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) {
        throw new Error("Password must be at least 8 characters.");
      }
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({
        email: loginEmail,
        password,
      });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      // 2FA deferred — ignore twoFactorRedirect for now and enter app
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rpma-login-hero rpma-login-hero--option-a" data-login-skin="option-a">
      <style dangerouslySetInnerHTML={{ __html: OPTION_A_INLINE_CSS }} />
      <div className="rpma-login-hero-bg" aria-hidden="true" />
      <LoginSqlBackground />
      <div className="rpma-login-sql-vignette" aria-hidden="true" />
      <LoginPageWords />

      <div className="rpma-login-hero-center">
        <div className="rpma-login-hero-brand">
          <div className="rpma-login-hero-mark">
            <RpmAssureMark size={108} showWordmark={false} className="rpma-mark-pulse" />
          </div>
          <h1 className="rpma-login-hero-title">
            <span className="rpma-login-hero-rpm">RPM</span>{" "}
            <span className="rpma-login-hero-assure">Assure</span>
          </h1>
          <p className="rpma-login-hero-tag">
            <span className="rpma-login-hero-tag-line">Assurance Delivered</span>
          </p>
        </div>

        <div className="rpma-login-glass">
          <IdleLogoutBanner />
          <h2 className="rpma-login-glass-title">Sign in</h2>

          {!authEnabled ? (
            <p className="rpma-login-glass-error">Auth is disabled.</p>
          ) : (
            <form className="rpma-login-glass-form" onSubmit={onSignIn}>
              <label className="rpma-login-field">
                <span className="rpma-login-field-label">Email or username</span>
                <span className="rpma-login-field-wrap">
                  <User className="rpma-login-field-icon" size={16} strokeWidth={2} />
                  <input
                    type="text"
                    required
                    placeholder="Email or username"
                    autoComplete="username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </span>
              </label>

              <label className="rpma-login-field">
                <span className="rpma-login-field-label">Password</span>
                <span className="rpma-login-field-wrap rpma-login-field-wrap--password">
                  <Lock className="rpma-login-field-icon" size={16} strokeWidth={2} />
                  <input
                    type={showPw ? "text" : "password"}
                    required
                    minLength={8}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="rpma-login-field-eye"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    tabIndex={-1}
                  >
                    {showPw ? (
                      <EyeOff size={16} strokeWidth={2} />
                    ) : (
                      <Eye size={16} strokeWidth={2} />
                    )}
                  </button>
                </span>
              </label>

              {error ? <p className="rpma-login-glass-error">{error}</p> : null}

              <button
                type="submit"
                className="rpma-login-glass-submit"
                disabled={busy}
              >
                <Lock size={16} strokeWidth={2.25} />
                {busy ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}
        </div>
      </div>

      <p className="rpma-login-hero-footer">Powered by RPM Resources</p>
    </div>
  );
}
