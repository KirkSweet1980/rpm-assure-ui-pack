﻿# Apply-Exco-Label-Tweaks.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $Here 'App\src\routes\index.tsx'
$dst = 'C:\RPM-Assure\App\src\routes\index.tsx'
Copy-Item -LiteralPath $src -Destination $dst -Force
Write-Host "OK $dst"
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 5
} catch { Write-Host $_ }
Write-Host 'Hard-refresh Exco Insight.'
Write-Host '=== Done ==='
