import { Link, createFileRoute } from "@tanstack/react-router";
import {
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { useMemo } from "react";
import { RequireAuth } from "@/components/portfolio/require-auth";
import { AppShell } from "@/components/portfolio/app-shell";
import { ChartTooltip } from "@/components/portfolio/chart-tooltip";
import { InfoTag } from "@/components/portfolio/info-tag";
import { RagBadge } from "@/components/portfolio/rag-badge";
import { StatCard } from "@/components/portfolio/stat-card";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHead } from "@/components/ui/card";
import { CHART } from "@/lib/brand-colors";
import { fetchDataSourceStatus, fetchPortfolio } from "@/lib/data/portfolio";
import { useStaffProfile } from "@/lib/auth/use-staff-profile";
import { useDashboardConfig } from "@/lib/settings/use-dashboard-config";
import type { ExcoCustomerBoard, ExcoInsightPayload } from "@/lib/data/types";
import { cn, formatSastDateTime } from "@/lib/utils";
import { ChevronRight, TriangleAlert } from "lucide-react";

export const Route = createFileRoute("/")({
  loader: async () => {
    const [portfolio, source] = await Promise.all([
      fetchPortfolio(),
      fetchDataSourceStatus(),
    ]);
    return { portfolio, source };
  },
  component: ExcoInsightPage,
});

function CustLink({ code, name }: { code: string; name: string }) {
  return (
    <Link
      to="/customers/$code"
      params={{ code }}
      className="font-medium text-fg hover:text-accent"
    >
      {name}
    </Link>
  );
}

function deriveExcoFromRows(
  rows: {
    customerCode: string;
    displayName: string;
    healthRag: "Red" | "Amber" | "Green";
    healthSummary: string;
    activeUserCount: number;
    operatorCount: number;
    sysproJobErrorCount: number;
    sysproDtrVarianceLines: number;
    lastImportAt: string | null;
    sqlInstanceName?: string | null;
    cover?: { syspro: boolean; rmm: boolean; cove: boolean };
    pulsewayDeviceCount?: number;
    pulsewayOfflineCount?: number;
    pulsewayOnlineCount?: number;
    pulsewayCriticalAlerts?: number;
    pulsewayHealthRag?: "Red" | "Amber" | "Green" | null;
    pulsewayHealthSummary?: string | null;
    pulsewayServerOnline?: number;
    pulsewayServerOffline?: number;
    pulsewayWorkstationOnline?: number;
    pulsewayWorkstationOffline?: number;
  }[],
): ExcoInsightPayload {
  const boards: ExcoCustomerBoard[] = rows.map((row) => {
    const collectAgeHours = row.lastImportAt
      ? Math.round(
          ((Date.now() - new Date(row.lastImportAt).getTime()) / 3600000) * 10,
        ) / 10
      : null;
    const collectFresh = collectAgeHours != null && collectAgeHours <= 24;
    const cov = row.cover ?? {
      syspro: (row.operatorCount ?? 0) > 0 || Boolean(row.sqlInstanceName),
      rmm: (row.pulsewayDeviceCount ?? 0) > 0,
      cove: false,
    };
    const healthScorePct =
      row.healthRag === "Green" ? 88 : row.healthRag === "Amber" ? 58 : 28;
    const collectPart = cov.syspro ? (collectFresh ? 100 : 30) : 100;
    const jobsPart = cov.syspro ? (row.sysproJobErrorCount === 0 ? 100 : 40) : 100;
    const assuranceScorePct = Math.round(
      healthScorePct * 0.55 + collectPart * 0.25 + jobsPart * 0.2,
    );
    const attentionReasons: string[] = [];
    if (row.healthRag !== "Green") attentionReasons.push(`Health ${row.healthRag}`);
    if (cov.syspro && !collectFresh)
      attentionReasons.push(
        collectAgeHours == null ? "No SYSPRO collect" : `SYSPRO collect stale (${collectAgeHours}h)`,
      );
    if (cov.syspro && row.sysproJobErrorCount > 0)
      attentionReasons.push(`${row.sysproJobErrorCount} job error(s)`);
    if (cov.syspro && row.sysproDtrVarianceLines > 0)
      attentionReasons.push(`${row.sysproDtrVarianceLines} FinSight Out of Balance`);
    if (cov.rmm && (row.pulsewayCriticalAlerts ?? 0) > 0)
      attentionReasons.push(`${row.pulsewayCriticalAlerts} RMM critical`);
    if (cov.rmm && (row.pulsewayOfflineCount ?? 0) > 0)
      attentionReasons.push(`${row.pulsewayOfflineCount} RMM offline`);
    if (!cov.syspro && !cov.rmm && !cov.cove)
      attentionReasons.push("No service cover");
    return {
      customerCode: row.customerCode,
      displayName: row.displayName,
      healthRag: row.healthRag,
      healthSummary: row.healthSummary,
      healthScorePct,
      assuranceScorePct,
      collectAgeHours,
      collectFresh,
      lastImportAt: row.lastImportAt,
      activeUserCount: row.activeUserCount,
      operatorCount: row.operatorCount,
      jobErrorCount: row.sysproJobErrorCount,
      dtrVarianceLines: row.sysproDtrVarianceLines,
      slaCompliancePct: null,
      availabilityPct: null,
      licenseExpiry: null,
      licenseProduct: null,
      licenseDaysRemaining: null,
      openRiskCount: 0,
      openIssueCount: 0,
      lastFullBackup: null,
      backupStatus: null,
      backupHealthy: null,
      sysproVersion: null,
      sysproBuild: null,
      installedHotfixCount: 0,
      lastHotfixAt: null,
      sampleHotfixCode: null,
      missingHotfixCount: null,
      missingMandatoryHotfixes: null,
      sysproCovered: cov.syspro === true,
      attentionReasons,
      pulsewayDeviceCount: row.pulsewayDeviceCount ?? 0,
      pulsewayOnlineCount: row.pulsewayOnlineCount ?? 0,
      pulsewayOfflineCount: row.pulsewayOfflineCount ?? 0,
      pulsewayCriticalAlerts: row.pulsewayCriticalAlerts ?? 0,
      pulsewayHealthRag: row.pulsewayHealthRag ?? null,
      pulsewayHealthSummary: row.pulsewayHealthSummary ?? null,
      pulsewayServerOnline: row.pulsewayServerOnline ?? 0,
      pulsewayServerOffline: row.pulsewayServerOffline ?? 0,
      pulsewayWorkstationOnline: row.pulsewayWorkstationOnline ?? 0,
      pulsewayWorkstationOffline: row.pulsewayWorkstationOffline ?? 0,
    };
  });
  return {
    generatedAt: new Date().toISOString(),
    estateAssurancePct:
      boards.length === 0
        ? 0
        : Math.round(
            boards.reduce((s, b) => s + b.assuranceScorePct, 0) / boards.length,
          ),
    customersNeedingAttention: boards.filter((b) => b.attentionReasons.length > 0)
      .length,
    collectFreshCount: boards.filter((b) => b.collectFresh).length,
    collectStaleCount: boards.filter(
      (b) => !b.collectFresh && b.collectAgeHours != null,
    ).length,
    collectMissingCount: boards.filter((b) => b.lastImportAt == null).length,
    licensesExpiringSoon: 0,
    openRisksTotal: 0,
    openIssuesTotal: 0,
    backupUnhealthyCount: 0,
    installedHotfixesTotal: 0,
    customersWithHotfixes: 0,
    customersMissingHotfixes: boards.length,
    rmmDevicesTotal: boards.reduce((s, b) => s + (b.pulsewayDeviceCount || 0), 0),
    rmmOfflineTotal: boards.reduce((s, b) => s + (b.pulsewayOfflineCount || 0), 0),
    rmmCriticalTotal: boards.reduce((s, b) => s + (b.pulsewayCriticalAlerts || 0), 0),
    rmmCustomersWithDevices: boards.filter((b) => (b.pulsewayDeviceCount || 0) > 0)
      .length,
    rmmCustomersUnhealthy: boards.filter(
      (b) =>
        (b.pulsewayDeviceCount || 0) > 0 &&
        (b.pulsewayHealthRag === "Red" || b.pulsewayHealthRag === "Amber"),
    ).length,
    rmmServerOnlineTotal: boards.reduce((s, b) => s + (b.pulsewayServerOnline || 0), 0),
    rmmServerOfflineTotal: boards.reduce((s, b) => s + (b.pulsewayServerOffline || 0), 0),
    rmmWorkstationOnlineTotal: boards.reduce(
      (s, b) => s + (b.pulsewayWorkstationOnline || 0),
      0,
    ),
    rmmWorkstationOfflineTotal: boards.reduce(
      (s, b) => s + (b.pulsewayWorkstationOffline || 0),
      0,
    ),
    boards,
  };
}

function ExcoInsightPage() {
  const { portfolio, source } = Route.useLoaderData();
  const { summary, rows: rowsList, customers, exco: excoRaw } = portfolio;
  const allRows = rowsList ?? customers ?? [];
  const { profile } = useStaffProfile();
  const { dashboard: dash } = useDashboardConfig();

  const rows = useMemo(() => {
    const codes = profile?.allowedCustomerCodes;
    if (!codes || codes.length === 0) return allRows;
    const set = new Set(codes.map((c) => c.toUpperCase()));
    return allRows.filter((r) => set.has(r.customerCode.toUpperCase()));
  }, [allRows, profile?.allowedCustomerCodes]);

  const exco = useMemo(() => {
    const base = excoRaw ?? deriveExcoFromRows(rows);
    if (rows === allRows) return base;
    const set = new Set(rows.map((r) => r.customerCode.toUpperCase()));
    const boards = base.boards.filter((b) => set.has(b.customerCode.toUpperCase()));
    return {
      ...base,
      boards,
      customersNeedingAttention: boards.filter((b) => b.attentionReasons.length > 0)
        .length,
      collectFreshCount: boards.filter((b) => b.collectFresh).length,
      collectStaleCount: boards.filter(
        (b) => !b.collectFresh && b.collectAgeHours != null,
      ).length,
      collectMissingCount: boards.filter((b) => b.lastImportAt == null).length,
      estateAssurancePct:
        boards.length === 0
          ? 0
          : Math.round(
              boards.reduce((s, b) => s + b.assuranceScorePct, 0) / boards.length,
            ),
      openRisksTotal: boards.reduce((s, b) => s + b.openRiskCount, 0),
      openIssuesTotal: boards.reduce((s, b) => s + b.openIssueCount, 0),
      licensesExpiringSoon: boards.filter(
        (b) =>
          b.licenseDaysRemaining != null &&
          b.licenseDaysRemaining >= 0 &&
          b.licenseDaysRemaining <= 90,
      ).length,
      backupUnhealthyCount: boards.filter((b) => b.backupHealthy === false).length,
      rmmDevicesTotal: boards.reduce((s, b) => s + (b.pulsewayDeviceCount || 0), 0),
      rmmOfflineTotal: boards.reduce((s, b) => s + (b.pulsewayOfflineCount || 0), 0),
      rmmCriticalTotal: boards.reduce(
        (s, b) => s + (b.pulsewayCriticalAlerts || 0),
        0,
      ),
      rmmServerOfflineTotal: boards.reduce(
        (s, b) => s + (b.pulsewayServerOffline || 0),
        0,
      ),
      rmmServerOnlineTotal: boards.reduce((s, b) => s + (b.pulsewayServerOnline || 0), 0),
    };
  }, [excoRaw, rows, allRows]);

  const attention = useMemo(
    () =>
      [...exco.boards]
        .filter((b) => b.attentionReasons.length > 0)
        .sort(
          (a, b) =>
            (a.healthRag === "Red" ? 0 : a.healthRag === "Amber" ? 1 : 2) -
              (b.healthRag === "Red" ? 0 : b.healthRag === "Amber" ? 1 : 2) ||
            b.attentionReasons.length - a.attentionReasons.length,
        ),
    [exco.boards],
  );

  const healthPie = useMemo(() => {
    let g = 0,
      a = 0,
      r = 0;
    for (const b of exco.boards) {
      if (b.healthRag === "Green") g++;
      else if (b.healthRag === "Amber") a++;
      else r++;
    }
    return [
      { name: "Healthy", value: g, fill: CHART.green },
      { name: "Watch", value: a, fill: CHART.amber },
      { name: "Critical", value: r, fill: CHART.red },
    ].filter((d) => d.value > 0);
  }, [exco.boards]);

  const coverStats = useMemo(() => {
    let syspro = 0,
      rmm = 0,
      cove = 0,
      epp = 0,
      csp = 0;
    for (const row of rows) {
      const c = row.cover;
      if (c?.syspro) syspro++;
      if (c?.rmm || (row.pulsewayDeviceCount ?? 0) > 0) rmm++;
      if (c?.cove || (row.coveDeviceCount ?? 0) > 0) cove++;
      if (c?.epp || (row.eppDeviceCount ?? 0) > 0) epp++;
      if (c?.csp) csp++;
    }
    return { syspro, rmm, cove, epp, csp, n: rows.length };
  }, [rows]);

  const scoreboard = useMemo(() => {
    return [...exco.boards]
      .map((b) => {
        const row = rows.find(
          (r) => r.customerCode.toUpperCase() === b.customerCode.toUpperCase(),
        );
        const c = row?.cover;
        return {
          ...b,
          coverSyspro: c?.syspro === true || b.sysproCovered === true,
          coverRmm: c?.rmm === true || (b.pulsewayDeviceCount || 0) > 0,
          coverCove: c?.cove === true || (row?.coveDeviceCount || 0) > 0,
          coverEpp: c?.epp === true || (row?.eppDeviceCount || 0) > 0,
          coverCsp: c?.csp === true,
        };
      })
      .sort(
        (a, b) =>
          (a.healthRag === "Red" ? 0 : a.healthRag === "Amber" ? 1 : 2) -
            (b.healthRag === "Red" ? 0 : b.healthRag === "Amber" ? 1 : 2) ||
          a.assuranceScorePct - b.assuranceScorePct,
      );
  }, [exco.boards, rows]);

  const liveLabel =
    source.liveOk || summary.dataMode === "live" ? "Live SQL" : "Demo data";

  const estateTone =
    exco.estateAssurancePct >= 80
      ? "green"
      : exco.estateAssurancePct >= 55
        ? "amber"
        : "red";

  return (
    <RequireAuth>
      <AppShell
        title={dash.estateTitle || "Exco Insight"}
        subtitle={
          (dash.estateSubtitle || "").trim() ||
          "High-Level Customer Estate View - EXCO"
        }
      >
        <div className="rpma-exco space-y-5">
          {/* Status */}
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant={summary.dataMode === "demo" ? "amber" : "green"}>
              {liveLabel}
            </Badge>
            {source.liveOk ? (
              <Badge variant="green">SQL connected</Badge>
            ) : source.error ? (
              <Badge variant="red">SQL issue</Badge>
            ) : null}
            <span className="text-[11px] text-subtle">
              As of {formatSastDateTime(exco.generatedAt || summary.generatedAt)}
            </span>
            <span className="text-[11px] text-subtle">
              · {exco.boards.length} customers
            </span>
          </div>

          {/* 1. Estate pulse — 5 executive KPIs */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <StatCard
              label="Estate assurance"
              value={`${exco.estateAssurancePct}%`}
              tone={estateTone}
              tip="Average health across all customers (0–100). Aim for 80%+."
            />
            <StatCard
              label="Need attention"
              value={exco.customersNeedingAttention}
              tone={exco.customersNeedingAttention > 0 ? "amber" : "green"}
              tip="Customers with red/amber health or other watch signals."
            />
            <StatCard
              label="Servers offline"
              value={exco.rmmServerOfflineTotal ?? 0}
              tone={(exco.rmmServerOfflineTotal ?? 0) > 0 ? "red" : "green"}
              tip="Servers not online under RPM Remote Management."
            />
            <StatCard
              label="Critical alerts"
              value={exco.rmmCriticalTotal ?? 0}
              tone={(exco.rmmCriticalTotal ?? 0) > 0 ? "red" : "green"}
              tip="Critical RMM alerts across the estate."
            />
            <StatCard
              label="Open risks"
              value={exco.openRisksTotal}
              tone={exco.openRisksTotal > 0 ? "amber" : "green"}
              tip="Open AMS risk items still needing a decision or mitigation."
            />
          </div>

          {/* 2. Estate health distribution + Priority list */}
          <div className="grid gap-4 lg:grid-cols-12">
            <Card className="lg:col-span-4">
              <CardHead className="!normal-case !tracking-normal">
                <span className="text-[13px] font-bold text-fg">
                  Customer Health Mix
                </span>
                <InfoTag title="Share of customers that look healthy (green), need watching (amber), or are critical (red).">
                  ?
                </InfoTag>
              </CardHead>
              <CardContent className="space-y-3">
                <div className="h-44">
                  {healthPie.length === 0 ? (
                    <p className="text-sm text-muted">No customers loaded.</p>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          isAnimationActive
                          data={healthPie}
                          dataKey="value"
                          nameKey="name"
                          innerRadius={48}
                          outerRadius={72}
                          paddingAngle={2}
                        >
                          {healthPie.map((e, i) => (
                            <Cell key={i} fill={e.fill} stroke="transparent" />
                          ))}
                        </Pie>
                        <Tooltip content={<ChartTooltip />} />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
                <div className="flex flex-wrap justify-center gap-3 text-[11px] text-muted">
                  {healthPie.map((d) => (
                    <span key={d.name} className="inline-flex items-center gap-1.5">
                      <span
                        className="h-2 w-2 rounded-full"
                        style={{ background: d.fill }}
                      />
                      {d.name} {d.value}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-8">
              <CardHead className="!normal-case !tracking-normal">
                <div className="flex w-full items-center gap-2">
                  <TriangleAlert className="h-4 w-4 text-rag-amber" aria-hidden />
                  <span className="text-[13px] font-bold text-fg">
                    Priority | Customers Needing Attention
                  </span>
                  <Badge variant="amber" className="ml-auto">
                    {attention.length}
                  </Badge>
                </div>
              </CardHead>
              <CardContent className="max-h-72 overflow-y-auto">
                {attention.length === 0 ? (
                  <p className="text-sm text-muted">
                    All customers are clear on current signals.
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {attention.slice(0, 12).map((b) => (
                      <li key={b.customerCode}>
                        <Link
                          to="/customers/$code"
                          params={{ code: b.customerCode }}
                          className="flex items-start gap-2.5 rounded-lg border border-border/80 bg-bg/40 px-2.5 py-2 transition hover:border-accent/40"
                        >
                          <RagBadge rag={b.healthRag} />
                          <span className="min-w-0 flex-1">
                            <span className="block text-sm font-semibold text-fg">
                              {b.displayName}
                            </span>
                            <span className="mt-0.5 flex flex-wrap gap-1">
                              {b.attentionReasons.slice(0, 4).map((r) => (
                                <Badge key={r} variant="muted">
                                  {r}
                                </Badge>
                              ))}
                            </span>
                          </span>
                          <span className="font-mono text-xs font-semibold text-muted">
                            {b.assuranceScorePct}%
                          </span>
                          <ChevronRight className="mt-0.5 h-4 w-4 text-subtle" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>

          {/* 3. Service coverage — high level product adoption */}
          <Card>
            <CardHead className="!normal-case !tracking-normal">
              <span className="text-[13px] font-bold text-fg">
                Module Cover Entire Estate
              </span>
              <InfoTag title="How many customers are on each RPM Assure service. Covered means data or contract scope is present.">
                ?
              </InfoTag>
            </CardHead>
            <CardContent>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                {(
                  [
                    {
                      label: "SYSPRO Deployment",
                      n: coverStats.syspro,
                      tip: "Customers with SYSPRO cover",
                    },
                    {
                      label: "Remote Management",
                      n: coverStats.rmm,
                      tip: "Customers with RMM / Pulseway devices",
                    },
                    {
                      label: "Cloud Backup",
                      n: coverStats.cove,
                      tip: "Customers with Cove backup devices",
                    },
                    {
                      label: "End Point Protection",
                      n: coverStats.epp,
                      tip: "Customers with Bitdefender EPP endpoints",
                    },
                    {
                      label: "Microsoft 365",
                      n: coverStats.csp,
                      tip: "Customers with M365 tenant cover",
                    },
                  ] as const
                ).map((s) => (
                  <div
                    key={s.label}
                    className="rounded-xl border border-border bg-muted/20 px-3 py-3"
                    title={s.tip}
                  >
                    <p className="text-[11px] font-semibold text-muted">{s.label}</p>
                    <p className="mt-1 font-mono text-2xl font-bold tabular-nums text-fg">
                      {s.n}
                      <span className="text-sm font-medium text-muted">
                        /{coverStats.n}
                      </span>
                    </p>
                    <p className="mt-0.5 text-[10px] text-subtle">
                      {coverStats.n
                        ? Math.round((s.n / coverStats.n) * 100)
                        : 0}
                      % of customers
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 4. Operations snapshot — simple numbers, not deep tables */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="border-border/80">
              <CardContent className="space-y-1 p-4">
                <p className="text-[11px] font-bold uppercase tracking-wide text-subtle">
                  Remote management
                </p>
                <p className="text-sm text-fg">
                  <span className="font-mono font-bold">
                    {exco.rmmServerOnlineTotal ?? 0}
                  </span>{" "}
                  servers online
                </p>
                <p className="text-xs text-muted">
                  {(exco.rmmServerOfflineTotal ?? 0) > 0 ? (
                    <span className="font-semibold text-rag-red">
                      {exco.rmmServerOfflineTotal} offline
                    </span>
                  ) : (
                    "No offline servers"
                  )}
                  {" · "}
                  {exco.rmmCriticalTotal ?? 0} critical alerts
                </p>
              </CardContent>
            </Card>
            <Card className="border-border/80">
              <CardContent className="space-y-1 p-4">
                <p className="text-[11px] font-bold uppercase tracking-wide text-subtle">
                  Cloud backup
                </p>
                <p className="text-sm text-fg">
                  <span className="font-mono font-bold">
                    {exco.backupUnhealthyCount}
                  </span>{" "}
                  customers with backup issues
                </p>
                <p className="text-xs text-muted">
                  Failed or stale backups on latest collect
                </p>
              </CardContent>
            </Card>
            <Card className="border-border/80">
              <CardContent className="space-y-1 p-4">
                <p className="text-[11px] font-bold uppercase tracking-wide text-subtle">
                  AMS risk & issues
                </p>
                <p className="text-sm text-fg">
                  <span className="font-mono font-bold">{exco.openRisksTotal}</span>{" "}
                  risks ·{" "}
                  <span className="font-mono font-bold">{exco.openIssuesTotal}</span>{" "}
                  issues
                </p>
                <p className="text-xs text-muted">Open items across the estate</p>
              </CardContent>
            </Card>
            <Card className="border-border/80">
              <CardContent className="space-y-1 p-4">
                <p className="text-[11px] font-bold uppercase tracking-wide text-subtle">
                  Data freshness
                </p>
                <p className="text-sm text-fg">
                  <span className="font-mono font-bold text-rag-green">
                    {exco.collectFreshCount}
                  </span>{" "}
                  fresh
                  {(exco.collectStaleCount ?? 0) > 0 ? (
                    <>
                      {" · "}
                      <span className="font-mono font-bold text-rag-amber">
                        {exco.collectStaleCount}
                      </span>{" "}
                      stale
                    </>
                  ) : null}
                </p>
                <p className="text-xs text-muted">
                  SYSPRO / collect age within 24h where covered
                </p>
              </CardContent>
            </Card>
          </div>

          {/* 5. Customer Health Assurance — single executive table */}
          <Card>
            <CardHead className="!normal-case !tracking-normal">
              <span className="text-[13px] font-bold text-fg">
                Customer Health Assurance
              </span>
              <InfoTag title="One row per customer: health, assurance, which services are on cover, and whether action is needed. Click a name to open Customer Ecosystem.">
                ?
              </InfoTag>
            </CardHead>
            <CardContent className="overflow-x-auto p-0">
              <table className="w-full min-w-[880px] text-left text-[12px]">
                <thead className="rpma-table-head border-b border-border bg-muted/30">
                  <tr>
                    <th className="px-3 py-2">Customer</th>
                    <th className="px-3 py-2">Health</th>
                    <th className="px-3 py-2 text-right">Score</th>
                    <th className="px-3 py-2 text-center">SYSPRO</th>
                    <th className="px-3 py-2 text-center">RMM</th>
                    <th className="px-3 py-2 text-center">Backup</th>
                    <th className="px-3 py-2 text-center">EPP</th>
                    <th className="px-3 py-2 text-center">M365</th>
                    <th className="px-3 py-2">Watch items</th>
                  </tr>
                </thead>
                <tbody>
                  {scoreboard.map((b) => (
                    <tr
                      key={b.customerCode}
                      className="rpma-data-row border-b border-border/60"
                    >
                      <td className="px-3 py-2">
                        <CustLink code={b.customerCode} name={b.displayName} />
                      </td>
                      <td className="px-3 py-2">
                        <RagBadge rag={b.healthRag} />
                      </td>
                      <td className="px-3 py-2 text-right font-mono font-semibold">
                        {b.assuranceScorePct}%
                      </td>
                      {(
                        [
                          b.coverSyspro,
                          b.coverRmm,
                          b.coverCove,
                          b.coverEpp,
                          b.coverCsp,
                        ] as boolean[]
                      ).map((on, i) => (
                        <td key={i} className="px-3 py-2 text-center">
                          {on ? (
                            <span className="font-semibold text-rag-green">On</span>
                          ) : (
                            <span className="text-[11px] font-bold uppercase text-amber-500">
                              No
                            </span>
                          )}
                        </td>
                      ))}
                      <td className="px-3 py-2 text-muted">
                        {b.attentionReasons.length === 0 ? (
                          <span className="text-rag-green">Clear</span>
                        ) : (
                          <span className="line-clamp-1" title={b.attentionReasons.join("; ")}>
                            {b.attentionReasons.slice(0, 2).join(" · ")}
                            {b.attentionReasons.length > 2
                              ? ` +${b.attentionReasons.length - 2}`
                              : ""}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                  {scoreboard.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-3 py-6 text-center text-muted">
                        No customers in portfolio.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </div>
      </AppShell>
    </RequireAuth>
  );
}

