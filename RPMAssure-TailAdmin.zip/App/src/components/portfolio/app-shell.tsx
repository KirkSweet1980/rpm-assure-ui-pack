import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import { SpaLink } from "@/components/nav/spa-link";
import {
  ChevronDown,
  FileText,
  LayoutDashboard,
  RefreshCw,
  Settings,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { DensityToggle } from "@/components/portfolio/density-toggle";
import { ThemeToggle } from "@/components/portfolio/theme-toggle";
import { UserButton } from "@/lib/auth/gates";
import { useDensity } from "@/lib/density";
import { fetchPortfolio } from "@/lib/data/portfolio";
import {
  readClientPortfolioCache,
  writeClientPortfolioCache,
} from "@/lib/data/client-portfolio-cache";
import { useIdleLogout } from "@/lib/auth/idle-logout";
import { useStaffProfile } from "@/lib/auth/use-staff-profile";
import {
  CustomerSwitcher,
  rememberRecentCustomer,
  type SwitcherCustomer,
} from "@/components/nav/customer-switcher";
import { SettingsTreeMenu } from "@/components/nav/settings-tree-menu";
import { SETTINGS_MENU_ENABLED } from "@/lib/auth/features";
import { SystemClock } from "@/components/nav/system-clock";
import { isNavActive } from "@/lib/nav/site-tree";
import { scrollChromeToTop } from "@/lib/nav/scroll-chrome";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  CustomerListProvider,
  sortMasterCustomers,
  type MasterCustomer,
} from "@/lib/nav/customer-list-context";
import { inferCustomerCover } from "@/lib/data/cover";

/**
 * App shell — D3 top navigation (navy chrome) + shared customer list for master–detail.
 */
export function AppShell({
  children,
  title,
  subtitle,
}: {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}) {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [reportsOpen, setReportsOpen] = useState(false);
  const [masterCustomers, setMasterCustomers] = useState<MasterCustomer[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const router = useRouter();
  const { isCompact } = useDensity();
  const { profile } = useStaffProfile();
  const isPlatformAdmin =
    profile?.permissions.canAccessPlatformSettings === true;
  const navRef = useRef<HTMLElement>(null);
  useIdleLogout();

  const currentCustomerCode = useMemo(() => {
    const m = pathname.match(/^\/customers\/([^/]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  }, [pathname]);

  useEffect(() => {
    if (currentCustomerCode) rememberRecentCustomer(currentCustomerCode);
  }, [currentCustomerCode]);

  useEffect(() => {
    requestAnimationFrame(scrollChromeToTop);
  }, [pathname]);

  useEffect(() => {
    let cancelled = false;

    function mapRows(
      p: Awaited<ReturnType<typeof fetchPortfolio>> | null | undefined,
    ): MasterCustomer[] {
      if (!p) return [];
      const boards = p.exco?.boards ?? [];
      const boardBy = new Map(
        boards.map((b) => [b.customerCode.toUpperCase(), b] as const),
      );
      let rows = p.customers ?? p.rows ?? [];
      const allowed = profile?.allowedCustomerCodes;
      if (allowed && allowed.length > 0) {
        const set = new Set(allowed.map((c) => c.toUpperCase()));
        rows = rows.filter((r) => set.has(r.customerCode.toUpperCase()));
      }
      const mapped = rows
        .filter(
          (r) =>
            Boolean(r.sqlInstanceName && String(r.sqlInstanceName).trim()) ||
            (r.operatorCount ?? 0) > 0 ||
            (r.pulsewayDeviceCount ?? 0) > 0 ||
            (r.pulsewayOfflineCount ?? 0) > 0 ||
            Boolean(r.pulsewayOrgName && String(r.pulsewayOrgName).trim()) ||
            (r.coveDeviceCount ?? 0) > 0 ||
            (r.eppDeviceCount ?? 0) > 0 ||
            (r.cspUserCount ?? 0) > 0 ||
            r.cover?.syspro ||
            r.cover?.rmm ||
            r.cover?.cove ||
            r.cover?.epp ||
            r.cover?.csp,
        )
        .map((r) => {
          const b = boardBy.get(r.customerCode.toUpperCase());
          const cover =
            r.cover ??
            inferCustomerCover({
              pillarSyspro: r.pillarSyspro,
              pillarPulseway: r.pillarPulseway,
              pillarCove: r.pillarCove,
              pillarEpp: r.pillarEpp,
              pillarCsp: r.pillarCsp,
              sqlInstanceName: r.sqlInstanceName,
              operatorCount: r.operatorCount,
              activeUserCount: r.activeUserCount,
              sysproLastImportAt: r.lastImportAt,
              sysproJobErrorCount: r.sysproJobErrorCount,
              sysproDtrVarianceLines: r.sysproDtrVarianceLines,
              pulsewayOrgName: r.pulsewayOrgName,
              pulsewayDeviceCount: r.pulsewayDeviceCount,
              coveDeviceCount: r.coveDeviceCount,
              eppDeviceCount: r.eppDeviceCount,
              cspUserCount: r.cspUserCount,
              cspLicenseCount: r.cspLicenseSkuCount,
            });
          return {
            code: r.customerCode,
            name: (r.displayName || r.customerCode).trim(),
            healthRag: r.healthRag,
            needsAttention:
              (b?.attentionReasons?.length ?? 0) > 0 || r.healthRag !== "Green",
            collectFresh: b?.collectFresh ?? !!r.lastImportAt,
            cover,
          } satisfies MasterCustomer;
        });
      return sortMasterCustomers(mapped);
    }

    const cached = readClientPortfolioCache();
    if (cached) {
      setMasterCustomers(mapRows(cached));
      setListLoading(false);
    }

    void fetchPortfolio()
      .then((p) => {
        if (cancelled) return;
        writeClientPortfolioCache(p);
        setMasterCustomers(mapRows(p));
        setListLoading(false);
      })
      .catch(() => {
        if (!cancelled) setListLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [profile?.allowedCustomerCodes]);

  const switcherCustomers: SwitcherCustomer[] = useMemo(
    () =>
      masterCustomers.map((c) => ({
        code: c.code,
        name: c.name,
        healthRag: c.healthRag,
        needsAttention: c.needsAttention,
        collectFresh: c.collectFresh,
      })),
    [masterCustomers],
  );

  function linkActive(href: string, match: "exact" | "prefix") {
    return isNavActive(pathname, { id: href, label: "", href, match });
  }

  const listValue = useMemo(
    () => ({
      customers: masterCustomers,
      setCustomers: setMasterCustomers,
      loading: listLoading,
    }),
    [masterCustomers, listLoading],
  );

  return (
    <CustomerListProvider value={listValue}>
      <div className="ta-shell rpma-d3-shell flex min-h-dvh bg-bg text-fg">
        <aside className="ta-sidebar hidden w-[260px] shrink-0 flex-col lg:flex">
          <Link
            to="/"
            className="ta-brand flex items-center gap-2 px-5 py-5"
            aria-label="RPM Assure"
          >
            <span className="ta-brand-mark">R</span>
            <span className="ta-brand-name">RPMAssure</span>
          </Link>
          <nav className="ta-side-nav flex flex-1 flex-col gap-1 px-3" aria-label="Main">
            <SpaLink
              href="/"
              className={cn("ta-side-link", linkActive("/", "exact") && "is-active")}
            >
              <LayoutDashboard className="h-4 w-4 shrink-0" />
              Dashboard
            </SpaLink>
            <DropdownMenu
              open={reportsOpen}
              onOpenChange={(o) => {
                setReportsOpen(o);
                if (o) setSettingsOpen(false);
              }}
            >
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  className={cn(
                    "ta-side-link w-full",
                    pathname.startsWith("/reports") && "is-active",
                  )}
                >
                  <FileText className="h-4 w-4 shrink-0" />
                  Reports
                  <ChevronDown className="ml-auto h-3.5 w-3.5 opacity-70" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" side="right" className="w-56">
                <DropdownMenuLabel>Reports</DropdownMenuLabel>
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports" onClick={() => setReportsOpen(false)}>
                    Open Reports
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=day-end" onClick={() => setReportsOpen(false)}>
                    Day end · FinSight
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=period-end" onClick={() => setReportsOpen(false)}>
                    Period end · FinSight
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=ams-full" onClick={() => setReportsOpen(false)}>
                    Applications RPM Assure
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=estate" onClick={() => setReportsOpen(false)}>
                    Estate overview
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=rmm-service" onClick={() => setReportsOpen(false)}>
                    RMM service pack
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=services-cover" onClick={() => setReportsOpen(false)}>
                    Services on cover
                  </SpaLink>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <SpaLink href="/reports?format=custom-pack" onClick={() => setReportsOpen(false)}>
                    Custom report
                  </SpaLink>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {SETTINGS_MENU_ENABLED ? (
              <DropdownMenu
                open={settingsOpen}
                onOpenChange={(o) => {
                  setSettingsOpen(o);
                  if (o) setReportsOpen(false);
                }}
              >
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    className={cn(
                      "ta-side-link w-full",
                      pathname.startsWith("/settings") && "is-active",
                    )}
                  >
                    <Settings className="h-4 w-4 shrink-0" />
                    {isPlatformAdmin ? "Settings" : "Account"}
                    <ChevronDown className="ml-auto h-3.5 w-3.5 opacity-70" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="start"
                  side="right"
                  className="w-64 max-h-[min(70vh,28rem)] overflow-y-auto"
                >
                  <DropdownMenuLabel>
                    {isPlatformAdmin ? "Configuration" : "My account"}
                  </DropdownMenuLabel>
                  <SettingsTreeMenu
                    pathname={pathname}
                    variant="dropdown"
                    adminOnly={isPlatformAdmin}
                    onNavigate={() => setSettingsOpen(false)}
                  />
                </DropdownMenuContent>
              </DropdownMenu>
            ) : null}

            <div className="ta-side-label">Customers</div>
            <div className="px-1">
              <CustomerSwitcher
                customers={switcherCustomers}
                currentCode={currentCustomerCode}
              />
            </div>
          </nav>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header ref={navRef} className="ta-topbar sticky top-0 z-40">
            <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
              <div className="min-w-0 flex-1">
                <h1 className="truncate text-lg font-bold tracking-tight text-fg sm:text-xl">
                  {title}
                </h1>
                {subtitle ? (
                  <p className="truncate text-xs text-muted">{subtitle}</p>
                ) : null}
              </div>
              <nav className="flex items-center gap-1 lg:hidden" aria-label="Main mobile">
                <SpaLink href="/" className="ta-mob-link">
                  Home
                </SpaLink>
                <SpaLink href="/reports" className="ta-mob-link">
                  Reports
                </SpaLink>
              </nav>
              <SystemClock className="hidden md:flex" />
              <ThemeToggle compact />
              <div className="hidden sm:block">
                <DensityToggle compact />
              </div>
              <button
                type="button"
                className="ta-iconbtn"
                aria-label="Refresh data"
                title="Refresh"
                onClick={() => {
                  try {
                    sessionStorage.removeItem("rpma_portfolio_cache_v1");
                  } catch {
                    /* */
                  }
                  void router.invalidate();
                }}
              >
                <RefreshCw className="h-4 w-4" />
              </button>
              <UserButton />
            </div>
          </header>

          <main
            className={cn(
              "rpma-topnav-main flex-1 overflow-x-hidden",
              pathname === "/"
                ? "p-3 sm:p-4 md:p-5"
                : isCompact
                  ? "p-3 md:p-4"
                  : "p-4 md:p-6",
            )}
          >
            <div
              className={cn(
                "rpma-topnav-canvas w-full",
                pathname === "/" ? "max-w-none" : "mx-auto max-w-[1680px]",
              )}
            >
              {children}
            </div>
          </main>
        </div>
      </div>
    </CustomerListProvider>
  );
}
