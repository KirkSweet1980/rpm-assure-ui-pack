import { createFileRoute } from "@tanstack/react-router";
import { CoveRetentionSection } from "@/components/customer/customer-sections";
import { Route as CustomerRoute } from "./customers.$code";

export const Route = createFileRoute("/customers/$code/cove/retention")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return <p className="text-sm text-muted">Loading customer workspace…</p>;
    }
    return <CoveRetentionSection data={data} />;
  },
});
