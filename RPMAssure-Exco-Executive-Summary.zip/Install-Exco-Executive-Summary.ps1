# Install-Exco-Executive-Summary.ps1
# Replaces Exco with full-width Executive Summary + drill-downs + risk matrix.
# Extract the zip first, then run this from the extracted folder (Administrator):
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Exco-Executive-Summary.ps1
$ErrorActionPreference = 'Stop'
$App = 'C:\RPM-Assure\App'
$ServiceName = 'RPMAssure-App'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Here) { $Here = (Get-Location).Path }

function W($c,$m){ Write-Host $m -ForegroundColor $c }

Write-Host '========================================' -ForegroundColor Cyan
Write-Host ' Exco Executive Summary + risk matrix'
Write-Host '========================================' -ForegroundColor Cyan

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { throw 'Run as Administrator.' }
if (-not (Test-Path $App)) { throw "Missing $App" }

$indexSrc = Join-Path $Here 'App\src\routes\index.tsx'
$shellSrc = Join-Path $Here 'App\src\components\portfolio\app-shell.tsx'
if (-not (Test-Path -LiteralPath $indexSrc)) { throw "Missing App\src\routes\index.tsx next to this script. Extract the full zip." }
if (-not (Test-Path -LiteralPath $shellSrc)) { throw "Missing App\src\components\portfolio\app-shell.tsx next to this script. Extract the full zip." }

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$bakDir = "C:\RPM-Assure\backup\exco-exec_$stamp"
New-Item -ItemType Directory -Force -Path $bakDir | Out-Null

$indexDest = Join-Path $App 'src\routes\index.tsx'
$shellDest = Join-Path $App 'src\components\portfolio\app-shell.tsx'

if (Test-Path -LiteralPath $indexDest) {
  Copy-Item -LiteralPath $indexDest -Destination (Join-Path $bakDir 'index.tsx') -Force
}
if (Test-Path -LiteralPath $shellDest) {
  $shellBak = Join-Path $bakDir 'app-shell.tsx'
  New-Item -ItemType Directory -Force -Path (Split-Path $shellBak) | Out-Null
  Copy-Item -LiteralPath $shellDest -Destination $shellBak -Force
}
W Green "Backup: $bakDir"

Copy-Item -LiteralPath $indexSrc -Destination $indexDest -Force
New-Item -ItemType Directory -Force -Path (Split-Path $shellDest) | Out-Null
Copy-Item -LiteralPath $shellSrc -Destination $shellDest -Force
W Green 'Installed index.tsx + app-shell.tsx (full width, drill-downs, risk matrix)'

$svcObj = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($svcObj) {
  W Cyan ("Restarting {0} (was {1}) ..." -f $ServiceName, $svcObj.Status)
  Restart-Service -InputObject $svcObj -Force
  $up = $false
  for ($i = 1; $i -le 40; $i++) {
    Start-Sleep -Seconds 1
    $l = Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue
    if ($l) { W Green ("LISTENING PID {0}" -f $l[0].OwningProcess); $up = $true; break }
  }
  if (-not $up) { W Yellow 'Service restarted but port 8081 not listening yet - wait about 10s then hard-refresh.' }
  Get-Service -Name $ServiceName | Format-Table Name, Status, StartType -AutoSize
} else {
  W Yellow 'Service RPMAssure-App not found - files installed; start the app yourself.'
}

try {
  $r = Invoke-WebRequest -Uri 'http://127.0.0.1:8081/login' -UseBasicParsing -TimeoutSec 8
  W Green ("PROOF OK: /login HTTP {0}" -f $r.StatusCode)
} catch {
  $msg = $_.Exception.Message
  W Yellow ("PROOF: /login not ready yet - {0}" -f $msg)
}

Write-Host ''
Write-Host '========================================' -ForegroundColor Green
Write-Host ' INSTALLED'
Write-Host '  Full-width Executive Summary'
Write-Host '  Click RAG / KPI / matrix cell to drill'
Write-Host '  Risk matrix (Impact x Likelihood)'
Write-Host '  Hard-refresh the browser'
Write-Host '========================================' -ForegroundColor Green
