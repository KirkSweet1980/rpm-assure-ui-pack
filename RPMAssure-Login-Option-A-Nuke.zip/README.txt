Nuke Option A - inline styles. Run Apply-Login-Option-A-Nuke.ps1
