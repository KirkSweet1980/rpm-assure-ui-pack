SQL-only login watermark. Run Apply-Login-Sql-Watermark-Only.ps1
