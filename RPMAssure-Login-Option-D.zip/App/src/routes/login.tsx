import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Eye, EyeOff, Lock, Shield, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

/** Option D — split insight dashboard (silent CSS motion only) */
const LOGIN_SKIN = "option-d-split";

const VALUE_PILLS = [
  "Clarity",
  "Insight",
  "Evidence",
  "Confidence",
  "Visibility",
  "Source of truth",
] as const;

const BAR_HEIGHTS = [28, 42, 55, 68, 82, 96] as const;

const SQL_SNIPPET = [
  "SELECT c.CustomerCode, h.HealthScorePct",
  "FROM dbo.Dim_Customer c",
  "JOIN dbo.vw_Kpi_Customer_Health_Latest h",
  "  ON h.CustomerCode = c.CustomerCode",
  "WHERE c.Active = 1",
  "ORDER BY h.HealthScorePct DESC;",
];

const OPTION_D_CSS = `
.rpma-d-root {
  min-height: 100dvh;
  width: 100%;
  display: grid;
  grid-template-columns: 1.05fr 0.95fr;
  background: #050d18;
  color: #e8f4ff;
  overflow: hidden;
  position: relative;
}
/* Diagonal energy edge */
.rpma-d-root::before {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  left: 52%;
  width: 2px;
  z-index: 5;
  background: linear-gradient(
    180deg,
    transparent 0%,
    rgba(27,184,166,0.15) 15%,
    rgba(27,184,166,0.55) 50%,
    rgba(27,184,166,0.15) 85%,
    transparent 100%
  );
  box-shadow: 0 0 18px rgba(27,184,166,0.35);
  transform: skewX(-6deg);
  pointer-events: none;
}

/* ── LEFT: insight stage ── */
.rpma-d-stage {
  position: relative;
  min-height: 100dvh;
  overflow: hidden;
  background:
    radial-gradient(ellipse 70% 60% at 35% 40%, rgba(27,184,166,0.12) 0%, transparent 60%),
    radial-gradient(ellipse 50% 50% at 70% 70%, rgba(20,100,140,0.1) 0%, transparent 55%),
    linear-gradient(160deg, #071525 0%, #050d18 55%, #030a12 100%);
  padding: 2.5rem 2rem 2rem 2.25rem;
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}
.rpma-d-sql-bg {
  position: absolute;
  inset: 0;
  z-index: 0;
  opacity: 0.22;
  font-family: Consolas, "Courier New", monospace;
  font-size: 11px;
  line-height: 1.55;
  color: rgba(140,190,220,0.55);
  padding: 1.5rem;
  pointer-events: none;
  white-space: pre;
  animation: rpmaDSqlDrift 40s linear infinite;
}
@keyframes rpmaDSqlDrift {
  0% { transform: translateY(0); opacity: 0.18; }
  50% { opacity: 0.28; }
  100% { transform: translateY(-12%); opacity: 0.18; }
}

.rpma-d-radar-wrap {
  position: relative;
  z-index: 2;
  width: min(280px, 70%);
  aspect-ratio: 1;
  margin: 0.5rem auto 0;
  flex: 0 0 auto;
}
.rpma-d-radar {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  border: 1px solid rgba(27,184,166,0.25);
  box-shadow:
    0 0 0 18px rgba(27,184,166,0.04),
    0 0 40px rgba(27,184,166,0.12),
    inset 0 0 40px rgba(27,184,166,0.06);
}
.rpma-d-radar::before,
.rpma-d-radar::after {
  content: "";
  position: absolute;
  inset: 18%;
  border-radius: 50%;
  border: 1px solid rgba(27,184,166,0.18);
}
.rpma-d-radar::after { inset: 36%; }
.rpma-d-radar-cross {
  position: absolute;
  inset: 0;
}
.rpma-d-radar-cross::before,
.rpma-d-radar-cross::after {
  content: "";
  position: absolute;
  background: rgba(27,184,166,0.12);
}
.rpma-d-radar-cross::before {
  left: 50%; top: 8%; bottom: 8%; width: 1px; transform: translateX(-50%);
}
.rpma-d-radar-cross::after {
  top: 50%; left: 8%; right: 8%; height: 1px; transform: translateY(-50%);
}
.rpma-d-sweep {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(
    from 0deg,
    transparent 0deg,
    transparent 300deg,
    rgba(27,184,166,0.05) 330deg,
    rgba(27,184,166,0.45) 360deg
  );
  animation: rpmaDSweep 4.5s linear infinite;
}
@keyframes rpmaDSweep {
  to { transform: rotate(360deg); }
}
.rpma-d-nodes {
  position: absolute;
  inset: 0;
  animation: rpmaDNodes 12s ease-in-out infinite alternate;
}
@keyframes rpmaDNodes {
  from { transform: rotate(0deg); }
  to { transform: rotate(8deg); }
}
.rpma-d-node {
  position: absolute;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #1bb8a6;
  box-shadow: 0 0 12px rgba(27,184,166,0.9);
}
.rpma-d-node:nth-child(1) { top: 18%; left: 48%; }
.rpma-d-node:nth-child(2) { top: 32%; left: 72%; }
.rpma-d-node:nth-child(3) { top: 55%; left: 78%; }
.rpma-d-node:nth-child(4) { top: 72%; left: 58%; }
.rpma-d-node:nth-child(5) { top: 68%; left: 28%; }
.rpma-d-node:nth-child(6) { top: 40%; left: 22%; }
.rpma-d-node:nth-child(7) { top: 48%; left: 50%; width: 10px; height: 10px; }
.rpma-d-link {
  position: absolute;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(27,184,166,0.45), transparent);
  transform-origin: left center;
  opacity: 0.55;
}

.rpma-d-bars {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: flex-end;
  gap: 0.55rem;
  height: 120px;
  margin: 0.25rem 0 0.5rem;
  padding: 0 0.5rem;
}
.rpma-d-bar {
  flex: 1;
  border-radius: 6px 6px 2px 2px;
  background: linear-gradient(180deg, #2dd4bf 0%, #0d9488 55%, #0f766e 100%);
  box-shadow: 0 0 16px rgba(27,184,166,0.25);
  transform-origin: bottom;
  animation: rpmaDBar 2.8s ease-in-out infinite alternate;
  position: relative;
}
.rpma-d-bar span {
  position: absolute;
  top: -1.15rem;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.65rem;
  font-weight: 700;
  color: rgba(180,240,230,0.85);
  white-space: nowrap;
}
.rpma-d-bar:nth-child(1) { height: 28%; animation-delay: 0s; }
.rpma-d-bar:nth-child(2) { height: 42%; animation-delay: 0.15s; }
.rpma-d-bar:nth-child(3) { height: 55%; animation-delay: 0.3s; }
.rpma-d-bar:nth-child(4) { height: 68%; animation-delay: 0.45s; }
.rpma-d-bar:nth-child(5) { height: 82%; animation-delay: 0.6s; }
.rpma-d-bar:nth-child(6) { height: 96%; animation-delay: 0.75s; }
@keyframes rpmaDBar {
  from { filter: brightness(0.9); transform: scaleY(0.92); }
  to { filter: brightness(1.15); transform: scaleY(1); }
}

.rpma-d-pills {
  position: relative;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: 0.45rem;
  max-width: 220px;
  margin-top: auto;
}
.rpma-d-pill {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.45rem 0.9rem;
  border-radius: 999px;
  border: 1px solid rgba(27,184,166,0.45);
  background: rgba(8,30,48,0.75);
  backdrop-filter: blur(8px);
  color: #c8fff6;
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  box-shadow: 0 4px 16px rgba(0,0,0,0.3), 0 0 12px rgba(27,184,166,0.1);
  opacity: 0;
  animation: rpmaDPillIn 0.55s ease-out forwards;
}
.rpma-d-pill i {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #1bb8a6;
  box-shadow: 0 0 8px #1bb8a6;
}
.rpma-d-pill:nth-child(1) { animation-delay: 0.15s; }
.rpma-d-pill:nth-child(2) { animation-delay: 0.3s; }
.rpma-d-pill:nth-child(3) { animation-delay: 0.45s; }
.rpma-d-pill:nth-child(4) { animation-delay: 0.6s; }
.rpma-d-pill:nth-child(5) { animation-delay: 0.75s; }
.rpma-d-pill:nth-child(6) { animation-delay: 0.9s; }
@keyframes rpmaDPillIn {
  from { opacity: 0; transform: translateX(-16px); }
  to { opacity: 1; transform: translateX(0); }
}
.rpma-d-pill {
  animation: rpmaDPillIn 0.55s ease-out forwards, rpmaDPillFloat 4.5s ease-in-out infinite;
}
.rpma-d-pill:nth-child(1) { animation-delay: 0.15s, 0s; }
.rpma-d-pill:nth-child(2) { animation-delay: 0.3s, 0.4s; }
.rpma-d-pill:nth-child(3) { animation-delay: 0.45s, 0.8s; }
.rpma-d-pill:nth-child(4) { animation-delay: 0.6s, 1.2s; }
.rpma-d-pill:nth-child(5) { animation-delay: 0.75s, 1.6s; }
.rpma-d-pill:nth-child(6) { animation-delay: 0.9s, 2s; }
@keyframes rpmaDPillFloat {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-4px); }
}

.rpma-d-stage-brand {
  position: relative;
  z-index: 2;
  margin-top: 0.5rem;
  font-size: 0.72rem;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: rgba(27,184,166,0.75);
  font-weight: 700;
}

/* ── RIGHT: form panel ── */
.rpma-d-panel {
  position: relative;
  z-index: 2;
  min-height: 100dvh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2.5rem 2rem;
  background:
    radial-gradient(ellipse 60% 50% at 60% 40%, rgba(27,184,166,0.06) 0%, transparent 55%),
    linear-gradient(200deg, #0a1524 0%, #071018 100%);
}
.rpma-d-card {
  width: min(380px, 100%);
  animation: rpmaDCardIn 0.65s ease-out both;
}
@keyframes rpmaDCardIn {
  from { opacity: 0; transform: translateY(14px); }
  to { opacity: 1; transform: translateY(0); }
}
.rpma-d-brand {
  text-align: center;
  margin-bottom: 1.5rem;
}
.rpma-d-brand-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 3rem;
  height: 3rem;
  border-radius: 0.85rem;
  border: 1px solid rgba(27,184,166,0.4);
  background: rgba(27,184,166,0.1);
  color: #1bb8a6;
  margin-bottom: 0.85rem;
  box-shadow: 0 0 24px rgba(27,184,166,0.2);
  animation: rpmaDShield 3.2s ease-in-out infinite;
}
@keyframes rpmaDShield {
  0%, 100% { box-shadow: 0 0 18px rgba(27,184,166,0.18); }
  50% { box-shadow: 0 0 32px rgba(27,184,166,0.4); }
}
.rpma-d-brand h1 {
  margin: 0;
  font-size: 1.75rem;
  font-weight: 800;
  letter-spacing: -0.02em;
}
.rpma-d-brand h1 span { color: #1bb8a6; }
.rpma-d-brand p {
  margin: 0.4rem 0 0;
  font-size: 0.82rem;
  color: rgba(170,200,220,0.7);
}
.rpma-d-form-box {
  padding: 1.5rem 1.4rem 1.35rem;
  border-radius: 1.1rem;
  background: linear-gradient(165deg, rgba(16,38,60,0.75) 0%, rgba(10,22,38,0.88) 100%);
  border: 1px solid rgba(27,184,166,0.22);
  box-shadow:
    0 0 0 1px rgba(27,184,166,0.06),
    0 24px 56px rgba(0,0,0,0.45);
  backdrop-filter: blur(16px);
}
.rpma-d-form-box h2 {
  margin: 0 0 1rem;
  font-size: 1.05rem;
  font-weight: 650;
  color: rgba(230,242,255,0.95);
}
.rpma-d-form {
  display: flex;
  flex-direction: column;
  gap: 0.9rem;
}
.rpma-d-label {
  display: block;
  margin-bottom: 0.35rem;
  font-size: 0.75rem;
  font-weight: 600;
  color: rgba(200,220,235,0.8);
}
.rpma-d-field {
  position: relative;
  display: flex;
  align-items: center;
}
.rpma-d-field > svg:first-of-type {
  position: absolute;
  left: 0.75rem;
  color: rgba(140,180,210,0.7);
  pointer-events: none;
}
.rpma-d-field input {
  width: 100%;
  height: 2.65rem;
  padding: 0 0.9rem 0 2.35rem;
  border-radius: 0.65rem;
  border: 1px solid rgba(100,160,200,0.2);
  background: rgba(6,14,26,0.75);
  color: #f0f7ff;
  font-size: 0.9rem;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.rpma-d-field input:focus {
  border-color: rgba(27,184,166,0.55);
  box-shadow: 0 0 0 3px rgba(27,184,166,0.14);
}
.rpma-d-field--pw input { padding-right: 2.5rem; }
.rpma-d-eye {
  position: absolute;
  right: 0.4rem;
  background: transparent;
  border: none;
  color: rgba(160,190,210,0.8);
  cursor: pointer;
  display: inline-flex;
  padding: 0.35rem;
}
.rpma-d-err { margin: 0; color: #f87171; font-size: 0.82rem; }
.rpma-d-submit {
  height: 2.75rem;
  margin-top: 0.15rem;
  border: none;
  border-radius: 0.65rem;
  background: linear-gradient(90deg, #0d9488 0%, #1bb8a6 55%, #14b8a6 100%);
  color: #042f2e;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.4rem;
  box-shadow: 0 8px 24px rgba(27,184,166,0.28);
  transition: transform 0.15s, box-shadow 0.2s, opacity 0.15s;
  animation: rpmaDBtn 2.8s ease-in-out infinite;
}
@keyframes rpmaDBtn {
  0%, 100% { box-shadow: 0 8px 24px rgba(27,184,166,0.25); }
  50% { box-shadow: 0 10px 30px rgba(27,184,166,0.42); }
}
.rpma-d-submit:hover:not(:disabled) {
  transform: translateY(-1px);
}
.rpma-d-submit:disabled { opacity: 0.7; cursor: wait; animation: none; }
.rpma-d-foot {
  margin: 1.25rem 0 0;
  text-align: center;
  font-size: 0.75rem;
  color: rgba(160,190,210,0.45);
}

@media (max-width: 900px) {
  .rpma-d-root {
    grid-template-columns: 1fr;
  }
  .rpma-d-root::before { display: none; }
  .rpma-d-stage {
    min-height: auto;
    max-height: 42vh;
    padding: 1.25rem 1.25rem 1rem;
  }
  .rpma-d-radar-wrap { width: 140px; margin: 0 auto; }
  .rpma-d-bars { height: 70px; }
  .rpma-d-pills {
    flex-direction: row;
    flex-wrap: wrap;
    max-width: none;
  }
  .rpma-d-pill { font-size: 0.65rem; padding: 0.3rem 0.65rem; }
  .rpma-d-panel { min-height: auto; padding: 1.5rem 1.25rem 2rem; }
}
@media (prefers-reduced-motion: reduce) {
  .rpma-d-sweep,
  .rpma-d-nodes,
  .rpma-d-bar,
  .rpma-d-pill,
  .rpma-d-sql-bg,
  .rpma-d-submit,
  .rpma-d-brand-icon,
  .rpma-d-card {
    animation: none !important;
  }
  .rpma-d-pill { opacity: 1; }
}
`;

function InsightStage() {
  const sql = [...SQL_SNIPPET, "", ...SQL_SNIPPET, "", ...SQL_SNIPPET].join("\n");
  return (
    <aside className="rpma-d-stage" aria-hidden="true">
      <div className="rpma-d-sql-bg">{sql}</div>

      <div className="rpma-d-radar-wrap">
        <div className="rpma-d-radar">
          <div className="rpma-d-radar-cross" />
          <div className="rpma-d-sweep" />
          <div className="rpma-d-nodes">
            {Array.from({ length: 7 }).map((_, i) => (
              <span key={i} className="rpma-d-node" />
            ))}
          </div>
        </div>
      </div>

      <div className="rpma-d-bars">
        {BAR_HEIGHTS.map((h, i) => (
          <div key={i} className="rpma-d-bar" style={{ height: `${h}%` }}>
            <span>{h}%</span>
          </div>
        ))}
      </div>

      <div className="rpma-d-pills">
        {VALUE_PILLS.map((label) => (
          <span key={label} className="rpma-d-pill">
            <i />
            {label}
          </span>
        ))}
      </div>

      <p className="rpma-d-stage-brand">Estate health · live insight</p>
    </aside>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({ email: loginEmail, password });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rpma-d-root" data-login-skin={LOGIN_SKIN}>
      <style>{OPTION_D_CSS}</style>
      <InsightStage />

      <section className="rpma-d-panel">
        <div className="rpma-d-card">
          <div className="rpma-d-brand">
            <div className="rpma-d-brand-icon">
              <Shield size={22} strokeWidth={2.25} />
            </div>
            <h1>
              RPM <span>Assure</span>
            </h1>
            <p>Managed Service Assurance</p>
          </div>

          <div className="rpma-d-form-box">
            <IdleLogoutBanner />
            <h2>Sign in to your account</h2>

            {!authEnabled ? (
              <p className="rpma-d-err">Auth is disabled.</p>
            ) : (
              <form className="rpma-d-form" onSubmit={onSignIn}>
                <label>
                  <span className="rpma-d-label">Email or username</span>
                  <span className="rpma-d-field">
                    <User size={16} />
                    <input
                      type="text"
                      required
                      placeholder="Email or username"
                      autoComplete="username"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </span>
                </label>

                <label>
                  <span className="rpma-d-label">Password</span>
                  <span className="rpma-d-field rpma-d-field--pw">
                    <Lock size={16} />
                    <input
                      type={showPw ? "text" : "password"}
                      required
                      minLength={8}
                      placeholder="Password"
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      className="rpma-d-eye"
                      onClick={() => setShowPw((v) => !v)}
                      aria-label={showPw ? "Hide password" : "Show password"}
                      tabIndex={-1}
                    >
                      {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </span>
                </label>

                {error ? <p className="rpma-d-err">{error}</p> : null}

                <button type="submit" className="rpma-d-submit" disabled={busy}>
                  {busy ? "Signing in..." : "Sign in"}
                </button>
              </form>
            )}
          </div>

          <p className="rpma-d-foot">Powered by RPM Resources · Secure staff access</p>
        </div>
      </section>
    </div>
  );
}
