Option D split insight login. Silent CSS animations only.
Run Apply-Login-Option-D.ps1 then private window ?v=d
