# Rollback-Old-UI.ps1
# Restores the previous UI from the newest C:\RPM-Assure\backups\old_ui_* folder.
# Pure ASCII. Run elevated.
$ErrorActionPreference = 'Stop'

$Root    = 'C:\RPM-Assure'
$App     = Join-Path $Root 'App'
$Backups = Join-Path $Root 'backups'
$Port    = 8081
$Logs    = Join-Path $Root 'deploy\logs'

if (-not (Test-Path $App)) { throw "Missing $App" }

$latest = Get-ChildItem $Backups -Directory -Filter 'old_ui_*' -EA SilentlyContinue |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1
if (-not $latest) { throw "No backup found under $Backups\old_ui_*" }

Write-Host "Restoring from $($latest.FullName)" -ForegroundColor Yellow

try { schtasks /End /TN 'RPMAssure-App-OnStart' 2>$null | Out-Null } catch {}
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -EA SilentlyContinue | ForEach-Object {
  $cl = [string]$_.CommandLine
  if ($cl -match 'RPM-Assure|8081|\.output|vite') {
    Stop-Process -Id $_.ProcessId -Force -EA SilentlyContinue
  }
}
Start-Sleep -Seconds 2

foreach ($name in @('src', 'public', '.output')) {
  $from = Join-Path $latest.FullName $name
  $to   = Join-Path $App $name
  if (Test-Path $from) {
    if (Test-Path $to) { Remove-Item $to -Recurse -Force }
    Copy-Item $from $to -Recurse -Force
    Write-Host "Restored $name"
  }
}

Write-Host 'Start the app the same way you did before the upgrade (Vite or production).'
Write-Host '=== Done ==='
