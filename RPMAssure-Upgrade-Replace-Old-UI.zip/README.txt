RPM Assure - Remove old UI / install upgraded UI
================================================

This pack:
  1. Stops the running app
  2. Backs up the OLD UI (src, public, .output)
  3. DELETES the old production bundle (.output) - that was showing the old look
  4. Installs the NEW UI (src + public + vite.config)
  5. Starts Vite so the live site matches the Grok preview
  6. Proves the new login marker is served

What is kept
  .env.local   SQL / auth settings
  data\        settings and local store
  node_modules
  package.json

RUN (elevated PowerShell on the APP SERVER)

  $zip  = "$env:USERPROFILE\Downloads\RPMAssure-Upgrade-Replace-Old-UI.zip"
  $dest = "$env:USERPROFILE\Downloads\RPMAssure-Upgrade-Replace-Old-UI"
  Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
  Unblock-File "$dest\Apply-Upgrade-Replace-Old-UI.ps1"
  powershell -NoProfile -ExecutionPolicy Bypass -File "$dest\Apply-Upgrade-Replace-Old-UI.ps1"

SUCCESS looks like
  PROOF OK: http://127.0.0.1:8081/src/routes/login.tsx
  UPGRADE COMPLETE
  New UI: cmd-centre-A-v3-split-20260812

THEN
  Private browser window -> https://assure.rpmresources.co.za/login
  Hard refresh (Ctrl+Shift+R)
  Sign in: RPMAdmin / RPM@dm1n2026#
  You should see split login: CLI windows left, glass card right

ROLLBACK (if needed)
  powershell -NoProfile -ExecutionPolicy Bypass -File "$dest\Rollback-Old-UI.ps1"
  (restores newest C:\RPM-Assure\backups\old_ui_*)
