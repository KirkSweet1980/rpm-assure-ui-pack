# Apply-Upgrade-Replace-Old-UI.ps1
# Removes the OLD UI (stale production .output) and installs the NEW upgraded UI.
# Preserves: .env.local, data\, node_modules, package.json
# Pure ASCII. Run elevated on the APP SERVER.
$ErrorActionPreference = 'Stop'

$Root    = 'C:\RPM-Assure'
$App     = Join-Path $Root 'App'
$Port    = 8081
$Marker  = 'cmd-centre-A-v3-split-20260812'
$utf8    = New-Object System.Text.UTF8Encoding $false
$Logs    = Join-Path $Root 'deploy\logs'
$Backups = Join-Path $Root 'backups'

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Here) { $Here = (Get-Location).Path }
$Payload = Join-Path $Here 'payload'
if (-not (Test-Path (Join-Path $Payload 'src\routes\login.tsx'))) {
  $alt = Get-ChildItem $Here -Recurse -Directory -Filter 'payload' -EA SilentlyContinue |
    Where-Object { Test-Path (Join-Path $_.FullName 'src\routes\login.tsx') } |
    Select-Object -First 1
  if ($alt) { $Payload = $alt.FullName }
}
if (-not (Test-Path (Join-Path $Payload 'src\routes\login.tsx'))) {
  throw "Missing payload\src\routes\login.tsx under $Here. Extract the FULL zip."
}

if (-not (Test-Path $App)) {
  foreach ($c in @(
      'C:\Program Files\RPM Resources\RPM Assure\app',
      'C:\Program Files\RPM Resources\RPM Assure\App'
    )) {
    if (Test-Path $c) { $App = $c; break }
  }
}
if (-not (Test-Path $App)) { throw "App folder not found. Expected C:\RPM-Assure\App" }

$loginSrc = [IO.File]::ReadAllText((Join-Path $Payload 'src\routes\login.tsx'))
if ($loginSrc -notlike "*$Marker*") {
  throw "Payload login.tsx missing marker $Marker - wrong zip"
}

Write-Host '========================================' -ForegroundColor Cyan
Write-Host ' RPM Assure - REMOVE OLD UI / INSTALL NEW'
Write-Host '========================================' -ForegroundColor Cyan
Write-Host "App     = $App"
Write-Host "Payload = $Payload"
Write-Host "Marker  = $Marker"
Write-Host ''

New-Item -ItemType Directory -Force -Path $Logs    | Out-Null
New-Item -ItemType Directory -Force -Path $Backups | Out-Null

# ---------- 1) STOP old app (production + vite + tasks) ----------
Write-Host '--- 1) Stop old app ---' -ForegroundColor Yellow
try { schtasks /End /TN 'RPMAssure-App-OnStart' 2>$null | Out-Null } catch {}
try { schtasks /End /TN 'RPMAssure-App' 2>$null | Out-Null } catch {}
foreach ($svcName in @('RPMAssure-App', 'RPMAssure', 'RPM-Assure')) {
  $svc = Get-Service -Name $svcName -EA SilentlyContinue
  if ($svc -and $svc.Status -eq 'Running') {
    try { Stop-Service -Name $svcName -Force -EA SilentlyContinue } catch {}
    Write-Host "Stopped service $svcName"
  }
}
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -EA SilentlyContinue | ForEach-Object {
  $cl = [string]$_.CommandLine
  if ($cl -match 'RPM-Assure|8081|\.output|vite') {
    Write-Host ("Kill PID " + $_.ProcessId)
    Stop-Process -Id $_.ProcessId -Force -EA SilentlyContinue
  }
}
$conns = Get-NetTCPConnection -LocalPort $Port -State Listen -EA SilentlyContinue
foreach ($c in @($conns)) {
  if ($c.OwningProcess -gt 0) {
    Write-Host ("Kill port $Port owner PID " + $c.OwningProcess)
    Stop-Process -Id $c.OwningProcess -Force -EA SilentlyContinue
  }
}
Start-Sleep -Seconds 2
Write-Host 'OK stopped' -ForegroundColor Green

# ---------- 2) BACKUP old version ----------
$stamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
$Backup = Join-Path $Backups ("old_ui_" + $stamp)
New-Item -ItemType Directory -Force -Path $Backup | Out-Null
Write-Host "--- 2) Backup old UI -> $Backup ---" -ForegroundColor Yellow

foreach ($name in @('src', 'public', '.output')) {
  $from = Join-Path $App $name
  if (Test-Path $from) {
    Write-Host "  backing up $name ..."
    Copy-Item $from (Join-Path $Backup $name) -Recurse -Force
  } else {
    Write-Host "  skip $name (not present)"
  }
}
foreach ($name in @('vite.config.ts', 'UI_DEPLOY_MARKER.txt', 'UI_VERSION.txt')) {
  $from = Join-Path $App $name
  if (Test-Path $from) {
    Copy-Item $from (Join-Path $Backup $name) -Force
  }
}
[IO.File]::WriteAllText(
  (Join-Path $Backup 'BACKUP_INFO.txt'),
  ("Backup of old UI`r`nTime=" + (Get-Date).ToString('o') + "`r`nFrom=$App`r`n"),
  $utf8
)
Write-Host "OK backup $Backup" -ForegroundColor Green

# ---------- 3) REMOVE old UI (source + stale production bundle) ----------
Write-Host '--- 3) Remove old UI ---' -ForegroundColor Yellow

# The stale production bundle is WHY the old UI kept showing
$oldOutput = Join-Path $App '.output'
if (Test-Path $oldOutput) {
  Remove-Item $oldOutput -Recurse -Force
  Write-Host 'REMOVED App\.output  (old production UI cannot come back)' -ForegroundColor Green
} else {
  Write-Host 'No .output present'
}

$oldSrc = Join-Path $App 'src'
if (Test-Path $oldSrc) {
  Remove-Item $oldSrc -Recurse -Force
  Write-Host 'REMOVED App\src'
}

# Keep public folder, we overwrite files; remove known stale if needed
$viteCache = Join-Path $App 'node_modules\.vite'
if (Test-Path $viteCache) {
  Remove-Item $viteCache -Recurse -Force -EA SilentlyContinue
  Write-Host 'Cleared Vite cache'
}

# Also remove legacy C:\RPM-Assure\src if it exists (old dual path)
$legacySrc = Join-Path $Root 'src'
if (Test-Path $legacySrc) {
  Remove-Item $legacySrc -Recurse -Force -EA SilentlyContinue
  Write-Host 'REMOVED C:\RPM-Assure\src (legacy)'
}

# ---------- 4) INSTALL new UI ----------
Write-Host '--- 4) Install new UI ---' -ForegroundColor Yellow
Copy-Item (Join-Path $Payload 'src') (Join-Path $App 'src') -Recurse -Force
Write-Host 'OK App\src'

$destPublic = Join-Path $App 'public'
New-Item -ItemType Directory -Force -Path $destPublic | Out-Null
if (Test-Path (Join-Path $Payload 'public')) {
  Copy-Item (Join-Path $Payload 'public\*') $destPublic -Recurse -Force
  Write-Host 'OK App\public'
}

# Always overwrite vite.config (mssql stub plugin required)
Copy-Item (Join-Path $Payload 'vite.config.ts') (Join-Path $App 'vite.config.ts') -Force
Write-Host 'OK vite.config.ts'

if (Test-Path (Join-Path $Payload 'tsconfig.json')) {
  if (-not (Test-Path (Join-Path $App 'tsconfig.json'))) {
    Copy-Item (Join-Path $Payload 'tsconfig.json') (Join-Path $App 'tsconfig.json') -Force
  }
}

if (Test-Path (Join-Path $Payload 'scripts')) {
  New-Item -ItemType Directory -Force -Path (Join-Path $App 'scripts') | Out-Null
  Copy-Item (Join-Path $Payload 'scripts\*') (Join-Path $App 'scripts') -Force -EA SilentlyContinue
}

Copy-Item (Join-Path $Payload 'UI_VERSION.txt') (Join-Path $App 'UI_VERSION.txt') -Force
[IO.File]::WriteAllText(
  (Join-Path $App 'UI_VERSION.txt'),
  ("UI-UPGRADE-REPLACE`r`nBUILD=$Marker`r`nINSTALLED=" + (Get-Date).ToString('o') + "`r`nBACKUP=$Backup`r`n"),
  $utf8
)

# Disk proof
$diskLogin = [IO.File]::ReadAllText((Join-Path $App 'src\routes\login.tsx'))
if ($diskLogin -notlike "*$Marker*") { throw 'Installed login.tsx missing marker' }
$diskSess = [IO.File]::ReadAllText((Join-Path $App 'src\lib\auth\use-current-user.ts'))
if ($diskSess -notmatch 'SESSION_PENDING_MS') { throw 'Installed use-current-user.ts missing session timeout' }
Write-Host 'OK disk proof: new login + session timeout' -ForegroundColor Green

# Mirror for any leftover start scripts that used C:\RPM-Assure\src
Copy-Item (Join-Path $App 'src') (Join-Path $Root 'src') -Recurse -Force -EA SilentlyContinue

# ---------- 5) Point scheduled task at VITE (not old .output) ----------
Write-Host '--- 5) Point OnStart at new UI (Vite) ---' -ForegroundColor Yellow
$wrapper = Join-Path $Logs 'start-app-vite.cmd'
$wrapperBody = @"
@echo off
cd /d "$App"
set PORT=$Port
set HOST=0.0.0.0
set NITRO_PORT=$Port
npx.cmd vite dev --host 0.0.0.0 --port $Port >> "$Logs\app-stdout.log" 2>> "$Logs\app-stderr.log"
"@
[IO.File]::WriteAllText($wrapper, $wrapperBody, $utf8)

# Disable any wrapper that still starts .output
$oldProd = Join-Path $Logs 'start-app-prod.cmd'
if (Test-Path $oldProd) {
  $retired = Join-Path $Logs ('start-app-prod.DISABLED.' + $stamp + '.cmd')
  Move-Item $oldProd $retired -Force
  Write-Host "Retired old production starter -> $retired"
}

try {
  schtasks /Create /F /TN 'RPMAssure-App-OnStart' /TR $wrapper /SC ONSTART /RU SYSTEM /RL HIGHEST /DELAY 0000:15 | Out-Null
  Write-Host 'OK scheduled task -> Vite (new UI)' -ForegroundColor Green
} catch {
  Write-Host ('WARN schtasks: ' + $_.Exception.Message) -ForegroundColor Yellow
}

# ---------- 6) START new UI ----------
Write-Host '--- 6) Start new UI ---' -ForegroundColor Yellow
$cmdLine = "cd /d `"$App`" && npx.cmd vite dev --host 0.0.0.0 --port $Port >> `"$Logs\app-stdout.log`" 2>> `"$Logs\app-stderr.log`""
Start-Process cmd.exe -ArgumentList '/c', $cmdLine -WorkingDirectory $App -WindowStyle Minimized

$up = $false
$pidListen = $null
for ($i = 1; $i -le 60; $i++) {
  Start-Sleep -Seconds 1
  $l = Get-NetTCPConnection -LocalPort $Port -State Listen -EA SilentlyContinue
  if ($l) {
    $pidListen = $l[0].OwningProcess
    Write-Host "LISTENING PID $pidListen after ${i}s"
    $up = $true
    break
  }
  if (($i % 10) -eq 0) { Write-Host "waiting $i/60..." }
}
if (-not $up) {
  Write-Host 'FAILED to bind port - last stderr:' -ForegroundColor Red
  if (Test-Path (Join-Path $Logs 'app-stderr.log')) {
    Get-Content (Join-Path $Logs 'app-stderr.log') -Tail 40
  }
  throw "Port $Port not listening"
}

Start-Sleep -Seconds 5

# ---------- 7) PROVE new UI is served ----------
Write-Host '--- 7) Prove new UI is live ---' -ForegroundColor Yellow
$ok = $false
$probeUrls = @(
  "http://127.0.0.1:$Port/src/routes/login.tsx",
  "http://127.0.0.1:$Port/src/lib/auth/use-current-user.ts"
)
foreach ($u in $probeUrls) {
  try {
    $r = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 25
    $body = $r.Content
    if ($body -like "*$Marker*" -or $body -match 'SESSION_PENDING_MS') {
      Write-Host "PROOF OK: $u" -ForegroundColor Green
      $ok = $true
    } else {
      Write-Host "No marker in $u (len=$($body.Length))" -ForegroundColor Yellow
    }
  } catch {
    Write-Host ("probe fail $u : " + $_.Exception.Message)
  }
}

# Confirm .output is gone so old UI cannot resurrect
if (Test-Path (Join-Path $App '.output')) {
  Write-Host 'WARN: .output reappeared - old production bundle still on disk' -ForegroundColor Yellow
} else {
  Write-Host 'OK .output gone (old production UI removed)' -ForegroundColor Green
}

if (-not $ok) {
  Write-Host ''
  Write-Host 'NEW UI FILES ARE ON DISK but serve proof failed.' -ForegroundColor Yellow
  Write-Host 'Open a PRIVATE browser window and hard-refresh.'
  Write-Host 'If you still see old login, Caddy may be caching or another process is on 8081:'
  Write-Host '  netstat -ano | findstr :8081'
  exit 1
}

Write-Host ''
Write-Host '========================================' -ForegroundColor Green
Write-Host ' UPGRADE COMPLETE'
Write-Host "  New UI:     $Marker"
Write-Host "  Old UI:     backed up then removed"
Write-Host "  Backup:     $Backup"
Write-Host "  Rollback:   run Rollback-Old-UI.ps1 in that backup folder"
Write-Host '  Browser:    PRIVATE WINDOW then hard refresh (Ctrl+Shift+R)'
Write-Host '  Login:      RPMAdmin  /  RPM@dm1n2026#'
Write-Host '  Look for:   split login (CLI left, glass card right)'
Write-Host '========================================' -ForegroundColor Green
Write-Host '=== Done ==='
