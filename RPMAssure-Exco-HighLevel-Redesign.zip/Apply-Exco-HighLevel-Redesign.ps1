﻿# Apply-Exco-HighLevel-Redesign.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = 'C:\RPM-Assure\App'
$src = Join-Path $Here 'App\src\routes\index.tsx'
$dst = Join-Path $AppRoot 'src\routes\index.tsx'
if (-not (Test-Path -LiteralPath $src)) { throw "Missing $src" }
Copy-Item -LiteralPath $src -Destination $dst -Force
Write-Host "OK $dst"
Write-Host 'Restart app...'
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 6
} catch {
  Write-Host $_
}
Write-Host 'Hard-refresh Exco Insight (home).'
Write-Host '=== Done ==='
