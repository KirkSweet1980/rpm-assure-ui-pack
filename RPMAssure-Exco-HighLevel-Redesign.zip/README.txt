Exco high-level redesign. Run Apply-Exco-HighLevel-Redesign.ps1
