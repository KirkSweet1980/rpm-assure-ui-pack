HARD apply Option A login.
Fixes nested App paths, writes dedicated CSS, clears Vite cache, restarts 8081.
Run: powershell -NoProfile -ExecutionPolicy Bypass -File Apply-Login-Option-A-Hard.ps1
Then open a PRIVATE browser window to /login
