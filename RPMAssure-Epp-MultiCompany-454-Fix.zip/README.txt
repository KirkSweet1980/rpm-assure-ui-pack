Fixed Collect here-string. Run Apply-Epp-MultiCompany-454-Fix.ps1
