# Apply-Epp-MultiCompany-454-Fix.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$SqlRoot = 'C:\RPM-Assure\Sql\bitdefender'
$Server = '102.222.21.220,14333'
$Db = 'RPMAssure_App'
if (-not (Test-Path $SqlRoot)) { New-Item -ItemType Directory -Path $SqlRoot -Force | Out-Null }
Copy-Item (Join-Path $Here 'Sql\bitdefender\454_Bitdefender_CompanyMap.sql') (Join-Path $SqlRoot '454_Bitdefender_CompanyMap.sql') -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $Here 'Sql\bitdefender\Collect-Bitdefender-To-RPMAssure.ps1') (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1') -Force
Copy-Item (Join-Path $Here 'Sql\bitdefender\Explore-Bitdefender-Companies.ps1') (Join-Path $SqlRoot 'Explore-Bitdefender-Companies.ps1') -Force
Write-Host 'OK Collect script fixed (bd_seed_map quote)'
if (Test-Path (Join-Path $SqlRoot '454_Bitdefender_CompanyMap.sql')) {
  Write-Host '=== 454 company map (safe re-run) ==='
  & sqlcmd -S $Server -d $Db -E -C -b -i (Join-Path $SqlRoot '454_Bitdefender_CompanyMap.sql') 2>&1 | ForEach-Object { Write-Host $_ }
}
Write-Host '=== Explore multi-company ==='
powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SqlRoot 'Explore-Bitdefender-Companies.ps1')
Write-Host '=== Re-collect ==='
powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1')
Write-Host ("collect exit=" + $LASTEXITCODE)
Write-Host '=== Proof ==='
& sqlcmd -S $Server -d $Db -E -C -Q "SET NOCOUNT ON; SELECT CustomerCode, COUNT(*) Cnt FROM dbo.Bitdefender_Endpoints WITH (NOLOCK) WHERE SnapshotDate=(SELECT MAX(SnapshotDate) FROM dbo.Bitdefender_Endpoints) GROUP BY CustomerCode ORDER BY 1; SELECT COUNT(*) Unmapped FROM dbo.Bitdefender_Endpoints WITH (NOLOCK) WHERE SnapshotDate=(SELECT MAX(SnapshotDate) FROM dbo.Bitdefender_Endpoints) AND (CustomerCode IS NULL OR LTRIM(RTRIM(CustomerCode))='');" 2>&1 | ForEach-Object { Write-Host $_ }
Write-Host '=== Done ==='
