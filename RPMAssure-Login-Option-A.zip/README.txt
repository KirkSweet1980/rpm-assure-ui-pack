Login Option A. Run Apply-Login-Option-A.ps1
