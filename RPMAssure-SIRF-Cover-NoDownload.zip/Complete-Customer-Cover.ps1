# Complete-Customer-Cover.ps1
# Stage 2 after SQL one-shot: check and map RMM (Pulseway), Cove, Bitdefender, M365.
# Run on the APP server (or any box that can reach central Assure SQL).
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\Complete-Customer-Cover.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\Complete-Customer-Cover.ps1 -CustomerCode SIRF
param(
  [string]$CustomerCode = '',
  [string]$DisplayName = '',
  [string]$CentralHost = '102.222.21.220,14333',
  [string]$CentralDb = 'RPMAssure_App',
  [string]$CentralUser = 'rpmassure'
)
$ErrorActionPreference = 'Stop'

$DefaultCentralPwd = '@ssuR3me!'

function Write-Step([string]$m) { Write-Host ''; Write-Host $m -ForegroundColor Cyan }
function Write-Ok([string]$m)   { Write-Host $m -ForegroundColor Green }
function Write-Warn2([string]$m){ Write-Host $m -ForegroundColor Yellow }

function Read-Default([string]$prompt, [string]$default) {
  $suffix = if ($default) { " [$default]" } else { '' }
  $v = Read-Host ($prompt + $suffix)
  if ([string]::IsNullOrWhiteSpace($v)) { return $default }
  return $v.Trim()
}

function Read-Secret([string]$prompt) {
  $sec = Read-Host $prompt -AsSecureString
  $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}

function Escape-Sql([string]$s) {
  if ($null -eq $s) { return '' }
  return ($s -replace "'", "''")
}

function Find-Sqlcmd {
  $cmd = Get-Command sqlcmd.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  foreach ($c in @(
      'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\sqlcmd.exe',
      'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\180\Tools\Binn\sqlcmd.exe',
      'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\130\Tools\Binn\sqlcmd.exe'
    )) {
    if (Test-Path $c) { return $c }
  }
  throw 'sqlcmd.exe not found.'
}

function Invoke-Sql([string]$Sqlcmd, [string]$Server, [string]$User, [string]$Password, [string]$Query, [string]$Database, [int]$TimeoutSec = 60) {
  $tmp = Join-Path $env:TEMP ('rpma_cover_' + [guid]::NewGuid().ToString('N').Substring(0,8) + '.sql')
  $out = Join-Path $env:TEMP ('rpma_cover_' + [guid]::NewGuid().ToString('N').Substring(0,8) + '.out')
  $err = Join-Path $env:TEMP ('rpma_cover_' + [guid]::NewGuid().ToString('N').Substring(0,8) + '.err')
  [IO.File]::WriteAllText($tmp, $Query, (New-Object System.Text.UTF8Encoding $false))
  $args = @('-S', $Server, '-d', $Database, '-C', '-b', '-I', '-t', [string]$TimeoutSec, '-W', '-s', '|', '-U', $User, '-P', $Password, '-i', $tmp)
  $p = Start-Process -FilePath $Sqlcmd -ArgumentList $args -Wait -PassThru -NoNewWindow `
    -RedirectStandardOutput $out -RedirectStandardError $err
  $stdout = ''; $stderr = ''
  if (Test-Path $out) { $stdout = Get-Content $out -Raw -ErrorAction SilentlyContinue }
  if (Test-Path $err) { $stderr = Get-Content $err -Raw -ErrorAction SilentlyContinue }
  Remove-Item $tmp, $out, $err -Force -ErrorAction SilentlyContinue
  return [pscustomobject]@{ ExitCode = $p.ExitCode; StdOut = $stdout; StdErr = $stderr; Ok = ($p.ExitCode -eq 0) }
}

function Get-DataRows([string]$text) {
  $rows = New-Object System.Collections.Generic.List[string]
  if (-not $text) { return ,$rows.ToArray() }
  foreach ($line in ($text -split "`r?`n")) {
    $n = $line.Trim()
    if (-not $n) { continue }
    if ($n -match '^(name|OrganizationName|PartnerName|CompanyName|DisplayName|TenantId|Pillar|CustomerCode|Status|Msg)\b') { continue }
    if ($n -match '^-+') { continue }
    if ($n -match 'rows affected') { continue }
    $rows.Add($n)
  }
  return ,$rows.ToArray()
}

function Get-SearchTokens([string]$code, [string]$name) {
  $tok = New-Object System.Collections.Generic.List[string]
  $tok.Add($code)
  foreach ($w in ($name -split '[^A-Za-z0-9]+')) {
    if ($w.Length -ge 3 -and $w -notmatch '^(pty|ltd|the|and|inc)$') { $tok.Add($w) }
  }
  return ,($tok | Select-Object -Unique)
}

function New-LikeOr([string]$col, [string[]]$tokens) {
  $parts = @()
  foreach ($t in $tokens) {
    $parts += ($col + " LIKE N'%" + (Escape-Sql $t) + "%'")
  }
  if ($parts.Count -eq 0) { return '1=0' }
  return '(' + ($parts -join ' OR ') + ')'
}

Write-Host '========================================' -ForegroundColor Cyan
Write-Host ' RPM Assure - customer cover checks'
Write-Host ' RMM (Pulseway) / Cove / Bitdefender / M365'
Write-Host '========================================' -ForegroundColor Cyan
Write-Host 'SQL one-shot only registered SYSPRO. This maps the rest.'
Write-Host 'Run on the APP server (central SQL).'

$sqlcmd = Find-Sqlcmd
Write-Ok ('sqlcmd = ' + $sqlcmd)

Write-Step '--- Customer ---'
if (-not $CustomerCode) { $CustomerCode = Read-Default 'Customer code' 'SIRF' }
$CustomerCode = $CustomerCode.ToUpperInvariant()
if ($CustomerCode -notmatch '^[A-Z0-9]{2,20}$') { throw 'Bad customer code.' }
if (-not $DisplayName) { $DisplayName = Read-Default 'Display name (for search)' 'Sir Fruit' }

Write-Step '--- Central Assure SQL ---'
$CentralHost = Read-Default 'Central host,port' $CentralHost
$CentralUser = Read-Default 'Central SQL user' $CentralUser
$useStd = Read-Default 'Use standard collect password? (Y/n)' 'Y'
if ($useStd -match '^[nN]') {
  $CentralPwd = Read-Secret 'Central SQL password'
} else {
  $CentralPwd = $DefaultCentralPwd
}

$probe = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd `
  -Database $CentralDb -Query "SET NOCOUNT ON; SELECT DB_NAME(), SUSER_SNAME();"
if (-not $probe.Ok) {
  Write-Host $probe.StdOut; Write-Host $probe.StdErr
  throw 'Cannot connect to central. Check host / user / password.'
}
Write-Ok 'Central OK'
Write-Host $probe.StdOut

$codeLit = Escape-Sql $CustomerCode
$nameLit = Escape-Sql $DisplayName
$tokens = Get-SearchTokens $CustomerCode $DisplayName
Write-Host ('Search tokens: ' + ($tokens -join ', '))

# ---------- customer exists? ----------
$chk = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
SELECT c.CustomerCode, c.DisplayName, c.Active, c.SqlInstanceName,
       ISNULL(a.PillarSyspro,0), ISNULL(a.PillarPulseway,0), ISNULL(a.PillarCove,0),
       ISNULL(a.PillarBitdefender,0), ISNULL(a.PillarMicrosoftCsp,0)
FROM dbo.Dim_Customer c
LEFT JOIN dbo.Dim_Customer_AmsConfig a ON a.CustomerCode = c.CustomerCode
WHERE c.CustomerCode = N'$codeLit';
"@
if (-not $chk.Ok -or (($chk.StdOut + '') -notmatch $CustomerCode)) {
  throw "Customer $CustomerCode is not on central Dim_Customer. Run the SQL one-shot first."
}
Write-Host $chk.StdOut

$score = [ordered]@{
  SYSPRO = 'unknown'
  RMM    = 'unknown'
  COVE   = 'unknown'
  EPP    = 'unknown'
  CSP    = 'unknown'
}

# ---------- SYSPRO evidence ----------
Write-Step '--- SYSPRO ---'
$sy = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
DECLARE @inst nvarchar(100) = (SELECT TOP 1 SqlInstanceName FROM dbo.Dim_Customer WHERE CustomerCode=N'$codeLit');
SELECT 'operators' AS Kind, COUNT(*) AS Cnt FROM dbo.Syspro_Operators WITH (NOLOCK)
WHERE InstanceName = @inst;
IF OBJECT_ID(N'dbo.Syspro_SystemLicense',N'U') IS NOT NULL
  SELECT 'license' AS Kind, COUNT(*) AS Cnt FROM dbo.Syspro_SystemLicense WITH (NOLOCK)
  WHERE InstanceName = @inst;
"@
Write-Host $sy.StdOut
if ($sy.StdOut -match 'operators\|\s*[1-9]') { $score.SYSPRO = 'COVERED (data)' }
else { $score.SYSPRO = 'registered - no collect yet' }

function Set-Pillar([string]$col, [int]$val) {
  $q = @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Dim_Customer_AmsConfig',N'U') IS NULL RETURN;
IF NOT EXISTS (SELECT 1 FROM dbo.Dim_Customer_AmsConfig WHERE CustomerCode=N'$codeLit')
  INSERT dbo.Dim_Customer_AmsConfig (CustomerCode, AmsEnabled, $col) VALUES (N'$codeLit', 1, $val);
ELSE
  UPDATE dbo.Dim_Customer_AmsConfig SET $col = $val, UpdatedAt = SYSUTCDATETIME(), UpdatedBy = N'cover-check'
  WHERE CustomerCode = N'$codeLit';
SELECT N'$col' AS Pillar, $val AS Status;
"@
  return Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query $q
}

# ---------- RMM / Pulseway ----------
Write-Step '--- RMM (Pulseway) ---'
$rmmHave = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Dim_Pulseway_OrgMap',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
SELECT OrganizationName, ISNULL(CAST(OrganizationId AS nvarchar(20)),N''), Active
FROM dbo.Dim_Pulseway_OrgMap WITH (NOLOCK)
WHERE CustomerCode = N'$codeLit';
"@
Write-Host 'Mapped now:'
Write-Host $rmmHave.StdOut

$rmmLike = New-LikeOr 'd.OrganizationName' $tokens
$rmmCand = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Pulseway_Devices',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
SELECT TOP 25 d.OrganizationName, COUNT_BIG(*) AS Devices,
       MAX(CAST(d.OrganizationId AS nvarchar(20))) AS OrgId
FROM dbo.Pulseway_Devices d WITH (NOLOCK)
WHERE d.SnapshotDate = (SELECT MAX(SnapshotDate) FROM dbo.Pulseway_Devices WITH (NOLOCK))
  AND $rmmLike
GROUP BY d.OrganizationName
ORDER BY Devices DESC;
"@
Write-Host 'Candidates (name match in latest Pulseway snapshot):'
Write-Host $rmmCand.StdOut
$rmmRows = @(Get-DataRows $rmmCand.StdOut | Where-Object { $_ -notmatch 'NO_TABLE' })
if ($rmmRows.Count -gt 0) {
  $i = 1
  foreach ($r in $rmmRows) { Write-Host ("  {0}) {1}" -f $i, $r); $i++ }
  $pick = Read-Default 'Map which numbers (comma), ALL, or NONE' $(if ($rmmRows.Count -eq 1) { '1' } else { 'NONE' })
  if ($pick -and $pick -notmatch '^(NONE|none|n)$') {
    $idxs = @()
    if ($pick -match '^(ALL|all)$') { $idxs = 1..$rmmRows.Count }
    else { $idxs = $pick.Split(',') | ForEach-Object { [int]($_.Trim()) } }
    foreach ($n in $idxs) {
      if ($n -lt 1 -or $n -gt $rmmRows.Count) { continue }
      $org = ($rmmRows[$n-1] -split '\|')[0].Trim()
      $orgLit = Escape-Sql $org
      $app = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
MERGE dbo.Dim_Pulseway_OrgMap AS t
USING (SELECT N'$orgLit' AS OrganizationName, N'$codeLit' AS CustomerCode) s
  ON t.OrganizationName = s.OrganizationName
WHEN MATCHED THEN UPDATE SET CustomerCode=s.CustomerCode, Active=1, Notes=N'cover-check'
WHEN NOT MATCHED THEN INSERT (OrganizationName, CustomerCode, Active, Notes)
  VALUES (s.OrganizationName, s.CustomerCode, 1, N'cover-check');
UPDATE dbo.Pulseway_Devices SET CustomerCode = N'$codeLit'
WHERE OrganizationName = N'$orgLit'
  AND (CustomerCode IS NULL OR CustomerCode <> N'$codeLit');
SELECT N'MAPPED' AS Msg, N'$orgLit';
"@
      Write-Host $app.StdOut
    }
    Set-Pillar 'PillarPulseway' 1 | Out-Null
    $score.RMM = 'COVERED (mapped)'
    Write-Ok 'Pulseway mapped + PillarPulseway=1'
  } else {
    $onRmm = Read-Default 'Is this customer on Pulseway / RMM at all? (Y/n)' 'Y'
    if ($onRmm -match '^[nN]') {
      Set-Pillar 'PillarPulseway' 0 | Out-Null
      $score.RMM = 'NO COVER (explicit)'
    } else {
      $score.RMM = 'SHOULD COVER - no org match. Map in Exco RMM or add alias.'
    }
  }
} else {
  Write-Warn2 'No Pulseway org name matched Sir Fruit / SIRF in the latest snapshot.'
  $onRmm = Read-Default 'Is this customer on Pulseway / RMM? (Y/n)' 'N'
  if ($onRmm -match '^[nN]') {
    Set-Pillar 'PillarPulseway' 0 | Out-Null
    $score.RMM = 'NO COVER (explicit)'
    Write-Ok 'PillarPulseway=0 so Exco will not wait for RMM'
  } else {
    $manual = Read-Default 'Type Pulseway OrganizationName exactly (or blank to skip)' ''
    if ($manual) {
      $orgLit = Escape-Sql $manual
      Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
MERGE dbo.Dim_Pulseway_OrgMap AS t
USING (SELECT N'$orgLit' AS OrganizationName, N'$codeLit' AS CustomerCode) s
  ON t.OrganizationName = s.OrganizationName
WHEN MATCHED THEN UPDATE SET CustomerCode=s.CustomerCode, Active=1
WHEN NOT MATCHED THEN INSERT (OrganizationName, CustomerCode, Active, Notes)
  VALUES (s.OrganizationName, s.CustomerCode, 1, N'cover-check manual');
UPDATE dbo.Pulseway_Devices SET CustomerCode=N'$codeLit' WHERE OrganizationName=N'$orgLit';
"@ | Out-Null
      Set-Pillar 'PillarPulseway' 1 | Out-Null
      $score.RMM = 'COVERED (manual map)'
    } else {
      $score.RMM = 'GAP - on RMM but not in latest collect. Re-run Pulseway collect.'
    }
  }
}

# ---------- Cove ----------
Write-Step '--- Cove backup ---'
$coveHave = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Dim_Cove_PartnerMap',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
SELECT PartnerName, ISNULL(CAST(PartnerId AS nvarchar(20)),N''), Active
FROM dbo.Dim_Cove_PartnerMap WITH (NOLOCK) WHERE CustomerCode=N'$codeLit';
"@
Write-Host 'Mapped now:'
Write-Host $coveHave.StdOut

$coveLike = New-LikeOr 'ISNULL(d.Product, d.CustomerCode)' $tokens
# Product often holds partner name; also try PartnerName if column exists
$coveCand = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Cove_DeviceStatistics',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
DECLARE @hasPartner bit = CASE WHEN COL_LENGTH(N'dbo.Cove_DeviceStatistics', N'PartnerName') IS NOT NULL THEN 1 ELSE 0 END;
DECLARE @hasProduct bit = CASE WHEN COL_LENGTH(N'dbo.Cove_DeviceStatistics', N'Product') IS NOT NULL THEN 1 ELSE 0 END;
IF @hasPartner = 1
  SELECT TOP 25 PartnerName AS PartnerName, COUNT_BIG(*) AS Devices
  FROM dbo.Cove_DeviceStatistics WITH (NOLOCK)
  WHERE SnapshotDate = (SELECT MAX(SnapshotDate) FROM dbo.Cove_DeviceStatistics WITH (NOLOCK))
    AND ($(New-LikeOr 'PartnerName' $tokens))
  GROUP BY PartnerName
  ORDER BY Devices DESC;
ELSE IF @hasProduct = 1
  SELECT TOP 25 Product AS PartnerName, COUNT_BIG(*) AS Devices
  FROM dbo.Cove_DeviceStatistics WITH (NOLOCK)
  WHERE SnapshotDate = (SELECT MAX(SnapshotDate) FROM dbo.Cove_DeviceStatistics WITH (NOLOCK))
    AND ($(New-LikeOr 'Product' $tokens))
  GROUP BY Product
  ORDER BY Devices DESC;
ELSE
  SELECT N'NO_NAME_COL';
"@
Write-Host 'Candidates:'
Write-Host $coveCand.StdOut
$coveRows = @(Get-DataRows $coveCand.StdOut | Where-Object { $_ -notmatch 'NO_TABLE|NO_NAME' })
if ($coveRows.Count -gt 0) {
  $i = 1
  foreach ($r in $coveRows) { Write-Host ("  {0}) {1}" -f $i, $r); $i++ }
  $pick = Read-Default 'Map which Cove partners (comma), ALL, or NONE' $(if ($coveRows.Count -eq 1) { '1' } else { 'NONE' })
  if ($pick -and $pick -notmatch '^(NONE|none|n)$') {
    $idxs = @()
    if ($pick -match '^(ALL|all)$') { $idxs = 1..$coveRows.Count }
    else { $idxs = $pick.Split(',') | ForEach-Object { [int]($_.Trim()) } }
    foreach ($n in $idxs) {
      if ($n -lt 1 -or $n -gt $coveRows.Count) { continue }
      $pn = ($coveRows[$n-1] -split '\|')[0].Trim()
      $pnLit = Escape-Sql $pn
      Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
MERGE dbo.Dim_Cove_PartnerMap AS t
USING (SELECT N'$pnLit' AS PartnerName, N'$codeLit' AS CustomerCode) s
  ON t.PartnerName = s.PartnerName
WHEN MATCHED THEN UPDATE SET CustomerCode=s.CustomerCode, Active=1, UpdatedAtUtc=SYSUTCDATETIME(), Notes=N'cover-check'
WHEN NOT MATCHED THEN INSERT (PartnerName, CustomerCode, Active, Notes)
  VALUES (s.PartnerName, s.CustomerCode, 1, N'cover-check');
IF OBJECT_ID(N'dbo.Dim_Cove_PartnerAlias',N'U') IS NOT NULL
  MERGE dbo.Dim_Cove_PartnerAlias AS t
  USING (SELECT N'$pnLit' AS PartnerName, N'$codeLit' AS CustomerCode) s
    ON t.PartnerName = s.PartnerName
  WHEN MATCHED THEN UPDATE SET CustomerCode=s.CustomerCode, Active=1
  WHEN NOT MATCHED THEN INSERT (PartnerName, CustomerCode, Active, Notes)
    VALUES (s.PartnerName, s.CustomerCode, 1, N'cover-check');
IF COL_LENGTH(N'dbo.Cove_DeviceStatistics', N'Product') IS NOT NULL
  UPDATE dbo.Cove_DeviceStatistics SET CustomerCode=N'$codeLit' WHERE Product=N'$pnLit';
IF COL_LENGTH(N'dbo.Cove_DeviceStatistics', N'PartnerName') IS NOT NULL
  UPDATE dbo.Cove_DeviceStatistics SET CustomerCode=N'$codeLit' WHERE PartnerName=N'$pnLit';
SELECT N'MAPPED' AS Msg, N'$pnLit';
"@ | ForEach-Object { Write-Host $_.StdOut }
    }
    Set-Pillar 'PillarCove' 1 | Out-Null
    $score.COVE = 'COVERED (mapped)'
    Write-Ok 'Cove mapped + PillarCove=1'
  } else {
    $onCove = Read-Default 'Is this customer on Cove backup? (Y/n)' 'Y'
    if ($onCove -match '^[nN]') {
      Set-Pillar 'PillarCove' 0 | Out-Null
      $score.COVE = 'NO COVER (explicit)'
    } else { $score.COVE = 'SHOULD COVER - no partner match. Map in Exco Cove.' }
  }
} else {
  Write-Warn2 'No Cove partner matched this name in the latest snapshot.'
  $onCove = Read-Default 'Is this customer on Cove backup? (Y/n)' 'N'
  if ($onCove -match '^[nN]') {
    Set-Pillar 'PillarCove' 0 | Out-Null
    $score.COVE = 'NO COVER (explicit)'
    Write-Ok 'PillarCove=0'
  } else {
    $manual = Read-Default 'Type Cove partner name exactly (or blank to skip)' ''
    if ($manual) {
      $pnLit = Escape-Sql $manual
      Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
MERGE dbo.Dim_Cove_PartnerMap AS t
USING (SELECT N'$pnLit' AS PartnerName, N'$codeLit' AS CustomerCode) s
  ON t.PartnerName = s.PartnerName
WHEN MATCHED THEN UPDATE SET CustomerCode=s.CustomerCode, Active=1
WHEN NOT MATCHED THEN INSERT (PartnerName, CustomerCode, Active, Notes)
  VALUES (s.PartnerName, s.CustomerCode, 1, N'cover-check manual');
"@ | Out-Null
      Set-Pillar 'PillarCove' 1 | Out-Null
      $score.COVE = 'COVERED (manual map)'
    } else { $score.COVE = 'GAP - on Cove but not in latest collect. Re-run Cove collect.' }
  }
}

# ---------- Bitdefender / EPP ----------
Write-Step '--- Bitdefender (EPP) ---'
$bdCand = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Bitdefender_Endpoints',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
IF COL_LENGTH(N'dbo.Bitdefender_Endpoints', N'CompanyName') IS NOT NULL
BEGIN
  SELECT TOP 25 CompanyName, COUNT_BIG(*) AS Endpoints
  FROM dbo.Bitdefender_Endpoints WITH (NOLOCK)
  WHERE SnapshotDate = (SELECT MAX(SnapshotDate) FROM dbo.Bitdefender_Endpoints WITH (NOLOCK))
    AND ($(New-LikeOr 'CompanyName' $tokens))
  GROUP BY CompanyName
  ORDER BY Endpoints DESC;
  RETURN;
END
IF COL_LENGTH(N'dbo.Bitdefender_Endpoints', N'Company') IS NOT NULL
BEGIN
  SELECT TOP 25 Company AS CompanyName, COUNT_BIG(*) AS Endpoints
  FROM dbo.Bitdefender_Endpoints WITH (NOLOCK)
  WHERE SnapshotDate = (SELECT MAX(SnapshotDate) FROM dbo.Bitdefender_Endpoints WITH (NOLOCK))
    AND ($(New-LikeOr 'Company' $tokens))
  GROUP BY Company
  ORDER BY Endpoints DESC;
  RETURN;
END
SELECT N'NO_NAME_COL';
"@
Write-Host 'Candidates:'
Write-Host $bdCand.StdOut
$bdRows = @(Get-DataRows $bdCand.StdOut | Where-Object { $_ -notmatch 'NO_TABLE|NO_NAME' })
if ($bdRows.Count -gt 0) {
  $i = 1
  foreach ($r in $bdRows) { Write-Host ("  {0}) {1}" -f $i, $r); $i++ }
  $pick = Read-Default 'Map which Bitdefender companies (comma), ALL, or NONE' $(if ($bdRows.Count -eq 1) { '1' } else { 'NONE' })
  if ($pick -and $pick -notmatch '^(NONE|none|n)$') {
    $idxs = @()
    if ($pick -match '^(ALL|all)$') { $idxs = 1..$bdRows.Count }
    else { $idxs = $pick.Split(',') | ForEach-Object { [int]($_.Trim()) } }
    foreach ($n in $idxs) {
      if ($n -lt 1 -or $n -gt $bdRows.Count) { continue }
      $cn = ($bdRows[$n-1] -split '\|')[0].Trim()
      $cnLit = Escape-Sql $cn
      Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
MERGE dbo.Dim_Bitdefender_CompanyMap AS t
USING (SELECT N'$cnLit' AS CompanyName, N'$codeLit' AS CustomerCode) s
  ON t.CompanyName = s.CompanyName AND t.CustomerCode = s.CustomerCode
WHEN MATCHED THEN UPDATE SET Active=1, Notes=N'cover-check'
WHEN NOT MATCHED THEN INSERT (CompanyName, CustomerCode, Active, Notes)
  VALUES (s.CompanyName, s.CustomerCode, 1, N'cover-check');
IF COL_LENGTH(N'dbo.Bitdefender_Endpoints', N'CompanyName') IS NOT NULL
  UPDATE dbo.Bitdefender_Endpoints SET CustomerCode=N'$codeLit' WHERE CompanyName=N'$cnLit';
SELECT N'MAPPED' AS Msg, N'$cnLit';
"@ | ForEach-Object { Write-Host $_.StdOut }
    }
    Set-Pillar 'PillarBitdefender' 1 | Out-Null
    $score.EPP = 'COVERED (mapped)'
    Write-Ok 'Bitdefender mapped + PillarBitdefender=1'
  } else {
    $onBd = Read-Default 'Is this customer on Bitdefender? (Y/n)' 'N'
    if ($onBd -match '^[nN]') { Set-Pillar 'PillarBitdefender' 0 | Out-Null; $score.EPP = 'NO COVER (explicit)' }
    else { $score.EPP = 'SHOULD COVER - no company match.' }
  }
} else {
  Write-Warn2 'No Bitdefender company matched this name.'
  $onBd = Read-Default 'Is this customer on Bitdefender? (Y/n)' 'N'
  if ($onBd -match '^[nN]') {
    Set-Pillar 'PillarBitdefender' 0 | Out-Null
    $score.EPP = 'NO COVER (explicit)'
  } else { $score.EPP = 'GAP - on Bitdefender but not in latest collect.' }
}

# ---------- M365 / CSP ----------
Write-Step '--- Microsoft 365 (CSP) ---'
$cspHave = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Dim_Csp_TenantMap',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
SELECT TenantId, ISNULL(DisplayName,N''), ISNULL(PrimaryDomain,N''), Active
FROM dbo.Dim_Csp_TenantMap WITH (NOLOCK) WHERE CustomerCode=N'$codeLit';
"@
Write-Host 'Mapped now:'
Write-Host $cspHave.StdOut
$cspLike1 = New-LikeOr 'ISNULL(DisplayName,N'''')' $tokens
$cspLike2 = New-LikeOr 'ISNULL(PrimaryDomain,N'''')' $tokens
$cspCand = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Dim_Csp_TenantMap',N'U') IS NULL BEGIN SELECT N'NO_TABLE'; RETURN; END
SELECT TOP 25 TenantId, ISNULL(DisplayName,N''), ISNULL(PrimaryDomain,N''), CustomerCode
FROM dbo.Dim_Csp_TenantMap WITH (NOLOCK)
WHERE $cspLike1 OR $cspLike2
ORDER BY DisplayName;
"@
Write-Host 'Candidates already in tenant map (any customer):'
Write-Host $cspCand.StdOut
$onCsp = Read-Default 'Is this customer on RPM Microsoft 365 / CSP? (Y/n)' 'N'
if ($onCsp -match '^[nN]') {
  Set-Pillar 'PillarMicrosoftCsp' 0 | Out-Null
  $score.CSP = 'NO COVER (explicit)'
  Write-Ok 'PillarMicrosoftCsp=0'
} else {
  $tid = Read-Default 'Tenant Id (GUID) if you have it (or blank)' ''
  $dom = Read-Default 'Primary domain e.g. sirfruit.co.za (or blank)' ''
  if ($tid -or $dom) {
    if (-not $tid) { $tid = 'pending-' + $CustomerCode.ToLowerInvariant() }
    $tidLit = Escape-Sql $tid
    $domLit = Escape-Sql $dom
    Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
MERGE dbo.Dim_Csp_TenantMap AS t
USING (SELECT N'$codeLit' AS CustomerCode, N'$tidLit' AS TenantId) s
  ON t.CustomerCode = s.CustomerCode AND t.TenantId = s.TenantId
WHEN MATCHED THEN UPDATE SET PrimaryDomain=NULLIF(N'$domLit',N''), DisplayName=N'$nameLit', Active=1
WHEN NOT MATCHED THEN INSERT (CustomerCode, TenantId, PrimaryDomain, DisplayName, Active, Notes)
  VALUES (s.CustomerCode, s.TenantId, NULLIF(N'$domLit',N''), N'$nameLit', 1, N'cover-check');
"@ | Out-Null
    Set-Pillar 'PillarMicrosoftCsp' 1 | Out-Null
    $score.CSP = 'COVERED (mapped) - run CSP collect for that tenant'
  } else {
    $score.CSP = 'SHOULD COVER - add tenant in Exco CSP / run Write-Csp-Config'
    Set-Pillar 'PillarMicrosoftCsp' 1 | Out-Null
  }
}

# ---------- final scorecard ----------
Write-Step '--- Cover scorecard ---'
$fin = Invoke-Sql -Sqlcmd $sqlcmd -Server $CentralHost -User $CentralUser -Password $CentralPwd -Database $CentralDb -Query @"
SET NOCOUNT ON;
SELECT c.CustomerCode, c.DisplayName, c.SqlInstanceName,
       ISNULL(a.PillarSyspro,0) AS Syspro,
       ISNULL(a.PillarPulseway,0) AS Rmm,
       ISNULL(a.PillarCove,0) AS Cove,
       ISNULL(a.PillarBitdefender,0) AS Epp,
       ISNULL(a.PillarMicrosoftCsp,0) AS Csp
FROM dbo.Dim_Customer c
LEFT JOIN dbo.Dim_Customer_AmsConfig a ON a.CustomerCode=c.CustomerCode
WHERE c.CustomerCode=N'$codeLit';
"@
Write-Host $fin.StdOut

Write-Host ''
Write-Host '========================================' -ForegroundColor Green
Write-Host (" COVER CHECK  {0}  {1}" -f $CustomerCode, $DisplayName)
Write-Host ("  SYSPRO       : {0}" -f $score.SYSPRO)
Write-Host ("  RMM Pulseway : {0}" -f $score.RMM)
Write-Host ("  Cove backup  : {0}" -f $score.COVE)
Write-Host ("  Bitdefender  : {0}" -f $score.EPP)
Write-Host ("  Microsoft 365: {0}" -f $score.CSP)
Write-Host '  Hard-refresh Exco - pillars follow this map.'
Write-Host '========================================' -ForegroundColor Green

$outDir = "C:\RPM-Assure\Sql\customers\$CustomerCode"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$proof = @(
  "COVER CHECK $CustomerCode $DisplayName $(Get-Date -Format o)",
  "SYSPRO=$($score.SYSPRO)",
  "RMM=$($score.RMM)",
  "COVE=$($score.COVE)",
  "EPP=$($score.EPP)",
  "CSP=$($score.CSP)"
) -join [Environment]::NewLine
[IO.File]::WriteAllText((Join-Path $outDir 'COVER_PROOF.txt'), $proof)
Write-Host ("Wrote " + (Join-Path $outDir 'COVER_PROOF.txt'))
Write-Host '=== Done ==='
