FORCE apply Option A login (self-contained).
1. Expand zip
2. Run Apply-Login-Option-A-Force.ps1 as admin if needed
3. Open PRIVATE window to /login
