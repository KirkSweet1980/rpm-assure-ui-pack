# Apply-Epp-455-CompanyMap-Pillars.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$SqlRoot = 'C:\RPM-Assure\Sql\bitdefender'
$Server = '102.222.21.220,14333'
$Db = 'RPMAssure_App'
Copy-Item (Join-Path $Here 'Sql\bitdefender\455_Fix_CompanyMap_And_Pillars.sql') (Join-Path $SqlRoot '455_Fix_CompanyMap_And_Pillars.sql') -Force
Copy-Item (Join-Path $Here 'Sql\bitdefender\Collect-Bitdefender-To-RPMAssure.ps1') (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1') -Force
Write-Host '=== 455 company map + pillars ==='
& sqlcmd -S $Server -d $Db -E -C -b -i (Join-Path $SqlRoot '455_Fix_CompanyMap_And_Pillars.sql') 2>&1 | ForEach-Object { Write-Host $_ }
Write-Host '=== Re-collect (company-first mapping) ==='
powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1')
Write-Host ("collect exit=" + $LASTEXITCODE)
Write-Host 'Restart app...'
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 6
} catch { Write-Host $_ }
Write-Host 'Hard-refresh EPP for ABLE, BHF, RSS, AHIC, RSR, UVSS, METSI, MEDIPOS, YLJ, RPMINT.'
Write-Host '=== Done ==='
