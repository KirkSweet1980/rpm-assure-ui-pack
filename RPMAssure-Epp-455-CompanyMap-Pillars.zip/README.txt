Fix company map + pillars + recollect. Run Apply-Epp-455-CompanyMap-Pillars.ps1
