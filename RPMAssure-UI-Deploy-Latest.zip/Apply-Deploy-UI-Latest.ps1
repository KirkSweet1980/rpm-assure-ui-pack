# Apply-Deploy-UI-Latest.ps1
# Deploys latest RPM Assure UI (src + public) to C:\RPM-Assure\App and restarts.
# Pure ASCII. Run elevated on the APP SERVER.
$ErrorActionPreference = 'Stop'

$App = 'C:\RPM-Assure\App'
$Port = 8081
$utf8 = New-Object System.Text.UTF8Encoding $false

# Locate this script's folder (payload next to it)
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Here) { $Here = (Get-Location).Path }
$Payload = Join-Path $Here 'payload'
if (-not (Test-Path (Join-Path $Payload 'src'))) {
  # zip may extract with an extra folder layer
  $alt = Get-ChildItem $Here -Recurse -Directory -Filter 'payload' -ErrorAction SilentlyContinue |
    Where-Object { Test-Path (Join-Path $_.FullName 'src') } |
    Select-Object -First 1
  if ($alt) { $Payload = $alt.FullName }
}
if (-not (Test-Path (Join-Path $Payload 'src'))) {
  throw "Missing payload\src next to this script. Extract the full zip first. Looked under: $Here"
}

# Prefer standard App path; also support Program Files layout
if (-not (Test-Path $App)) {
  foreach ($c in @(
      'C:\Program Files\RPM Resources\RPM Assure\app',
      'C:\Program Files\RPM Resources\RPM Assure\App'
    )) {
    if (Test-Path $c) { $App = $c; break }
  }
}
if (-not (Test-Path $App)) { throw "App not found: C:\RPM-Assure\App" }

Write-Host '=== Deploy latest UI ==='
Write-Host "Payload = $Payload"
Write-Host "App     = $App"

$markerIn = Join-Path $Payload 'UI_DEPLOY_MARKER.txt'
if (Test-Path $markerIn) {
  Write-Host '--- package marker ---'
  Get-Content $markerIn
}

# Backup existing src (timestamped)
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$BackupRoot = Join-Path $App ("_backup_ui_" + $stamp)
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
if (Test-Path (Join-Path $App 'src')) {
  Write-Host "Backing up src -> $BackupRoot\src"
  Copy-Item (Join-Path $App 'src') (Join-Path $BackupRoot 'src') -Recurse -Force
}
if (Test-Path (Join-Path $App 'public')) {
  Copy-Item (Join-Path $App 'public') (Join-Path $BackupRoot 'public') -Recurse -Force -ErrorAction SilentlyContinue
}

# Deploy src
$destSrc = Join-Path $App 'src'
if (Test-Path $destSrc) {
  # Remove old src contents carefully then copy fresh
  Write-Host 'Replacing App\src ...'
  Remove-Item $destSrc -Recurse -Force
}
Copy-Item (Join-Path $Payload 'src') $destSrc -Recurse -Force
Write-Host "OK $destSrc"

# Deploy public (merge/replace)
$destPublic = Join-Path $App 'public'
if (Test-Path (Join-Path $Payload 'public')) {
  New-Item -ItemType Directory -Force -Path $destPublic | Out-Null
  Copy-Item (Join-Path $Payload 'public\*') $destPublic -Recurse -Force
  Write-Host "OK $destPublic"
}

# Optional: vite/tsconfig only if missing (do not clobber working server config lightly)
foreach ($f in @('vite.config.ts', 'tsconfig.json')) {
  $srcF = Join-Path $Payload $f
  $dstF = Join-Path $App $f
  if ((Test-Path $srcF) -and -not (Test-Path $dstF)) {
    Copy-Item $srcF $dstF -Force
    Write-Host "OK added $f"
  }
}

# Write deploy marker into App
$markerOut = Join-Path $App 'UI_DEPLOY_MARKER.txt'
if (Test-Path $markerIn) {
  Copy-Item $markerIn $markerOut -Force
} else {
  [System.IO.File]::WriteAllText($markerOut, ("UI-DEPLOY-LATEST applied " + (Get-Date).ToString('o') + "`r`n"), $utf8)
}
Write-Host "OK $markerOut"

# Mirror to C:\RPM-Assure\src if present (some older starts used it)
$mirror = 'C:\RPM-Assure\src'
if (Test-Path (Split-Path $mirror -Parent)) {
  if (Test-Path $mirror) { Remove-Item $mirror -Recurse -Force -ErrorAction SilentlyContinue }
  Copy-Item $destSrc $mirror -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "OK mirrored $mirror"
}

# Clear Vite cache so UI is not sticky
$viteCache = Join-Path $App 'node_modules\.vite'
if (Test-Path $viteCache) {
  Remove-Item $viteCache -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host 'Cleared node_modules\.vite'
}

# Restart app
Write-Host '--- Restart app ---'
try { schtasks /End /TN 'RPMAssure-App-OnStart' 2>$null | Out-Null } catch {}
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$listen = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($listen) {
  foreach ($c in @($listen)) {
    try { Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  Start-Sleep -Seconds 2
}

$started = $false
$task = schtasks /Run /TN 'RPMAssure-App-OnStart' 2>&1
if ($LASTEXITCODE -eq 0) {
  Write-Host 'Started RPMAssure-App-OnStart'
  $started = $true
} else {
  $serverJs = Join-Path $App '.output\server\index.mjs'
  $nodeExe = $null
  foreach ($n in @(
      'C:\Program Files\RPM Resources\RPM Assure\runtime\node\node.exe',
      'C:\Nodejs\node.exe',
      'C:\Program Files\nodejs\node.exe'
    )) {
    if (Test-Path $n) { $nodeExe = $n; break }
  }
  if (-not $nodeExe) {
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) { $nodeExe = $cmd.Source }
  }
  $logDir = 'C:\RPM-Assure\deploy\logs'
  if (-not (Test-Path $logDir)) { $logDir = Join-Path $env:TEMP 'rpma-logs' }
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null

  if ((Test-Path $serverJs) -and $nodeExe) {
    Write-Host 'NOTE: production .output is STALE until you rebuild.' -ForegroundColor Yellow
    Write-Host 'Starting vite dev so new UI is live immediately...'
    $cmdLine = "cd /d `"$App`" && npx.cmd vite dev --host 0.0.0.0 --port $Port >> `"$logDir\app-stdout.log`" 2>> `"$logDir\app-stderr.log`""
    Start-Process cmd.exe -ArgumentList '/c', $cmdLine -WorkingDirectory $App -WindowStyle Minimized
    $started = $true
  } elseif ($nodeExe -and (Test-Path (Join-Path $App 'package.json'))) {
    Write-Host 'Starting vite dev...'
    $cmdLine = "cd /d `"$App`" && npx.cmd vite dev --host 0.0.0.0 --port $Port >> `"$logDir\app-stdout.log`" 2>> `"$logDir\app-stderr.log`""
    Start-Process cmd.exe -ArgumentList '/c', $cmdLine -WorkingDirectory $App -WindowStyle Minimized
    $started = $true
  }
}

if (-not $started) {
  Write-Host 'WARN: could not auto-start. Start app manually.' -ForegroundColor Yellow
}

$up = $false
for ($i = 1; $i -le 50; $i++) {
  Start-Sleep -Seconds 1
  $l = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
  if ($l) {
    Write-Host "LISTENING PID $($l[0].OwningProcess)"
    $up = $true
    break
  }
}

if ($up) {
  Start-Sleep -Seconds 4
  try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/" -UseBasicParsing -TimeoutSec 20
    Write-Host ("HTTP " + $r.StatusCode + " len=" + $r.RawContentLength) -ForegroundColor Green
  } catch {
    Write-Host ("Probe: " + $_.Exception.Message) -ForegroundColor Yellow
  }
}

Write-Host ''
Write-Host '========================================' -ForegroundColor Green
Write-Host ' UI DEPLOYED'
Write-Host "  App:     $App"
Write-Host "  Backup:  $BackupRoot"
Write-Host '  Browser: hard-refresh (Ctrl+F5) or private window'
Write-Host '  Marker:  C:\RPM-Assure\App\UI_DEPLOY_MARKER.txt'
Write-Host '========================================' -ForegroundColor Green
Write-Host 'Live SQL is separate - run Apply-Connect-Live-Data.ps1 if portfolio is still demo.'
Write-Host 'For production node rebuild later:'
Write-Host '  cd C:\RPM-Assure\App'
Write-Host '  npm.cmd run build:node'
Write-Host '=== Done ==='
