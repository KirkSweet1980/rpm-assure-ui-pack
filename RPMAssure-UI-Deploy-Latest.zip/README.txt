RPM Assure - Latest UI deploy pack
==================================

Contents:
  payload\src\          Full UI source (routes, components, lib)
  payload\public\       Brand / static assets
  payload\UI_DEPLOY_MARKER.txt
  Apply-Deploy-UI-Latest.ps1
  Apply-Connect-Live-Data.ps1   (optional: wire live SQL after UI)

On APP SERVER (elevated PowerShell):

  $zip  = "$env:USERPROFILE\Downloads\RPMAssure-UI-Deploy-Latest.zip"
  $dest = "$env:USERPROFILE\Downloads\RPMAssure-UI-Deploy-Latest"
  Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
  Unblock-File "$dest\Apply-Deploy-UI-Latest.ps1"
  powershell -NoProfile -ExecutionPolicy Bypass -File "$dest\Apply-Deploy-UI-Latest.ps1"

Then hard-refresh the browser (Ctrl+F5).

Optional - connect live SQL after UI is up:

  powershell -NoProfile -ExecutionPolicy Bypass -File "$dest\Apply-Connect-Live-Data.ps1"

Notes:
- Backs up existing App\src to App\_backup_ui_YYYYMMDD_HHMMSS
- Starts vite so source UI is live immediately
- Production .output is NOT rebuilt by this pack (run npm run build:node later if you use node server only)
