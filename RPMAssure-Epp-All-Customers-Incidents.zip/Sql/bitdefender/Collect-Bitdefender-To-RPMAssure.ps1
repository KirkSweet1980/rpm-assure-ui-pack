# Collect Bitdefender GravityZone endpoints → RPMAssure_App (EPP pillar)
# Auth: Basic base64(ApiKey + ":")
# Map: Dim_Bitdefender_NameMap patterns against Name+Fqdn; optional default RPMINT for staff

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
. (Join-Path $here 'Bitdefender.Config.ps1')

# Optional SQL overrides in config; else defaults used on central
if (-not $SqlServer)   { $SqlServer = '102.222.21.220,14333' }
if (-not $SqlDatabase) { $SqlDatabase = 'RPMAssure_App' }
if (-not $SqlUser)     { $SqlUser = 'Rpm_collect' }
if (-not $SqlPassword) { $SqlPassword = 'RpmCollect#AHIC2026' }
if (-not $DefaultUnmappedCode) { $DefaultUnmappedCode = '' } # set 'RPMINT' to stamp staff devices

if ([string]::IsNullOrWhiteSpace($ApiKey) -or $ApiKey -like 'PASTE*') { throw 'Set $ApiKey in Bitdefender.Config.ps1' }
if ([string]::IsNullOrWhiteSpace($AccessUrl)) { $AccessUrl = 'https://cloud.gravityzone.bitdefender.com' }
$AccessUrl = $AccessUrl.TrimEnd('/')
$baseApi = if ($AccessUrl -match '/api$') { $AccessUrl } else { $AccessUrl + '/api' }

$logDir = Join-Path $here 'logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$log = Join-Path $logDir ("bd_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
$script:RpcId = 0

function Write-Log([string]$m) {
  $line = ('{0:u} {1}' -f (Get-Date).ToUniversalTime(), $m)
  Add-Content -LiteralPath $log -Value $line
  Write-Host $line
}

function Get-AuthHeader {
  $b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($ApiKey + ':')))
  return ('Basic ' + $b64)
}

function ConvertTo-Text($c) {
  if ($null -eq $c) { return '' }
  if ($c -is [string]) { return $c }
  if ($c -is [byte[]]) { return [Text.Encoding]::UTF8.GetString($c) }
  try { return [Text.Encoding]::UTF8.GetString([byte[]]$c) } catch { return [string]$c }
}

function Find-Sqlcmd {
  $c = Get-Command sqlcmd -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  $paths = @(
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\SQLCMD.EXE',
    'C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\130\Tools\Binn\SQLCMD.EXE'
  )
  foreach ($p in $paths) { if (Test-Path $p) { return $p } }
  throw 'sqlcmd not found'
}

function Invoke-SqlText([string]$SqlText, [string]$Label) {
  $sqlcmd = Find-Sqlcmd
  $f = Join-Path $logDir ("{0}_{1:yyyyMMdd_HHmmss}.sql" -f $Label, (Get-Date))
  [IO.File]::WriteAllText($f, $SqlText, [Text.UTF8Encoding]::new($false))
  Write-Log ("SQL " + $Label + " -> " + $f)
  & $sqlcmd -S $SqlServer -d $SqlDatabase -U $SqlUser -P $SqlPassword -C -b -i $f
  if ($LASTEXITCODE -ne 0) { throw ("sqlcmd failed " + $LASTEXITCODE + " on " + $Label) }
}

function Invoke-GzRpc {
  param([string]$Service, [string]$Method, [hashtable]$Params = @{})
  $script:RpcId++
  $uri = '{0}/v1.0/jsonrpc/{1}' -f $baseApi, $Service
  $body = (@{
      jsonrpc = '2.0'
      id      = [string]$script:RpcId
      method  = $Method
      params  = $Params
    } | ConvertTo-Json -Depth 12 -Compress)
  $resp = Invoke-WebRequest -Uri $uri -Method POST -Headers @{
    Authorization  = (Get-AuthHeader)
    'Content-Type' = 'application/json'
  } -Body $body -UseBasicParsing -TimeoutSec 90
  return (ConvertTo-Text $resp.Content)
}

function Sql-Str([string]$s) {
  if ($null -eq $s -or $s -eq '') { return 'NULL' }
  return ("N'{0}'" -f ($s.Replace("'", "''")))
}

function Sql-Bit($v) {
  if ($null -eq $v) { return 'NULL' }
  if ($v -eq $true -or "$v" -eq '1' -or "$v" -eq 'True') { return '1' }
  return '0'
}

function Sql-Int($v) {
  if ($null -eq $v -or "$v" -eq '') { return 'NULL' }
  $n = 0
  if ([int]::TryParse("$v", [ref]$n)) { return [string]$n }
  return 'NULL'
}

Write-Log '=== Bitdefender EPP collect start ==='
Write-Log ("SQL=" + $SqlServer + " / " + $SqlDatabase)
Write-Log ("API=" + $baseApi)

# Schema must already exist (Apply-Bitdefender-450 as admin). Soft re-seed map only.
$seedMap = @'
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Dim_Bitdefender_NameMap', N'U') IS NULL
BEGIN
  RAISERROR(N'Dim_Bitdefender_NameMap missing — run 450 as SQL admin first.', 16, 1);
  RETURN;
END
MERGE dbo.Dim_Bitdefender_NameMap AS t
USING (VALUES
  (N'AHIC', N'AHIC', N'Prefix', 10, N'AHI Carrier servers'),
  (N'ahi-carrier', N'AHIC', N'Contains', 20, N'FQDN domain'),
  (N'HYDRA', N'HYDRA', N'Prefix', 10, N'Hydrasales'),
  (N'AHIC', N'AHIC', N'Prefix', 10, N'AHI'),
  (N'ahi-carrier', N'AHIC', N'Contains', 20, N'FQDN'),
  (N'HYDRA', N'HYDRA', N'Prefix', 10, N'Hydra'),
  (N'HYDRASRV', N'HYDRA', N'Prefix', 8, N'HYDRASRV'),
  (N'RSR', N'RSR', N'Prefix', 12, N'Redsun'),
  (N'RSR-', N'RSR', N'Prefix', 10, N'Redsun Raisins'),
  (N'REDSUN', N'RSR', N'Contains', 20, N'Redsun'),
  (N'UVSS', N'UVSS', N'Prefix', 10, N'UVSS'),
  (N'RPM', N'RPMINT', N'Prefix', 28, N'RPM hosts'),
  (N'RPM-', N'RPMINT', N'Prefix', 10, N'RPM Resources servers'),
  (N'rpmresources', N'RPMINT', N'Contains', 20, N'RPM FQDN'),
  (N'RPMWINRM', N'RPMINT', N'Prefix', 10, N'Central winrm'),
  (N'RPMPET', N'RPMINT', N'Prefix', 8, N'rpmpet'),
  (N'LUKERPM', N'RPMINT', N'Prefix', 30, N'RPM staff'),
  (N'METSI', N'METSI', N'Prefix', 10, N'Metsi'),
  (N'ABLE', N'ABLE', N'Prefix', 10, N'Able Tracers'),
  (N'AT-', N'ABLE', N'Prefix', 15, N'AT-SERVER'),
  (N'RSS', N'RSS', N'Prefix', 12, N'RSS'),
  (N'RSS-', N'RSS', N'Prefix', 10, N'Remote Site Solutions'),
  (N'PCNS', N'BHF', N'Prefix', 10, N'BHF / PCNS'),
  (N'BHF', N'BHF', N'Prefix', 15, N'BHF'),
  (N'SBS', N'SBS', N'Prefix', 12, N'SBS'),
  (N'SBS-', N'SBS', N'Prefix', 10, N'Simply Bright'),
  (N'SIMPLY', N'SBS', N'Contains', 20, N'Simply Bright')
) AS s(Pattern, CustomerCode, MatchType, Priority, Notes)
ON t.Pattern = s.Pattern AND t.CustomerCode = s.CustomerCode
WHEN MATCHED THEN UPDATE SET MatchType=s.MatchType, Priority=s.Priority, Notes=s.Notes, Active=1, UpdatedAtUtc=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT (Pattern, CustomerCode, MatchType, Priority, Notes, Active)
  VALUES (s.Pattern, s.CustomerCode, s.MatchType, s.Priority, s.Notes, 1);
'@
try {
  Invoke-SqlText -SqlText $seedMap -Label 'bd_seed_map'
} catch {
  Write-Log ("WARN seed map: " + $_.Exception.Message)
}

# Load name map from SQL
$mapSql = @'
SET NOCOUNT ON;
SELECT Pattern, CustomerCode, MatchType, Priority
FROM dbo.Dim_Bitdefender_NameMap WITH (NOLOCK)
WHERE Active = 1
ORDER BY Priority ASC, Pattern ASC;
'@
$mapFile = Join-Path $logDir 'name_map_query.sql'
[IO.File]::WriteAllText($mapFile, $mapSql, [Text.UTF8Encoding]::new($false))
$sqlcmd = Find-Sqlcmd
$mapRaw = & $sqlcmd -S $SqlServer -d $SqlDatabase -U $SqlUser -P $SqlPassword -C -h -1 -W -s '|' -i $mapFile 2>&1 | Out-String
$maps = New-Object System.Collections.Generic.List[object]
foreach ($line in ($mapRaw -split "`r?`n")) {
  if ($line -notmatch '\|') { continue }
  if ($line -match 'Pattern|rows affected|---') { continue }
  $parts = $line.Split('|')
  if ($parts.Count -lt 3) { continue }
  $maps.Add([pscustomobject]@{
      Pattern      = $parts[0].Trim()
      CustomerCode = $parts[1].Trim()
      MatchType    = $parts[2].Trim()
      Priority     = if ($parts.Count -gt 3) { [int]($parts[3].Trim()) } else { 100 }
    })
}
Write-Log ("Name map rules=" + $maps.Count)

function Resolve-CustomerCode([string]$Name, [string]$Fqdn) {
  $hay = (($Name + ' ' + $Fqdn)).ToUpperInvariant()
  foreach ($m in $maps) {
    $pat = $m.Pattern.ToUpperInvariant()
    $mt = $m.MatchType
    $hit = $false
    if ($mt -eq 'Exact') {
      if ($Name.ToUpperInvariant() -eq $pat -or $Fqdn.ToUpperInvariant() -eq $pat) { $hit = $true }
    } elseif ($mt -eq 'Prefix') {
      if ($Name.ToUpperInvariant().StartsWith($pat) -or $Fqdn.ToUpperInvariant().StartsWith($pat)) { $hit = $true }
      if (-not $hit -and $hay.Contains($pat)) {
        if ($hay -match ("(?:^|[^A-Z0-9])" + [regex]::Escape($pat))) { $hit = $true }
      }
    } else {
      if ($hay.Contains($pat)) { $hit = $true }
    }
    if ($hit) { return $m.CustomerCode }
  }
  # Regex fallback (same rules as explore Suggest-Code)
  if ($hay -match 'AHI|CARRIER') { return 'AHIC' }
  if ($hay -match 'BHF|PCNS|HEALTHCARE|FUNDERS') { return 'BHF' }
  if ($hay -match 'HYDRA') { return 'HYDRA' }
  if ($hay -match 'REDSUN|\bRSR\b|RSR-') { return 'RSR' }
  if ($hay -match 'REMOTE.?SITE|\bRSS\b|RSS-') { return 'RSS' }
  if ($hay -match 'UVSS|VENTILATION') { return 'UVSS' }
  if ($hay -match 'ABLE|\bAT-') { return 'ABLE' }
  if ($hay -match '\bRPM|RPMPET|RPMWINRM|LUKERPM|RPMRESOURCES') { return 'RPMINT' }
  if ($hay -match 'SIMPLY|\bSBS\b|SBS-') { return 'SBS' }
  if ($hay -match 'METSI') { return 'METSI' }
  if ($hay -match 'MEDIPOS') { return 'MEDIPOS' }
  if ($hay -match 'INTERBRAND') { return 'IB' }
  if ($hay -match 'VAULT') { return 'VAULT' }
  if ($hay -match '\bYLJ\b') { return 'YLJ' }
  if ($DefaultUnmappedCode) { return $DefaultUnmappedCode }
  return $null
}

# Fetch all endpoints
$allEp = New-Object System.Collections.Generic.List[object]
$page = 1
$pages = 1
do {
  $raw = Invoke-GzRpc -Service 'network' -Method 'getEndpointsList' -Params @{ page = $page; perPage = 50 }
  if ($page -eq 1) {
    [IO.File]::WriteAllText((Join-Path $logDir 'last_endpoints.json'), $raw, [Text.UTF8Encoding]::new($false))
  }
  if ($raw -match '"error"') { throw ("getEndpointsList error: " + $raw.Substring(0, [Math]::Min(300, $raw.Length))) }
  $eo = $raw | ConvertFrom-Json
  $pages = [int]$eo.result.pagesCount
  if ($pages -lt 1) { $pages = 1 }
  foreach ($it in @($eo.result.items)) { $allEp.Add($it) }
  Write-Log ("Endpoints page " + $page + "/" + $pages + " total=" + $eo.result.total)
  $page++
} while ($page -le $pages -and $page -le 40)

Write-Log ("Endpoints from API=" + $allEp.Count)
if ($allEp.Count -eq 0) { throw 'No endpoints from GravityZone' }

$snap = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd')
$values = New-Object System.Collections.Generic.List[string]
$codeCounts = @{}
$unmapped = 0

foreach ($ep in $allEp) {
  $id = [string]$ep.id
  if (-not $id) { continue }
  $name = [string]$ep.name
  $fqdn = [string]$ep.fqdn
  $code = Resolve-CustomerCode $name $fqdn
  if (-not $code) { $unmapped++; $codeKey = '(unmapped)' } else { $codeKey = $code }
  if (-not $codeCounts.ContainsKey($codeKey)) { $codeCounts[$codeKey] = 0 }
  $codeCounts[$codeKey]++

  $ip = ''
  if ($ep.ip) { $ip = [string]$ep.ip }
  $gid = ''
  if ($ep.groupId) { $gid = [string]$ep.groupId }
  $os = ''
  if ($ep.operatingSystemVersion) { $os = [string]$ep.operatingSystemVersion }
  $polId = ''; $polName = ''
  if ($ep.policy) {
    if ($ep.policy.id) { $polId = [string]$ep.policy.id }
    if ($ep.policy.name) { $polName = [string]$ep.policy.name }
  }
  $macs = ''
  if ($ep.macs) {
    try { $macs = (@($ep.macs) -join ',') } catch { $macs = [string]$ep.macs }
    if ($macs.Length -gt 400) { $macs = $macs.Substring(0, 400) }
  }

  $codeSql = if ($code) { Sql-Str $code } else { 'NULL' }
  $values.Add((
    "({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12})" -f `
      ("'{0}'" -f $snap),
      (Sql-Str $id),
      $codeSql,
      (Sql-Str $name),
      (Sql-Str $fqdn),
      (Sql-Str $ip),
      (Sql-Str $gid),
      (Sql-Bit $ep.isManaged),
      (Sql-Int $ep.machineType),
      (Sql-Str $os),
      (Sql-Str $polId),
      (Sql-Str $polName),
      (Sql-Str $macs)
  ))
}

Write-Log '--- Map counts ---'
foreach ($k in ($codeCounts.Keys | Sort-Object)) {
  Write-Log ("  " + $k + " n=" + $codeCounts[$k])
}
Write-Log ("Unmapped=" + $unmapped)

# License
try {
  $licRaw = Invoke-GzRpc -Service 'licensing' -Method 'getLicenseInfo' -Params @{}
  [IO.File]::WriteAllText((Join-Path $logDir 'last_license.json'), $licRaw, [Text.UTF8Encoding]::new($false))
  $lic = ($licRaw | ConvertFrom-Json).result
  $used = Sql-Int $lic.usedSlots
  $res = Sql-Int $lic.reservedSlots
  $tot = Sql-Int $lic.totalSlots
  $endSub = 'NULL'
  $exp = 'NULL'
  if ($lic.endSubscription) {
    try { $endSub = ("'{0}'" -f ([datetime]$lic.endSubscription).ToString('yyyy-MM-dd')) } catch {}
  }
  if ($lic.expiryDate) {
    try { $exp = ("'{0}'" -f ([datetime]$lic.expiryDate).ToString('yyyy-MM-dd')) } catch {}
  }
  $rawJson = Sql-Str ($(if ($licRaw.Length -gt 4000) { $licRaw.Substring(0, 4000) } else { $licRaw }))
  $licSql = @"
SET NOCOUNT ON;
MERGE dbo.Bitdefender_LicenseSnapshot AS t
USING (SELECT CAST('$snap' AS date) AS SnapshotDate) s ON t.SnapshotDate = s.SnapshotDate
WHEN MATCHED THEN UPDATE SET
  UsedSlots=$used, ReservedSlots=$res, TotalSlots=$tot,
  EndSubscription=$endSub, ExpiryDate=$exp, RawJson=$rawJson, ImportedAt=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT (SnapshotDate, UsedSlots, ReservedSlots, TotalSlots, EndSubscription, ExpiryDate, RawJson)
  VALUES (s.SnapshotDate, $used, $res, $tot, $endSub, $exp, $rawJson);
"@
  Invoke-SqlText -SqlText $licSql -Label 'bd_license'
  Write-Log ("License used=$($lic.usedSlots)/$($lic.totalSlots)")
} catch {
  Write-Log ("License soft-fail: " + $_.Exception.Message)
}

# Load endpoints (replace today's snapshot)
$load = @"
SET NOCOUNT ON;
SET XACT_ABORT ON;
DELETE FROM dbo.Bitdefender_Endpoints WHERE SnapshotDate = '$snap';
INSERT INTO dbo.Bitdefender_Endpoints (
  SnapshotDate, EndpointId, CustomerCode, DeviceName, Fqdn, IpAddress, GroupId,
  IsManaged, MachineType, OperatingSystem, PolicyId, PolicyName, MacAddresses
) VALUES
$($values -join ",`r`n");

SELECT CustomerCode, COUNT(*) AS Cnt
FROM dbo.Bitdefender_Endpoints WITH (NOLOCK)
WHERE SnapshotDate = '$snap'
GROUP BY CustomerCode
ORDER BY CustomerCode;

SELECT COUNT(*) AS Unmapped
FROM dbo.Bitdefender_Endpoints WITH (NOLOCK)
WHERE SnapshotDate = '$snap' AND (CustomerCode IS NULL OR CustomerCode = N'');
"@
Invoke-SqlText -SqlText $load -Label 'bd_endpoints_load'

# Build id → customer map for incidents/quarantine stamping
$epCodeById = @{}
foreach ($ep in $allEp) {
  $id = [string]$ep.id
  if (-not $id) { continue }
  $code = Resolve-CustomerCode ([string]$ep.name) ([string]$ep.fqdn)
  if ($code) { $epCodeById[$id] = $code }
}

# --- Incidents (soft) ---
$incOk = 0; $incCount = 0; $incMsg = 'not attempted'
$incValues = New-Object System.Collections.Generic.List[string]
try {
  $parentCandidates = New-Object System.Collections.Generic.List[string]
  # Custom Groups root + each endpoint id (explore found per-endpoint parentId works)
  try {
    $cgRaw = Invoke-GzRpc -Service 'network' -Method 'getCustomGroupsList' -Params @{}
    $cg = $cgRaw | ConvertFrom-Json
    foreach ($g in @($cg.result)) {
      if ($g.id) { [void]$parentCandidates.Add([string]$g.id) }
    }
  } catch {}
  foreach ($ep in $allEp) {
    if ($ep.id) { [void]$parentCandidates.Add([string]$ep.id) }
  }
  $seenInc = @{}
  $tried = 0
  foreach ($parentId in $parentCandidates) {
    if ($tried -ge 60) { break }
    $tried++
    try {
      $raw = Invoke-GzRpc -Service 'incidents' -Method 'getIncidentsList' -Params @{
        parentId = $parentId
        page     = 1
        perPage  = 50
      }
      if ($raw -match '"error"') { continue }
      $incOk = 1
      $incMsg = 'ok'
      $jo = $raw | ConvertFrom-Json
      $items = @()
      if ($jo.result.items) { $items = @($jo.result.items) }
      elseif ($jo.result -is [System.Array]) { $items = @($jo.result) }
      foreach ($it in $items) {
        $iid = [string]($it.id)
        if (-not $iid) { $iid = [string]($it.incidentId) }
        if (-not $iid) { continue }
        if ($seenInc.ContainsKey($iid)) { continue }
        $seenInc[$iid] = $true
        $eid = ''
        if ($it.endpointId) { $eid = [string]$it.endpointId }
        elseif ($it.endpoint -and $it.endpoint.id) { $eid = [string]$it.endpoint.id }
        elseif ($parentId.Length -eq 24) { $eid = $parentId }
        $code = $null
        if ($eid -and $epCodeById.ContainsKey($eid)) { $code = $epCodeById[$eid] }
        $dname = ''
        if ($it.endpointName) { $dname = [string]$it.endpointName }
        elseif ($it.deviceName) { $dname = [string]$it.deviceName }
        if (-not $code -and $dname) { $code = Resolve-CustomerCode $dname '' }
        $sev = ''; if ($it.severity) { $sev = [string]$it.severity } elseif ($it.priority) { $sev = [string]$it.priority }
        $st = ''; if ($it.status) { $st = [string]$it.status }
        $typ = ''; if ($it.type) { $typ = [string]$it.type } elseif ($it.incidentType) { $typ = [string]$it.incidentType }
        $sum = ''; if ($it.summary) { $sum = [string]$it.summary } elseif ($it.name) { $sum = [string]$it.name } elseif ($it.description) { $sum = [string]$it.description }
        if ($sum.Length -gt 500) { $sum = $sum.Substring(0, 500) }
        $det = 'NULL'
        foreach ($k in @('created','createdAt','detectionDate','lastUpdate')) {
          if ($it.$k) {
            try { $det = ("'{0}'" -f ([datetime]$it.$k).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss')) } catch {}
            break
          }
        }
        $codeSql = if ($code) { Sql-Str $code } else { 'NULL' }
        $rawItem = Sql-Str (($it | ConvertTo-Json -Depth 4 -Compress))
        if ($rawItem.Length -gt 4000) { $rawItem = Sql-Str ((($it | ConvertTo-Json -Depth 2 -Compress).Substring(0, [Math]::Min(3500, 3500)))) }
        $incValues.Add(("({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10})" -f `
          ("'{0}'" -f $snap), (Sql-Str $iid), $codeSql, (Sql-Str $eid), (Sql-Str $dname),
          (Sql-Str $sev), (Sql-Str $st), (Sql-Str $typ), (Sql-Str $sum), $det, $rawItem))
        $incCount++
      }
    } catch {
      # keep going
    }
  }
  if ($incOk -eq 0) { $incMsg = 'API error or no parentId accepted (enable Incidents on API key)' }
  if ($incValues.Count -gt 0) {
    $incSql = @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Bitdefender_Incidents', N'U') IS NULL
BEGIN
  RAISERROR(N'Bitdefender_Incidents missing — run 452 as admin', 16, 1);
  RETURN;
END
DELETE FROM dbo.Bitdefender_Incidents WHERE SnapshotDate = '$snap';
INSERT INTO dbo.Bitdefender_Incidents (
  SnapshotDate, IncidentId, CustomerCode, EndpointId, DeviceName,
  Severity, Status, IncidentType, Summary, DetectedAt, RawJson
) VALUES
$($incValues -join ",`r`n");
"@
    try { Invoke-SqlText -SqlText $incSql -Label 'bd_incidents_load' } catch {
      Write-Log ("Incidents load soft-fail: " + $_.Exception.Message)
    }
  } elseif ($incOk -eq 1) {
    # API ok but zero incidents — clear today
    try {
      Invoke-SqlText -SqlText @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Bitdefender_Incidents', N'U') IS NOT NULL
  DELETE FROM dbo.Bitdefender_Incidents WHERE SnapshotDate = '$snap';
"@ -Label 'bd_incidents_clear'
    } catch {}
    Write-Log 'Incidents API OK — 0 open items'
  } else {
    Write-Log ("Incidents SKIP: " + $incMsg)
  }
} catch {
  $incMsg = $_.Exception.Message
  Write-Log ("Incidents soft-fail: " + $incMsg)
}

# --- Quarantine (soft) ---
$qOk = 0; $qCount = 0; $qMsg = 'not attempted'
$qValues = New-Object System.Collections.Generic.List[string]
try {
  $qRaw = $null
  foreach ($ver in @('v1.0', 'v1.1')) {
    $script:RpcId++
    $uri = '{0}/{1}/jsonrpc/quarantine' -f $baseApi, $ver
    $body = (@{
        jsonrpc = '2.0'
        id      = [string]$script:RpcId
        method  = 'getQuarantineItemsList'
        params  = @{ page = 1; perPage = 50 }
      } | ConvertTo-Json -Compress)
    try {
      $resp = Invoke-WebRequest -Uri $uri -Method POST -Headers @{
        Authorization  = (Get-AuthHeader)
        'Content-Type' = 'application/json'
      } -Body $body -UseBasicParsing -TimeoutSec 60
      $qRaw = ConvertTo-Text $resp.Content
      if ($qRaw -notmatch '"error"') { $qOk = 1; $qMsg = ("ok " + $ver); break }
      $qMsg = ("error " + $ver + ": " + $(if ($qRaw.Length -gt 120) { $qRaw.Substring(0, 120) } else { $qRaw }))
    } catch {
      $qMsg = ($ver + " " + $_.Exception.Message)
    }
  }
  # Also try network service path
  if ($qOk -eq 0) {
    try {
      $qRaw2 = Invoke-GzRpc -Service 'quarantine' -Method 'getQuarantineItemsList' -Params @{ page = 1; perPage = 50 }
      if ($qRaw2 -notmatch '"error"') { $qRaw = $qRaw2; $qOk = 1; $qMsg = 'ok network/quarantine' }
      else { $qMsg = ("network/quarantine: " + $(if ($qRaw2.Length -gt 120) { $qRaw2.Substring(0, 120) } else { $qRaw2 })) }
    } catch {
      $qMsg = $_.Exception.Message
    }
  }
  if ($qOk -eq 1 -and $qRaw) {
    $jo = $qRaw | ConvertFrom-Json
    $items = @()
    if ($jo.result.items) { $items = @($jo.result.items) }
    elseif ($jo.result -is [System.Array]) { $items = @($jo.result) }
    foreach ($it in $items) {
      $qid = [string]($it.id)
      if (-not $qid) { $qid = [string]($it.itemId) }
      if (-not $qid) { continue }
      $eid = ''; if ($it.endpointId) { $eid = [string]$it.endpointId }
      $code = $null
      if ($eid -and $epCodeById.ContainsKey($eid)) { $code = $epCodeById[$eid] }
      $dname = ''; if ($it.endpointName) { $dname = [string]$it.endpointName } elseif ($it.computerName) { $dname = [string]$it.computerName }
      if (-not $code -and $dname) { $code = Resolve-CustomerCode $dname '' }
      $threat = ''; if ($it.threatName) { $threat = [string]$it.threatName } elseif ($it.malwareName) { $threat = [string]$it.malwareName }
      $path = ''; if ($it.filePath) { $path = [string]$it.filePath } elseif ($it.path) { $path = [string]$it.path }
      if ($path.Length -gt 500) { $path = $path.Substring(0, 500) }
      $st = ''; if ($it.status) { $st = [string]$it.status }
      $qa = 'NULL'
      if ($it.quarantineDate) {
        try { $qa = ("'{0}'" -f ([datetime]$it.quarantineDate).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss')) } catch {}
      }
      $codeSql = if ($code) { Sql-Str $code } else { 'NULL' }
      $rawItem = Sql-Str (($it | ConvertTo-Json -Depth 3 -Compress))
      $qValues.Add(("({0},{1},{2},{3},{4},{5},{6},{7},{8},{9})" -f `
        ("'{0}'" -f $snap), (Sql-Str $qid), $codeSql, (Sql-Str $eid), (Sql-Str $dname),
        (Sql-Str $threat), (Sql-Str $path), (Sql-Str $st), $qa, $rawItem))
      $qCount++
    }
    if ($qValues.Count -gt 0) {
      $qSql = @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Bitdefender_Quarantine', N'U') IS NULL
BEGIN
  RAISERROR(N'Bitdefender_Quarantine missing — run 452 as admin', 16, 1);
  RETURN;
END
DELETE FROM dbo.Bitdefender_Quarantine WHERE SnapshotDate = '$snap';
INSERT INTO dbo.Bitdefender_Quarantine (
  SnapshotDate, ItemId, CustomerCode, EndpointId, DeviceName,
  ThreatName, FilePath, Status, QuarantinedAt, RawJson
) VALUES
$($qValues -join ",`r`n");
"@
      try { Invoke-SqlText -SqlText $qSql -Label 'bd_quarantine_load' } catch {
        Write-Log ("Quarantine load soft-fail: " + $_.Exception.Message)
      }
    } else {
      try {
        Invoke-SqlText -SqlText @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Bitdefender_Quarantine', N'U') IS NOT NULL
  DELETE FROM dbo.Bitdefender_Quarantine WHERE SnapshotDate = '$snap';
"@ -Label 'bd_quarantine_clear'
      } catch {}
      Write-Log 'Quarantine API OK — 0 items'
    }
  } else {
    Write-Log ("Quarantine SKIP: " + $qMsg)
  }
} catch {
  $qMsg = $_.Exception.Message
  Write-Log ("Quarantine soft-fail: " + $qMsg)
}

# Collect status row
try {
  $mappedN = ($allEp.Count - $unmapped)
  $stSql = @"
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.Bitdefender_CollectStatus', N'U') IS NULL RETURN;
MERGE dbo.Bitdefender_CollectStatus AS t
USING (SELECT CAST('$snap' AS date) AS SnapshotDate) s ON t.SnapshotDate = s.SnapshotDate
WHEN MATCHED THEN UPDATE SET
  EndpointsTotal=$($allEp.Count), EndpointsMapped=$mappedN, EndpointsUnmapped=$unmapped,
  IncidentsOk=$incOk, IncidentsCount=$incCount, QuarantineOk=$qOk, QuarantineCount=$qCount,
  IncidentsMessage=$(Sql-Str $incMsg), QuarantineMessage=$(Sql-Str $qMsg),
  ImportedAt=SYSUTCDATETIME()
WHEN NOT MATCHED THEN INSERT (
  SnapshotDate, EndpointsTotal, EndpointsMapped, EndpointsUnmapped,
  IncidentsOk, IncidentsCount, QuarantineOk, QuarantineCount,
  IncidentsMessage, QuarantineMessage
) VALUES (
  s.SnapshotDate, $($allEp.Count), $mappedN, $unmapped,
  $incOk, $incCount, $qOk, $qCount,
  $(Sql-Str $incMsg), $(Sql-Str $qMsg)
);
"@
  Invoke-SqlText -SqlText $stSql -Label 'bd_collect_status'
} catch {
  Write-Log ("CollectStatus soft-fail: " + $_.Exception.Message)
}

Write-Log ("log=" + $log)
Write-Log ("Incidents ok=$incOk count=$incCount msg=$incMsg")
Write-Log ("Quarantine ok=$qOk count=$qCount msg=$qMsg")
Write-Log '=== Bitdefender EPP collect done ==='
Write-Host 'If Unmapped > 0: SELECT DeviceName, Fqdn FROM dbo.vw_Bitdefender_Unmapped_Latest; add Dim_Bitdefender_NameMap patterns; re-run.'
