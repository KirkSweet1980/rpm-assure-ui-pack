# Apply-Epp-All-Customers-Incidents.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = 'C:\RPM-Assure\App'
$SqlRoot = 'C:\RPM-Assure\Sql\bitdefender'
$Server = '102.222.21.220,14333'
$Db = 'RPMAssure_App'
Write-Host '=== EPP map all customers + incidents/quarantine ==='
if (-not (Test-Path $SqlRoot)) { New-Item -ItemType Directory -Path $SqlRoot -Force | Out-Null }
Copy-Item (Join-Path $Here 'Sql\bitdefender\452_Expand_Epp_Map_Incidents.sql') (Join-Path $SqlRoot '452_Expand_Epp_Map_Incidents.sql') -Force
Copy-Item (Join-Path $Here 'Sql\bitdefender\Collect-Bitdefender-To-RPMAssure.ps1') (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1') -Force
Write-Host 'OK SQL scripts'
$pairs = @(
  'src\lib\data\types.ts',
  'src\lib\data\live-portfolio.ts',
  'src\lib\data\cover.ts',
  'src\routes\customers.$code.epp.index.tsx',
  'src\routes\customers.$code.epp.modules.tsx',
  'src\routes\customers.$code.epp.incidents.tsx',
  'src\routes\customers.$code.epp.quarantine.tsx',
  'src\components\customer\customer-sections.tsx'
)
foreach ($rel in $pairs) {
  $s = Join-Path $Here ('App\' + $rel)
  $d = Join-Path $AppRoot $rel
  if (-not (Test-Path -LiteralPath $s)) { Write-Host "SKIP $s"; continue }
  $dir = Split-Path -Parent $d
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  Copy-Item -LiteralPath $s -Destination $d -Force
  Write-Host "OK $d"
}
Write-Host 'Apply 452 as Windows auth (admin)...'
& sqlcmd -S $Server -d $Db -E -C -b -i (Join-Path $SqlRoot '452_Expand_Epp_Map_Incidents.sql') 2>&1 | ForEach-Object { Write-Host $_ }
Write-Host 'Re-run Bitdefender collect...'
powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SqlRoot 'Collect-Bitdefender-To-RPMAssure.ps1')
Write-Host ("collect exit=" + $LASTEXITCODE)
Write-Host 'Proof counts:'
& sqlcmd -S $Server -d $Db -E -C -Q "SET NOCOUNT ON; SELECT CustomerCode, COUNT(*) Cnt FROM dbo.Bitdefender_Endpoints WITH (NOLOCK) WHERE SnapshotDate=(SELECT MAX(SnapshotDate) FROM dbo.Bitdefender_Endpoints) AND CustomerCode IS NOT NULL GROUP BY CustomerCode ORDER BY 1; SELECT COUNT(*) Unmapped FROM dbo.Bitdefender_Endpoints WITH (NOLOCK) WHERE SnapshotDate=(SELECT MAX(SnapshotDate) FROM dbo.Bitdefender_Endpoints) AND (CustomerCode IS NULL OR LTRIM(RTRIM(CustomerCode))=''); SELECT TOP 1 SnapshotDate, EndpointsTotal, EndpointsMapped, EndpointsUnmapped, IncidentsOk, IncidentsCount, QuarantineOk, QuarantineCount, IncidentsMessage, QuarantineMessage FROM dbo.Bitdefender_CollectStatus ORDER BY SnapshotDate DESC;" 2>&1 | ForEach-Object { Write-Host $_ }
Write-Host 'Restart app...'
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 6
} catch { Write-Host $_ }
Write-Host 'Hard-refresh EPP pages for AHIC, HYDRA, RSR, UVSS, RPMINT, METSI, ABLE, RSS, BHF, SBS.'
Write-Host '=== Done ==='
