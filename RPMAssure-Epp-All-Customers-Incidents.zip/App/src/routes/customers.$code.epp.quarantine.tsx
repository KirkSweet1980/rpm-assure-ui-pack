import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHead } from "@/components/ui/card";
import { Route as CustomerRoute } from "./customers.$code";
import { NoCoverPanel } from "@/components/ui/no-cover";
import { formatSastDateTime } from "@/lib/utils";

export const Route = createFileRoute("/customers/$code/epp/quarantine")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return <p className="text-sm text-muted">Loading customer workspace…</p>;
    }
    const epp = data.epp;
    const covered =
      data.cover?.epp === true ||
      epp?.enabled === true ||
      (epp?.devices?.length ?? 0) > 0 ||
      (epp?.summary?.deviceCount ?? 0) > 0 ||
      (data.customer?.eppDeviceCount ?? 0) > 0;
    if (!covered) {
      return (
        <NoCoverPanel
          service="Endpoint Protection (EPP) · Quarantine"
          hint={
            epp?.message ||
            "No cover — no Bitdefender endpoints mapped to this customer."
          }
        />
      );
    }
    const rows = epp?.quarantine ?? [];
    const feed = epp?.feedStatus;
    return (
      <div className="space-y-3">
        <Card>
          <CardHead>RPM End Point Protection · Quarantine ({rows.length})</CardHead>
          <CardContent className="p-0">
            {rows.length === 0 ? (
              <div className="space-y-2 p-4 text-sm text-muted">
                <p className="font-medium text-fg">No quarantine items on latest collect.</p>
                {feed?.quarantineOk === false ? (
                  <p className="text-[12px] text-subtle">
                    GravityZone quarantine API not available for this key
                    {feed.quarantineMessage ? `: ${feed.quarantineMessage}` : "."} Enable
                    Quarantine rights on the API key, re-run Bitdefender collect.
                  </p>
                ) : (
                  <p className="text-[12px] text-subtle">
                    No quarantined files for this customer's endpoints on the latest
                    snapshot.
                  </p>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px] text-left text-sm">
                  <thead className="border-b border-border bg-muted/40 text-[11px] uppercase tracking-wide text-muted">
                    <tr>
                      <th className="px-3 py-2">Quarantined</th>
                      <th className="px-3 py-2">Device</th>
                      <th className="px-3 py-2">Threat</th>
                      <th className="px-3 py-2">Path</th>
                      <th className="px-3 py-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.itemId} className="border-b border-border/70">
                        <td className="px-3 py-2 text-xs text-muted">
                          {r.quarantinedAt ? formatSastDateTime(r.quarantinedAt) : "—"}
                        </td>
                        <td className="px-3 py-2 font-medium">{r.deviceName ?? "—"}</td>
                        <td className="px-3 py-2 text-xs">{r.threatName ?? "—"}</td>
                        <td
                          className="max-w-[320px] truncate px-3 py-2 text-xs text-muted"
                          title={r.filePath ?? undefined}
                        >
                          {r.filePath ?? "—"}
                        </td>
                        <td className="px-3 py-2 text-xs">{r.status ?? "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  },
});
