import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHead } from "@/components/ui/card";
import { Route as CustomerRoute } from "./customers.$code";
import { NoCoverPanel } from "@/components/ui/no-cover";

export const Route = createFileRoute("/customers/$code/epp/modules")({
  component: function CustomerChild() {
    const data = CustomerRoute.useLoaderData();
    if (!data?.customer) {
      return <p className="text-sm text-muted">Loading customer workspace…</p>;
    }
    const epp = data.epp;
    const devices = epp?.devices ?? [];
    const covered =
      data.cover?.epp === true ||
      epp?.enabled === true ||
      devices.length > 0 ||
      (data.customer?.eppDeviceCount ?? 0) > 0;
    if (!covered) {
      return (
        <NoCoverPanel
          service="Endpoint Protection (EPP)"
          hint={
            epp?.message ||
            "No cover — enable EPP for this customer to collect this module."
          }
        />
      );
    }
    const byPolicy = new Map<string, number>();
    for (const d of devices) {
      const k = d.policyName?.trim() || "(no policy name)";
      byPolicy.set(k, (byPolicy.get(k) ?? 0) + 1);
    }
    const policies = [...byPolicy.entries()].sort((a, b) => b[1] - a[1]);
    return (
      <div className="space-y-3">
        <Card>
          <CardHead>RPM End Point Protection · Policies on endpoints</CardHead>
          <CardContent className="p-4 text-sm">
            <p className="mb-3 text-muted">
              Policy assignment from GravityZone endpoint list (module matrix expands when API rights allow).
            </p>
            {policies.length === 0 ? (
              <p className="text-muted">No endpoint/policy rows for this customer on latest snapshot.</p>
            ) : (
              <ul className="space-y-1">
                {policies.map(([name, n]) => (
                  <li
                    key={name}
                    className="flex items-center justify-between rounded-md border border-border px-3 py-2"
                  >
                    <span className="font-medium text-fg">{name}</span>
                    <span className="tabular-nums text-muted">{n} device(s)</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    );
  },
});
