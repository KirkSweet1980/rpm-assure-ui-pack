Visible brand words on login (not watermark). Run Apply-Login-Brand-Words-Visible.ps1
