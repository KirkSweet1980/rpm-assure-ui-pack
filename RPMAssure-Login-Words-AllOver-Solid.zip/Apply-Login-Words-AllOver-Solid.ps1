﻿# Apply-Login-Words-AllOver-Solid.ps1
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = 'C:\RPM-Assure\App'
foreach ($rel in @('src\routes\login.tsx', 'src\styles.css')) {
  $s = Join-Path $Here ('App\' + $rel)
  $d = Join-Path $AppRoot $rel
  Copy-Item -LiteralPath $s -Destination $d -Force
  Write-Host ("OK " + $d)
}
try {
  schtasks /End /TN RPMAssure-App-OnStart 2>$null | Out-Null
  Start-Sleep 2
  Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
  }
  schtasks /Run /TN RPMAssure-App-OnStart | Out-Null
  Start-Sleep 5
} catch { Write-Host $_ }
Write-Host 'Hard-refresh /login.'
Write-Host '=== Done ==='
