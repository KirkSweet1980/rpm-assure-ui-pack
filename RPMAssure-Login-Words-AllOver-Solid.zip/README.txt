Solid brand words all over login (not watermark). Run Apply-Login-Words-AllOver-Solid.ps1
