import { Download } from "lucide-react";

export function DownloadPackButton({
  compact = false,
}: {
  compact?: boolean;
}) {
  return (
    <a
      href="/downloads/RPMAssure-Exco-SoftBoard.zip"
      download="RPMAssure-Exco-SoftBoard.zip"
      className={
        compact
          ? "inline-flex min-h-9 items-center gap-1 rounded-md border border-border bg-surface px-2 py-1 text-[11px] font-semibold text-fg hover:border-accent/40"
          : "inline-flex min-h-10 items-center gap-2 rounded-lg bg-[#3b82f6] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#2563eb]"
      }
    >
      <Download className="h-4 w-4 shrink-0" />
      {compact ? "Download zip" : "Download install zip"}
    </a>
  );
}
