import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import { SpaLink } from "@/components/nav/spa-link";
import {
  Building2,
  ChevronDown,
  FileText,
  LayoutDashboard,
  RefreshCw,
  Settings,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { DensityToggle } from "@/components/portfolio/density-toggle";
import { ThemeToggle } from "@/components/portfolio/theme-toggle";
import { UserButton } from "@/lib/auth/gates";
import { useDensity } from "@/lib/density";
import { RpmAssureNavLogo } from "@/components/brand/rpm-assure-nav-logo";
import { fetchPortfolio } from "@/lib/data/portfolio";
import {
  readClientPortfolioCache,
  writeClientPortfolioCache,
} from "@/lib/data/client-portfolio-cache";
import { useIdleLogout } from "@/lib/auth/idle-logout";
import { useStaffProfile } from "@/lib/auth/use-staff-profile";
import {
  CustomerSwitcher,
  rememberRecentCustomer,
  type SwitcherCustomer,
} from "@/components/nav/customer-switcher";
import { SettingsTreeMenu } from "@/components/nav/settings-tree-menu";
import { SETTINGS_MENU_ENABLED } from "@/lib/auth/features";
import { SystemClock } from "@/components/nav/system-clock";
import { isNavActive } from "@/lib/nav/site-tree";
import { scrollChromeToTop } from "@/lib/nav/scroll-chrome";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  CustomerListProvider,
  sortMasterCustomers,
  type MasterCustomer,
} from "@/lib/nav/customer-list-context";
import { inferCustomerCover } from "@/lib/data/cover";

/**
 * App shell — D3 top navigation (navy chrome) + shared customer list for master–detail.
 */
export function AppShell({
  children,
  title,
  subtitle,
}: {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}) {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [reportsOpen, setReportsOpen] = useState(false);
  const [masterCustomers, setMasterCustomers] = useState<MasterCustomer[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const router = useRouter();
  const { isCompact } = useDensity();
  const { profile } = useStaffProfile();
  const isPlatformAdmin =
    profile?.permissions.canAccessPlatformSettings === true;
  const navRef = useRef<HTMLElement>(null);
  useIdleLogout();

  const currentCustomerCode = useMemo(() => {
    const m = pathname.match(/^\/customers\/([^/]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  }, [pathname]);

  useEffect(() => {
    if (currentCustomerCode) rememberRecentCustomer(currentCustomerCode);
  }, [currentCustomerCode]);

  useEffect(() => {
    requestAnimationFrame(scrollChromeToTop);
  }, [pathname]);

  useEffect(() => {
    let cancelled = false;

    function mapRows(
      p: Awaited<ReturnType<typeof fetchPortfolio>> | null | undefined,
    ): MasterCustomer[] {
      if (!p) return [];
      const boards = p.exco?.boards ?? [];
      const boardBy = new Map(
        boards.map((b) => [b.customerCode.toUpperCase(), b] as const),
      );
      let rows = p.customers ?? p.rows ?? [];
      const allowed = profile?.allowedCustomerCodes;
      if (allowed && allowed.length > 0) {
        const set = new Set(allowed.map((c) => c.toUpperCase()));
        rows = rows.filter((r) => set.has(r.customerCode.toUpperCase()));
      }
      const mapped = rows
        .filter(
          (r) =>
            Boolean(r.sqlInstanceName && String(r.sqlInstanceName).trim()) ||
            (r.operatorCount ?? 0) > 0 ||
            (r.pulsewayDeviceCount ?? 0) > 0 ||
            (r.pulsewayOfflineCount ?? 0) > 0 ||
            Boolean(r.pulsewayOrgName && String(r.pulsewayOrgName).trim()) ||
            (r.coveDeviceCount ?? 0) > 0 ||
            (r.eppDeviceCount ?? 0) > 0 ||
            (r.cspUserCount ?? 0) > 0 ||
            r.cover?.syspro ||
            r.cover?.rmm ||
            r.cover?.cove ||
            r.cover?.epp ||
            r.cover?.csp,
        )
        .map((r) => {
          const b = boardBy.get(r.customerCode.toUpperCase());
          const cover =
            r.cover ??
            inferCustomerCover({
              pillarSyspro: r.pillarSyspro,
              pillarPulseway: r.pillarPulseway,
              pillarCove: r.pillarCove,
              pillarEpp: r.pillarEpp,
              pillarCsp: r.pillarCsp,
              sqlInstanceName: r.sqlInstanceName,
              operatorCount: r.operatorCount,
              activeUserCount: r.activeUserCount,
              sysproLastImportAt: r.lastImportAt,
              sysproJobErrorCount: r.sysproJobErrorCount,
              sysproDtrVarianceLines: r.sysproDtrVarianceLines,
              pulsewayOrgName: r.pulsewayOrgName,
              pulsewayDeviceCount: r.pulsewayDeviceCount,
              coveDeviceCount: r.coveDeviceCount,
              eppDeviceCount: r.eppDeviceCount,
              cspUserCount: r.cspUserCount,
              cspLicenseCount: r.cspLicenseSkuCount,
            });
          return {
            code: r.customerCode,
            name: (r.displayName || r.customerCode).trim(),
            healthRag: r.healthRag,
            needsAttention:
              (b?.attentionReasons?.length ?? 0) > 0 || r.healthRag !== "Green",
            collectFresh: b?.collectFresh ?? !!r.lastImportAt,
            cover,
          } satisfies MasterCustomer;
        });
      return sortMasterCustomers(mapped);
    }

    const cached = readClientPortfolioCache();
    if (cached) {
      setMasterCustomers(mapRows(cached));
      setListLoading(false);
    }

    void fetchPortfolio()
      .then((p) => {
        if (cancelled) return;
        writeClientPortfolioCache(p);
        setMasterCustomers(mapRows(p));
        setListLoading(false);
      })
      .catch(() => {
        if (!cancelled) setListLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [profile?.allowedCustomerCodes]);

  const switcherCustomers: SwitcherCustomer[] = useMemo(
    () =>
      masterCustomers.map((c) => ({
        code: c.code,
        name: c.name,
        healthRag: c.healthRag,
        needsAttention: c.needsAttention,
        collectFresh: c.collectFresh,
      })),
    [masterCustomers],
  );

  function linkActive(href: string, match: "exact" | "prefix") {
    return isNavActive(pathname, { id: href, label: "", href, match });
  }

  const listValue = useMemo(
    () => ({
      customers: masterCustomers,
      setCustomers: setMasterCustomers,
      loading: listLoading,
    }),
    [masterCustomers, listLoading],
  );

  return (
    <CustomerListProvider value={listValue}>
      <div className="rpma-topnav-shell rpma-d3-shell flex min-h-dvh flex-col bg-bg text-fg">
        <header
          ref={navRef}
          className="rpma-topnav sticky top-0 z-50 border-b border-border-strong"
        >
          <div className="rpma-topnav-inner mx-auto flex w-full max-w-[1680px] items-center gap-3 px-3 sm:gap-4 sm:px-4 lg:px-5">
            <div className="rpma-topnav-left flex min-w-0 flex-1 items-center gap-3 sm:gap-5">
              <Link
                to="/"
                className="rpma-topnav-brand rpma-focus shrink-0 rounded-lg"
                aria-label="RPM Assure — Assure App"
              >
                <RpmAssureNavLogo />
              </Link>

              <nav
                className="rpma-topnav-primary flex min-w-0 flex-wrap items-center gap-1"
                aria-label="Main"
              >
                <SpaLink
                  href="/"
                  className={cn(
                    "rpma-topnav-link",
                    linkActive("/", "exact") && "rpma-topnav-link-active",
                  )}
                >
                  <LayoutDashboard className="h-3.5 w-3.5 shrink-0 opacity-90" />
                  <span>Exco Insight</span>
                </SpaLink>

                <DropdownMenu
                  open={reportsOpen}
                  onOpenChange={(o) => {
                    setReportsOpen(o);
                    if (o) setSettingsOpen(false);
                  }}
                >
                  <DropdownMenuTrigger asChild>
                    <button
                      type="button"
                      className={cn(
                        "rpma-topnav-link",
                        pathname.startsWith("/reports") &&
                          "rpma-topnav-link-active",
                      )}
                    >
                      <FileText className="h-3.5 w-3.5 shrink-0 opacity-90" />
                      <span>Reports</span>
                      <ChevronDown className="h-3 w-3 opacity-70" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-56">
                    <DropdownMenuLabel>Reports</DropdownMenuLabel>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports"
                        onClick={() => setReportsOpen(false)}
                      >
                        Open Reports
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel>Quick packs</DropdownMenuLabel>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=day-end"
                        onClick={() => setReportsOpen(false)}
                      >
                        Day end · FinSight
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=period-end"
                        onClick={() => setReportsOpen(false)}
                      >
                        Period end · FinSight
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=ams-full"
                        onClick={() => setReportsOpen(false)}
                      >
                        Applications RPM Assure
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=estate"
                        onClick={() => setReportsOpen(false)}
                      >
                        Estate overview
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=rmm-service"
                        onClick={() => setReportsOpen(false)}
                      >
                        RMM service pack
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=services-cover"
                        onClick={() => setReportsOpen(false)}
                      >
                        Services on cover
                      </SpaLink>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <SpaLink
                        href="/reports?format=custom-pack"
                        onClick={() => setReportsOpen(false)}
                      >
                        Custom report
                      </SpaLink>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <div
                  className="mx-0.5 hidden h-5 w-px shrink-0 bg-white/15 sm:block"
                  aria-hidden
                />

                <CustomerSwitcher
                  customers={switcherCustomers}
                  currentCode={currentCustomerCode}
                />

                {SETTINGS_MENU_ENABLED ? (
                  <DropdownMenu
                    open={settingsOpen}
                    onOpenChange={(o) => {
                      setSettingsOpen(o);
                      if (o) setReportsOpen(false);
                    }}
                  >
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        className={cn(
                          "rpma-topnav-link",
                          pathname.startsWith("/settings") &&
                            "rpma-topnav-link-active",
                        )}
                      >
                        <Settings className="h-3.5 w-3.5 shrink-0 opacity-90" />
                        <span className="hidden sm:inline">Configuration</span>
                        <ChevronDown className="h-3 w-3 opacity-70" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="start"
                      className="w-64 max-h-[min(70vh,28rem)] overflow-y-auto"
                    >
                      <DropdownMenuLabel>
                        {isPlatformAdmin ? "Configuration" : "My account"}
                      </DropdownMenuLabel>
                      <SettingsTreeMenu
                        pathname={pathname}
                        variant="dropdown"
                        adminOnly={isPlatformAdmin}
                        onNavigate={() => setSettingsOpen(false)}
                      />
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : null}
              </nav>
            </div>

            <div className="rpma-topnav-right ml-auto flex shrink-0 items-center gap-1.5 sm:gap-2">
              <SystemClock className="hidden md:flex" />
              <ThemeToggle compact />
              <div className="hidden sm:block">
                <DensityToggle compact />
              </div>
              <button
                type="button"
                className="rpma-topnav-iconbtn"
                aria-label="Refresh data"
                title="Refresh"
                onClick={() => {
                  try {
                    sessionStorage.removeItem("rpma_portfolio_cache_v1");
                  } catch {
                    /* */
                  }
                  void router.invalidate();
                }}
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
              <div className="rpma-topnav-user">
                <UserButton />
              </div>
            </div>
          </div>

          <div className="rpma-topnav-titlebar border-t border-border-strong">
            <div className="mx-auto flex w-full max-w-[1680px] items-center gap-2 px-3 py-1.5 sm:px-4 lg:px-5">
              {pathname.startsWith("/reports") ? (
                <FileText className="hidden h-3.5 w-3.5 shrink-0 text-accent sm:block" />
              ) : pathname.startsWith("/settings") ? (
                <Settings className="hidden h-3.5 w-3.5 shrink-0 text-accent sm:block" />
              ) : pathname.startsWith("/customers") ? (
                <Building2 className="hidden h-3.5 w-3.5 shrink-0 text-accent sm:block" />
              ) : (
                <LayoutDashboard className="hidden h-3.5 w-3.5 shrink-0 text-accent sm:block" />
              )}
              <div className="min-w-0">
                <h1 className="truncate text-[14px] font-bold tracking-tight text-fg sm:text-[15px]">
                  {title}
                </h1>
                {subtitle ? (
                  <p className="truncate text-[11px] text-muted">{subtitle}</p>
                ) : null}
              </div>
            </div>
          </div>
        </header>

        <main
          className={cn(
            "rpma-topnav-main flex-1 overflow-x-hidden",
            pathname === "/"
              ? "p-2 sm:p-2.5 md:p-3"
              : isCompact
                ? "p-2.5 md:p-3"
                : "p-3 md:p-4",
          )}
        >
          <div
            className={cn(
              "rpma-topnav-canvas w-full",
              pathname === "/" ? "max-w-none" : "mx-auto max-w-[1680px]",
            )}
          >
            {children}
          </div>
        </main>
      </div>
    </CustomerListProvider>
  );
}
