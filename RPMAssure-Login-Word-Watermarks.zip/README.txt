Login word watermarks. Run Apply-Login-Word-Watermarks.ps1
