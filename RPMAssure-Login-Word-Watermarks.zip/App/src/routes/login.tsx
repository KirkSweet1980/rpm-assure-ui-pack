import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RpmAssureMark } from "@/components/brand/rpm-assure-mark";
import { IdleLogoutBanner } from "@/lib/auth/idle-logout";
import { normalizeLoginIdentifier } from "@/lib/auth/root-admin";
export const Route = createFileRoute("/login")({
  component: LoginPage,
});

type FloatWin = {
  id: string;
  kind: "ps" | "sql" | "linux" | "macos";
  title: string;
  lines: string[];
  className: string;
};

/** One of each: PowerShell · SQL · Linux · macOS */
const FLOAT_WINDOWS: FloatWin[] = [
  {
    id: "win-ps",
    kind: "ps",
    title: "Windows PowerShell",
    className: "rpma-login-fwin rpma-login-fwin--ps rpma-login-fwin--tl",
    lines: [
      "PS C:\\> Get-Process | Select -First 6",
      "",
      "Handles  NPM(K)  PM(K)  Id  ProcessName",
      "-------  ------  -----  --  -----------",
      "  10316     122    156 Idle",
      "  39878    1134   1134 System",
      "  13376    1222    188 csrss",
      "  28164    1222    202 services",
      "  12936    1222    118 lsass",
      "  32248    1208    218 svchost",
      "",
      "PS C:\\> Get-Service WinRM",
      "Status  Name   DisplayName",
      "------  ----   -----------",
      "Running WinRM  Windows Remote Management",
    ],
  },
  {
    id: "win-sql",
    kind: "sql",
    title: "Microsoft SQL Server Management Studio",
    className: "rpma-login-fwin rpma-login-fwin--sql rpma-login-fwin--tr",
    lines: [
      "-- Query connected to RPMREPORTS",
      "USE [RPMAssure_App];",
      "GO",
      "",
      "SELECT",
      "    c.CustomerCode,",
      "    c.DisplayName,",
      "    COUNT(d.AccountId) AS Devices",
      "FROM dbo.Dim_Customer AS c",
      "LEFT JOIN dbo.Cove_DeviceStatistics AS d",
      "  ON d.CustomerCode = c.CustomerCode",
      "WHERE c.Active = 1",
      "GROUP BY c.CustomerCode, c.DisplayName",
      "ORDER BY Devices DESC;",
      "GO",
      "",
      "-- (21 rows affected)",
    ],
  },
  {
    id: "win-linux",
    kind: "linux",
    title: "user@rpm-linux: ~",
    className: "rpma-login-fwin rpma-login-fwin--linux rpma-login-fwin--bl",
    lines: [
      "user@rpm-linux:~$ uname -a",
      "Linux rpm-linux 6.8.0-51-generic #52-Ubuntu SMP x86_64 GNU/Linux",
      "",
      "user@rpm-linux:~$ df -h / /var",
      "Filesystem      Size  Used Avail Use% Mounted on",
      "/dev/sda2        98G   42G   52G  45% /",
      "/dev/sda4       200G   88G  102G  47% /var",
      "",
      "user@rpm-linux:~$ systemctl status ssh --no-pager",
      "● ssh.service - OpenBSD Secure Shell server",
      "     Active: active (running)",
      "",
      "user@rpm-linux:~$ _",
    ],
  },
  {
    id: "win-macos",
    kind: "macos",
    title: "Terminal — zsh — 80×24",
    className: "rpma-login-fwin rpma-login-fwin--macos rpma-login-fwin--br",
    lines: [
      "last login: Mon Aug 10 17:24:01 on ttys000",
      "rpm@MacBook-Pro ~ % sw_vers",
      "ProductName:		macOS",
      "ProductVersion:	15.5",
      "BuildVersion:	24F74",
      "",
      "rpm@MacBook-Pro ~ % top -l 1 | head -n 8",
      "Processes: 412 total, 3 running, 409 sleeping",
      "CPU usage: 8.2% user, 4.1% sys, 87.7% idle",
      "PhysMem: 18G used (2148M wired), 14G unused",
      "",
      "rpm@MacBook-Pro ~ % ping -c 2 10.0.0.1",
      "64 bytes from 10.0.0.1: icmp_seq=0 ttl=64 time=1.2 ms",
      "64 bytes from 10.0.0.1: icmp_seq=1 ttl=64 time=0.9 ms",
      "rpm@MacBook-Pro ~ % █",
    ],
  },
];

function lineClass(kind: FloatWin["kind"], line: string): string {
  if (kind === "ps") {
    if (line.startsWith("PS ") || line.startsWith(">>")) return "is-prompt";
    if (/Running|True/i.test(line)) return "is-ok";
  }
  if (kind === "sql") {
    if (line.startsWith("--")) return "is-comment";
    if (/^(SELECT|FROM|WHERE|LEFT|GROUP|ORDER|USE|GO)\b/i.test(line.trim()))
      return "is-kw";
    if (line.includes("rows affected")) return "is-ok";
  }
  if (kind === "linux") {
    if (line.includes("$ ")) return "is-prompt";
    if (line.startsWith("●") || /active \(running\)/i.test(line)) return "is-ok";
  }
  if (kind === "macos") {
    if (line.includes("% ") || line.startsWith("last login")) return "is-prompt";
    if (/ProductName|unused|ttl=/i.test(line)) return "is-ok";
  }
  return "";
}


/** Soft brand-word watermarks behind login (clarity, source of truth, …) */
const LOGIN_WATERMARK_WORDS = [
  { text: "clarity", className: "rpma-login-word-wm--1" },
  { text: "source of truth", className: "rpma-login-word-wm--2" },
  { text: "trust", className: "rpma-login-word-wm--3" },
  { text: "assurance", className: "rpma-login-word-wm--4" },
  { text: "visibility", className: "rpma-login-word-wm--5" },
  { text: "accountability", className: "rpma-login-word-wm--6" },
  { text: "insight", className: "rpma-login-word-wm--7" },
  { text: "integrity", className: "rpma-login-word-wm--8" },
  { text: "confidence", className: "rpma-login-word-wm--9" },
  { text: "control", className: "rpma-login-word-wm--10" },
  { text: "resilience", className: "rpma-login-word-wm--11" },
  { text: "evidence", className: "rpma-login-word-wm--12" },
] as const;

function LoginWordWatermarks() {
  return (
    <div className="rpma-login-word-wm-layer" aria-hidden="true">
      {LOGIN_WATERMARK_WORDS.map((w) => (
        <span key={w.text} className={`rpma-login-word-wm ${w.className}`}>
          {w.text}
        </span>
      ))}
    </div>
  );
}

function FloatWindow({ win }: { win: FloatWin }) {
  return (
    <div className={win.className} aria-hidden="true">
      <div className="rpma-login-fwin-bar">
        <span className="rpma-login-fwin-dots">
          <i />
          <i />
          <i />
        </span>
        <span className="rpma-login-fwin-title">{win.title}</span>
      </div>
      <div className="rpma-login-fwin-body">
        {win.lines.map((line, i) => (
          <div key={i} className={lineClass(win.kind, line)}>
            {line || "\u00a0"}
          </div>
        ))}
      </div>
    </div>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      void navigate({ to: "/" });
    }
  }, [isPending, user, navigate]);

  async function onSignIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const raw = email.trim();
      if (!raw) throw new Error("Enter your email or username.");
      if (password.length < 8) {
        throw new Error("Password must be at least 8 characters.");
      }
      const loginEmail = raw.includes("@")
        ? raw.toLowerCase()
        : normalizeLoginIdentifier(raw);
      if (!loginEmail) throw new Error("Enter a valid email or username.");
      const res = await authClient.signIn.email({
        email: loginEmail,
        password,
      });
      if (res.error) {
        const rawMsg = res.error.message || res.error.statusText || "Sign-in failed";
        if (/invalid|credential|password|user/i.test(rawMsg)) {
          throw new Error("Invalid email or password.");
        }
        throw new Error(rawMsg);
      }
      // 2FA deferred — ignore twoFactorRedirect for now and enter app
      await navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (/fetch|network|Failed to fetch/i.test(message)) {
        setError(message + " - check the app is running.");
      } else {
        setError(message);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rpma-login-hero">
      <div className="rpma-login-hero-bg" aria-hidden="true" />
      <div className="rpma-login-hero-grid" aria-hidden="true" />
      <div className="rpma-login-hero-glow" aria-hidden="true" />
      <LoginWordWatermarks />

      <div className="rpma-login-ps-stage" aria-hidden="true">
        {FLOAT_WINDOWS.map((w) => (
          <FloatWindow key={w.id} win={w} />
        ))}
      </div>

      <div className="rpma-login-hero-center">
        <div className="rpma-login-hero-brand">
          <div className="rpma-login-hero-mark">
            <RpmAssureMark size={108} showWordmark={false} className="rpma-mark-pulse" />
          </div>
          <h1 className="rpma-login-hero-title">
            <span className="rpma-login-hero-rpm">RPM</span>{" "}
            <span className="rpma-login-hero-assure">Assure</span>
          </h1>
          <p className="rpma-login-hero-tag">
            <span className="rpma-login-hero-tag-line">Assurance Delivered</span>
          </p>
        </div>

        <div className="rpma-login-glass">
          <IdleLogoutBanner />
          <h2 className="rpma-login-glass-title">Sign in</h2>

          {!authEnabled ? (
            <p className="rpma-login-glass-error">Auth is disabled.</p>
          ) : (
            <form className="rpma-login-glass-form" onSubmit={onSignIn}>
              <label className="rpma-login-field">
                <span className="rpma-login-field-label">Email or username</span>
                <span className="rpma-login-field-wrap">
                  <User className="rpma-login-field-icon" size={16} strokeWidth={2} />
                  <input
                    type="text"
                    required
                    placeholder="Email or username"
                    autoComplete="username"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </span>
              </label>

              <label className="rpma-login-field">
                <span className="rpma-login-field-label">Password</span>
                <span className="rpma-login-field-wrap">
                  <Lock className="rpma-login-field-icon" size={16} strokeWidth={2} />
                  <input
                    type={showPw ? "text" : "password"}
                    required
                    minLength={8}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="rpma-login-field-eye"
                    onClick={() => setShowPw((v) => !v)}
                    aria-label={showPw ? "Hide password" : "Show password"}
                    tabIndex={-1}
                  >
                    {showPw ? (
                      <EyeOff size={16} strokeWidth={2} />
                    ) : (
                      <Eye size={16} strokeWidth={2} />
                    )}
                  </button>
                </span>
              </label>

              {error ? <p className="rpma-login-glass-error">{error}</p> : null}

              <button
                type="submit"
                className="rpma-login-glass-submit"
                disabled={busy}
              >
                <Lock size={16} strokeWidth={2.25} />
                {busy ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}
        </div>
      </div>

      <p className="rpma-login-hero-footer">Powered by RPM Resources</p>
    </div>
  );
}
