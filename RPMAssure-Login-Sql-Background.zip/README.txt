Login SQL full background. Run Apply-Login-Sql-Background.ps1
